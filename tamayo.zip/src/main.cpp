#include "tamayo/editor/EditorApp.h"
#include <iostream>
#include <string>

int main(int argc, char* argv[]) {
    tamayo::EditorApp app;

    // Parse command line arguments
    std::string openFile;
    std::string exportJson;
    std::string exportWebgl;
    bool showVersion = false;
    bool showHelp = false;

    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg == "--open" && i + 1 < argc) {
            openFile = argv[++i];
        } else if (arg == "--export-json" && i + 1 < argc) {
            exportJson = argv[++i];
        } else if (arg == "--export-webgl" && i + 1 < argc) {
            exportWebgl = argv[++i];
        } else if (arg == "--version") {
            showVersion = true;
        } else if (arg == "--help") {
            showHelp = true;
        }
    }

    // Show version
    if (showVersion) {
        std::cout << "Tamayo 2.5D v0.1.0" << std::endl;
        return 0;
    }

    // Show help
    if (showHelp) {
        std::cout << "Tamayo 2.5D - 2.5D Animation Engine" << std::endl;
        std::cout << std::endl;
        std::cout << "Usage:" << std::endl;
        std::cout << "  tamayo [options]" << std::endl;
        std::cout << std::endl;
        std::cout << "Options:" << std::endl;
        std::cout << "  --open <file>        Open a .tamayo project file" << std::endl;
        std::cout << "  --export-json <file> Export scene to JSON format" << std::endl;
        std::cout << "  --export-webgl <dir> Export scene to WebGL (HTML+JS)" << std::endl;
        std::cout << "  --version            Show version information" << std::endl;
        std::cout << "  --help               Show this help message" << std::endl;
        return 0;
    }

    // Initialize application
    app.initialize();

    // Open file if specified
    if (!openFile.empty()) {
        app.openScene(openFile);
    }

    // Export to JSON if specified
    if (!exportJson.empty()) {
        app.exportScene(exportJson, "json");
        return 0;
    }

    // Export to WebGL if specified
    if (!exportWebgl.empty()) {
        app.exportScene(exportWebgl, "webgl");
        return 0;
    }

    // Main loop (placeholder - would need actual windowing system)
    std::cout << "Tamayo 2.5D Editor" << std::endl;
    std::cout << "Press Ctrl+C to exit" << std::endl;

    // Simple main loop
    bool running = true;
    while (running) {
        // Update application
        app.update(1.0f / 60.0f);

        // In a real implementation, this would handle window events
        // For now, just break after a short time
        break;
    }

    // Shutdown
    app.shutdown();

    return 0;
}
