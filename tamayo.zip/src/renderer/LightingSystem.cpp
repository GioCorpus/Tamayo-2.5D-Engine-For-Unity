#include "tamayo/renderer/LightingSystem.h"
#include <algorithm>
#include <cmath>

namespace tamayo {

LightingSystem::LightingSystem() = default;

void LightingSystem::setAmbientColor(const Color& color) {
    ambientColor_ = color;
}

const Color& LightingSystem::getAmbientColor() const {
    return ambientColor_;
}

void LightingSystem::setAmbientIntensity(float intensity) {
    ambientIntensity_ = std::clamp(intensity, 0.0f, 1.0f);
}

float LightingSystem::getAmbientIntensity() const {
    return ambientIntensity_;
}

void LightingSystem::addPointLight(const PointLight& light) {
    pointLights_.push_back(light);
}

void LightingSystem::removePointLight(size_t index) {
    if (index < pointLights_.size()) {
        pointLights_.erase(pointLights_.begin() + index);
    }
}

void LightingSystem::clearPointLights() {
    pointLights_.clear();
}

const std::vector<PointLight>& LightingSystem::getPointLights() const {
    return pointLights_;
}

std::vector<PointLight>& LightingSystem::getPointLights() {
    return pointLights_;
}

Color LightingSystem::calculateLighting(const glm::vec2& position, float depth) const {
    // Start with ambient light
    Color result(
        ambientColor_.r * ambientIntensity_,
        ambientColor_.g * ambientIntensity_,
        ambientColor_.b * ambientIntensity_,
        1.0f
    );

    // Add point lights
    for (const auto& light : pointLights_) {
        glm::vec2 lightDir = light.position - position;
        float distance = glm::length(lightDir);

        if (distance > light.radius) {
            continue;
        }

        // Calculate distance attenuation
        float attenuation = 1.0f - (distance / light.radius);
        attenuation = std::pow(attenuation, light.falloff);

        // Calculate depth-based falloff
        float depthAttenuation = 1.0f / (1.0f + depth * depthFalloff_);

        // Add light contribution
        float intensity = light.intensity * attenuation * depthAttenuation;
        result.r += light.color.r * intensity;
        result.g += light.color.g * intensity;
        result.b += light.color.b * intensity;
    }

    // Clamp to valid range
    result.r = std::clamp(result.r, 0.0f, 1.0f);
    result.g = std::clamp(result.g, 0.0f, 1.0f);
    result.b = std::clamp(result.b, 0.0f, 1.0f);

    return result;
}

void LightingSystem::setDepthFalloff(float falloff) {
    depthFalloff_ = std::max(0.0f, falloff);
}

float LightingSystem::getDepthFalloff() const {
    return depthFalloff_;
}

} // namespace tamayo
