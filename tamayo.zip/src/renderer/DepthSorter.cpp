#include "tamayo/renderer/DepthSorter.h"
#include <algorithm>

namespace tamayo {

DepthSorter::DepthSorter() = default;

std::vector<std::shared_ptr<Layer>> DepthSorter::sort(
    const std::vector<std::shared_ptr<Layer>>& layers,
    bool frontToBack
) const {
    std::vector<std::shared_ptr<Layer>> sorted = layers;

    if (frontToBack) {
        std::sort(sorted.begin(), sorted.end(), compareFrontToBack);
    } else {
        std::sort(sorted.begin(), sorted.end(), compareBackToFront);
    }

    return sorted;
}

std::vector<std::shared_ptr<Layer>> DepthSorter::filterVisible(
    const std::vector<std::shared_ptr<Layer>>& layers
) const {
    std::vector<std::shared_ptr<Layer>> visible;
    visible.reserve(layers.size());

    for (const auto& layer : layers) {
        if (layer->isVisible()) {
            visible.push_back(layer);
        }
    }

    return visible;
}

std::vector<std::shared_ptr<Layer>> DepthSorter::sortAndFilter(
    const std::vector<std::shared_ptr<Layer>>& layers,
    bool frontToBack
) const {
    std::vector<std::shared_ptr<Layer>> result;
    result.reserve(layers.size());

    // Filter visible layers
    for (const auto& layer : layers) {
        if (layer->isVisible()) {
            result.push_back(layer);
        }
    }

    // Sort filtered layers
    if (frontToBack) {
        std::sort(result.begin(), result.end(), compareFrontToBack);
    } else {
        std::sort(result.begin(), result.end(), compareBackToFront);
    }

    return result;
}

bool DepthSorter::compareBackToFront(const std::shared_ptr<Layer>& a, const std::shared_ptr<Layer>& b) {
    // Higher z-depth = further back = render first
    return a->getZDepth() > b->getZDepth();
}

bool DepthSorter::compareFrontToBack(const std::shared_ptr<Layer>& a, const std::shared_ptr<Layer>& b) {
    // Lower z-depth = closer to front = render first
    return a->getZDepth() < b->getZDepth();
}

} // namespace tamayo
