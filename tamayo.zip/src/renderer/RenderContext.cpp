#include "tamayo/renderer/RenderContext.h"
#include <glm/gtc/matrix_transform.hpp>

namespace tamayo {

RenderContext::RenderContext() = default;

RenderContext::RenderContext(float canvasWidth, float canvasHeight)
    : canvasWidth_(canvasWidth), canvasHeight_(canvasHeight) {}

void RenderContext::setCanvasSize(float width, float height) {
    canvasWidth_ = width;
    canvasHeight_ = height;
}

float RenderContext::getCanvasWidth() const {
    return canvasWidth_;
}

float RenderContext::getCanvasHeight() const {
    return canvasHeight_;
}

std::vector<RenderCommand> RenderContext::buildRenderCommands(
    const Scene& scene,
    const LightingSystem& lighting,
    bool frontToBack
) const {
    std::vector<RenderCommand> commands;

    // Get sorted layers
    auto sortedLayers = getSortedLayers(scene, frontToBack);

    // Build render commands for each layer
    for (const auto& layer : sortedLayers) {
        if (!layer->isVisible()) {
            continue;
        }

        RenderCommand cmd;
        cmd.layer = layer;
        cmd.transform = calculateLayerTransform(*layer, glm::vec2(0.0f), 1.0f);
        cmd.blendMode = layer->getBlendMode();

        // Calculate lighting for layer center
        glm::vec2 layerCenter(
            layer->getTransform().getX() + layer->getContentWidth() * 0.5f,
            layer->getTransform().getY() + layer->getContentHeight() * 0.5f
        );
        cmd.color = lighting.calculateLighting(layerCenter, layer->getZDepth());

        commands.push_back(cmd);
    }

    return commands;
}

std::vector<std::shared_ptr<Layer>> RenderContext::getSortedLayers(
    const Scene& scene,
    bool frontToBack
) const {
    return depthSorter_.sortAndFilter(scene.getLayers(), frontToBack);
}

glm::mat4 RenderContext::calculateLayerTransform(
    const Layer& layer,
    const glm::vec2& cameraOffset,
    float cameraZoom
) const {
    // Get layer transform matrix
    glm::mat4 transform = layer.getTransform().getMatrix();

    // Apply camera offset and zoom
    transform = glm::translate(transform, glm::vec3(cameraOffset.x, cameraOffset.y, 0.0f));
    transform = glm::scale(transform, glm::vec3(cameraZoom, cameraZoom, 1.0f));

    return transform;
}

} // namespace tamayo
