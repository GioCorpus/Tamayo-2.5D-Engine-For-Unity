#include "tamayo/core/Scene.h"
#include <algorithm>

namespace tamayo {

SceneID Scene::nextID_ = 1;

Scene::Scene() : id_(nextID_++) {}

Scene::Scene(float width, float height) : id_(nextID_++), canvasWidth_(width), canvasHeight_(height) {}

void Scene::setCanvasSize(float width, float height) {
    canvasWidth_ = width;
    canvasHeight_ = height;
}

float Scene::getCanvasWidth() const {
    return canvasWidth_;
}

float Scene::getCanvasHeight() const {
    return canvasHeight_;
}

void Scene::setBackgroundColor(const Color& color) {
    backgroundColor_ = color;
}

const Color& Scene::getBackgroundColor() const {
    return backgroundColor_;
}

void Scene::addLayer(std::shared_ptr<Layer> layer) {
    layers_.push_back(layer);
}

void Scene::removeLayer(LayerID id) {
    auto it = std::remove_if(layers_.begin(), layers_.end(),
        [id](const std::shared_ptr<Layer>& layer) { return layer->getID() == id; });
    layers_.erase(it, layers_.end());
}

void Scene::moveLayer(LayerID id, int newIndex) {
    if (newIndex < 0 || newIndex >= static_cast<int>(layers_.size())) {
        return;
    }

    auto it = std::find_if(layers_.begin(), layers_.end(),
        [id](const std::shared_ptr<Layer>& layer) { return layer->getID() == id; });

    if (it != layers_.end()) {
        auto layer = *it;
        layers_.erase(it);
        layers_.insert(layers_.begin() + newIndex, layer);
    }
}

const std::vector<std::shared_ptr<Layer>>& Scene::getLayers() const {
    return layers_;
}

std::shared_ptr<Layer> Scene::findLayer(LayerID id) const {
    for (const auto& layer : layers_) {
        if (layer->getID() == id) {
            return layer;
        }
    }
    return nullptr;
}

void Scene::sortLayersByDepth(bool frontToBack) {
    if (frontToBack) {
        std::sort(layers_.begin(), layers_.end(),
            [](const std::shared_ptr<Layer>& a, const std::shared_ptr<Layer>& b) {
                return a->getZDepth() < b->getZDepth();
            });
    } else {
        std::sort(layers_.begin(), layers_.end(),
            [](const std::shared_ptr<Layer>& a, const std::shared_ptr<Layer>& b) {
                return a->getZDepth() > b->getZDepth();
            });
    }
}

std::vector<std::shared_ptr<Layer>> Scene::getSortedLayers(bool frontToBack) const {
    std::vector<std::shared_ptr<Layer>> sorted = layers_;
    if (frontToBack) {
        std::sort(sorted.begin(), sorted.end(),
            [](const std::shared_ptr<Layer>& a, const std::shared_ptr<Layer>& b) {
                return a->getZDepth() < b->getZDepth();
            });
    } else {
        std::sort(sorted.begin(), sorted.end(),
            [](const std::shared_ptr<Layer>& a, const std::shared_ptr<Layer>& b) {
                return a->getZDepth() > b->getZDepth();
            });
    }
    return sorted;
}

void Scene::setCurrentFrame(uint32_t frame) {
    currentFrame_ = clampFrame(frame);
}

uint32_t Scene::getCurrentFrame() const {
    return currentFrame_;
}

void Scene::setTotalFrames(uint32_t frames) {
    totalFrames_ = frames;
}

uint32_t Scene::getTotalFrames() const {
    return totalFrames_;
}

uint32_t Scene::clampFrame(uint32_t frame) const {
    if (totalFrames_ == 0) {
        return 0;
    }
    return std::min(frame, totalFrames_ - 1);
}

SceneID Scene::getID() const {
    return id_;
}

} // namespace tamayo
