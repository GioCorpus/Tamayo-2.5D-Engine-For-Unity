#include "tamayo/core/ParallaxEngine.h"
#include <algorithm>

namespace tamayo {

ParallaxEngine::ParallaxEngine() = default;

ParallaxEngine::ParallaxEngine(float canvasWidth, float canvasHeight)
    : canvasWidth_(canvasWidth), canvasHeight_(canvasHeight) {}

void ParallaxEngine::setCameraOffset(float x, float y) {
    cameraOffset_ = glm::vec2(x, y);
}

void ParallaxEngine::setCameraOffset(const glm::vec2& offset) {
    cameraOffset_ = offset;
}

glm::vec2 ParallaxEngine::getCameraOffset() const {
    return cameraOffset_;
}

void ParallaxEngine::setCameraZoom(float zoom) {
    cameraZoom_ = std::max(0.1f, zoom);
}

float ParallaxEngine::getCameraZoom() const {
    return cameraZoom_;
}

void ParallaxEngine::setDepthPlaneCount(uint32_t count) {
    depthPlaneCount_ = std::max(1u, count);
}

uint32_t ParallaxEngine::getDepthPlaneCount() const {
    return depthPlaneCount_;
}

void ParallaxEngine::applyParallax(std::vector<std::shared_ptr<Layer>>& layers) const {
    for (auto& layer : layers) {
        if (!layer->isVisible()) {
            continue;
        }

        float depth = layer->getZDepth();
        glm::vec2 offset = calculateDepthOffset(depth);
        float scale = calculateDepthScale(depth);

        // Apply parallax to layer transform
        Transform transform = layer->getTransform();
        glm::vec3 pos = transform.getPosition();
        pos.x += offset.x;
        pos.y += offset.y;
        transform.setPosition(pos);

        glm::vec2 currentScale = transform.getScale();
        transform.setScale(currentScale.x * scale, currentScale.y * scale);

        layer->setTransform(transform);
    }
}

glm::vec2 ParallaxEngine::calculateDepthOffset(float layerDepth) const {
    // Normalize depth to 0-1 range
    float normalizedDepth = (layerDepth - minDepth_) / (maxDepth_ - minDepth_);
    normalizedDepth = std::clamp(normalizedDepth, 0.0f, 1.0f);

    // Calculate parallax offset (deeper layers move less)
    float parallaxFactor = 1.0f - (normalizedDepth * parallaxStrength_);
    
    return glm::vec2(
        cameraOffset_.x * parallaxFactor,
        cameraOffset_.y * parallaxFactor
    );
}

float ParallaxEngine::calculateDepthScale(float layerDepth) const {
    // Normalize depth to 0-1 range
    float normalizedDepth = (layerDepth - minDepth_) / (maxDepth_ - minDepth_);
    normalizedDepth = std::clamp(normalizedDepth, 0.0f, 1.0f);

    // Calculate scale based on depth and zoom
    // Deeper layers scale less with zoom
    float depthScale = 1.0f - (normalizedDepth * 0.5f);
    return depthScale * cameraZoom_;
}

std::vector<float> ParallaxEngine::generateLayerDepths(uint32_t layerCount) const {
    std::vector<float> depths;
    depths.reserve(layerCount);

    if (layerCount == 0) {
        return depths;
    }

    if (layerCount == 1) {
        depths.push_back(0.5f);
        return depths;
    }

    // Distribute layers evenly across depth range
    float step = (maxDepth_ - minDepth_) / static_cast<float>(layerCount - 1);
    for (uint32_t i = 0; i < layerCount; ++i) {
        depths.push_back(minDepth_ + step * static_cast<float>(i));
    }

    return depths;
}

void ParallaxEngine::setCanvasSize(float width, float height) {
    canvasWidth_ = width;
    canvasHeight_ = height;
}

float ParallaxEngine::getCanvasWidth() const {
    return canvasWidth_;
}

float ParallaxEngine::getCanvasHeight() const {
    return canvasHeight_;
}

} // namespace tamayo
