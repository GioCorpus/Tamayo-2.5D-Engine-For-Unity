#include "tamayo/core/Keyframe.h"

namespace tamayo {

Keyframe::Keyframe() = default;

Keyframe::Keyframe(uint32_t frame, const Transform& transform)
    : frame_(frame), transform_(transform) {}

void Keyframe::setFrame(uint32_t frame) {
    frame_ = frame;
}

uint32_t Keyframe::getFrame() const {
    return frame_;
}

void Keyframe::setTransform(const Transform& transform) {
    transform_ = transform;
}

const Transform& Keyframe::getTransform() const {
    return transform_;
}

Transform& Keyframe::getTransform() {
    return transform_;
}

void Keyframe::setInterpolation(InterpolationType type) {
    interpolation_ = type;
}

InterpolationType Keyframe::getInterpolation() const {
    return interpolation_;
}

void Keyframe::setBezierHandles(const glm::vec2& in, const glm::vec2& out) {
    bezierIn_ = in;
    bezierOut_ = out;
}

glm::vec2 Keyframe::getBezierIn() const {
    return bezierIn_;
}

glm::vec2 Keyframe::getBezierOut() const {
    return bezierOut_;
}

bool Keyframe::operator<(const Keyframe& other) const {
    return frame_ < other.frame_;
}

bool Keyframe::operator==(const Keyframe& other) const {
    return frame_ == other.frame_ && transform_ == other.transform_;
}

bool Keyframe::operator!=(const Keyframe& other) const {
    return !(*this == other);
}

} // namespace tamayo
