#include "tamayo/core/Layer.h"
#include <algorithm>

namespace tamayo {

LayerID Layer::nextID_ = 1;

Layer::Layer() : id_(nextID_++) {}

Layer::Layer(const std::string& name) : id_(nextID_++), name_(name) {}

void Layer::setName(const std::string& name) {
    name_ = name;
}

const std::string& Layer::getName() const {
    return name_;
}

void Layer::setVisible(bool visible) {
    visible_ = visible;
}

bool Layer::isVisible() const {
    return visible_;
}

void Layer::setZDepth(float depth) {
    zDepth_ = depth;
}

float Layer::getZDepth() const {
    return zDepth_;
}

void Layer::setBlendMode(BlendMode mode) {
    blendMode_ = mode;
}

BlendMode Layer::getBlendMode() const {
    return blendMode_;
}

void Layer::setImagePath(const std::string& path) {
    imagePath_ = path;
}

const std::string& Layer::getImagePath() const {
    return imagePath_;
}

void Layer::setContentSize(float width, float height) {
    contentWidth_ = width;
    contentHeight_ = height;
}

float Layer::getContentWidth() const {
    return contentWidth_;
}

float Layer::getContentHeight() const {
    return contentHeight_;
}

void Layer::setTransform(const Transform& transform) {
    transform_ = transform;
}

const Transform& Layer::getTransform() const {
    return transform_;
}

Transform& Layer::getTransform() {
    return transform_;
}

void Layer::setTimeline(const Timeline& timeline) {
    timeline_ = timeline;
}

const Timeline& Layer::getTimeline() const {
    return timeline_;
}

Timeline& Layer::getTimeline() {
    return timeline_;
}

void Layer::addChild(std::shared_ptr<Layer> child) {
    children_.push_back(child);
}

void Layer::removeChild(LayerID id) {
    auto it = std::remove_if(children_.begin(), children_.end(),
        [id](const std::shared_ptr<Layer>& child) { return child->getID() == id; });
    children_.erase(it, children_.end());
}

const std::vector<std::shared_ptr<Layer>>& Layer::getChildren() const {
    return children_;
}

std::shared_ptr<Layer> Layer::findChild(LayerID id) const {
    for (const auto& child : children_) {
        if (child->getID() == id) {
            return child;
        }
        // Recursively search children
        auto found = child->findChild(id);
        if (found) {
            return found;
        }
    }
    return nullptr;
}

LayerID Layer::getID() const {
    return id_;
}

} // namespace tamayo
