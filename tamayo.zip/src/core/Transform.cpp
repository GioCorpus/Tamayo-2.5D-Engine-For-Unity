#include "tamayo/core/Transform.h"
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/quaternion.hpp>
#include <cmath>

namespace tamayo {

Transform::Transform() = default;

Transform::Transform(float x, float y, float z) : position_(x, y, z) {}

void Transform::setPosition(float x, float y, float z) {
    position_ = glm::vec3(x, y, z);
}

void Transform::setPosition(const glm::vec3& position) {
    position_ = position;
}

glm::vec3 Transform::getPosition() const {
    return position_;
}

void Transform::setScale(float sx, float sy) {
    scale_ = glm::vec2(sx, sy);
}

void Transform::setScale(const glm::vec2& scale) {
    scale_ = scale;
}

glm::vec2 Transform::getScale() const {
    return scale_;
}

void Transform::setRotation(float degrees) {
    rotation_ = degrees;
}

float Transform::getRotation() const {
    return rotation_;
}

void Transform::setAlpha(float alpha) {
    alpha_ = std::clamp(alpha, 0.0f, 1.0f);
}

float Transform::getAlpha() const {
    return alpha_;
}

void Transform::setAnchor(float ax, float ay) {
    anchor_ = glm::vec2(ax, ay);
}

void Transform::setAnchor(const glm::vec2& anchor) {
    anchor_ = anchor;
}

glm::vec2 Transform::getAnchor() const {
    return anchor_;
}

glm::mat4 Transform::getMatrix() const {
    glm::mat4 matrix = glm::mat4(1.0f);

    // Translate to anchor point
    matrix = glm::translate(matrix, glm::vec3(anchor_.x, anchor_.y, 0.0f));

    // Apply transformations
    matrix = glm::translate(matrix, position_);
    matrix = glm::rotate(matrix, glm::radians(rotation_), glm::vec3(0.0f, 0.0f, 1.0f));
    matrix = glm::scale(matrix, glm::vec3(scale_.x, scale_.y, 1.0f));

    // Translate back from anchor point
    matrix = glm::translate(matrix, glm::vec3(-anchor_.x, -anchor_.y, 0.0f));

    return matrix;
}

Transform Transform::lerp(const Transform& a, const Transform& b, float t) {
    Transform result;

    // Linearly interpolate position
    result.position_ = glm::mix(a.position_, b.position_, t);

    // Linearly interpolate scale
    result.scale_ = glm::mix(a.scale_, b.scale_, t);

    // Linearly interpolate rotation
    result.rotation_ = a.rotation_ + (b.rotation_ - a.rotation_) * t;

    // Linearly interpolate alpha
    result.alpha_ = a.alpha_ + (b.alpha_ - a.alpha_) * t;

    // Linearly interpolate anchor
    result.anchor_ = glm::mix(a.anchor_, b.anchor_, t);

    return result;
}

bool Transform::operator==(const Transform& other) const {
    const float epsilon = 1e-6f;
    return glm::all(glm::epsilonEqual(position_, other.position_, epsilon)) &&
           glm::all(glm::epsilonEqual(scale_, other.scale_, epsilon)) &&
           std::abs(rotation_ - other.rotation_) < epsilon &&
           std::abs(alpha_ - other.alpha_) < epsilon &&
           glm::all(glm::epsilonEqual(anchor_, other.anchor_, epsilon));
}

bool Transform::operator!=(const Transform& other) const {
    return !(*this == other);
}

} // namespace tamayo
