#include "tamayo/core/Timeline.h"
#include <algorithm>
#include <cmath>

namespace tamayo {

Timeline::Timeline() = default;

void Timeline::addKeyframe(const Keyframe& keyframe) {
    // Remove existing keyframe at the same frame if it exists
    removeKeyframe(keyframe.getFrame());
    keyframes_.push_back(keyframe);
    sorted_ = false;
}

void Timeline::removeKeyframe(uint32_t frame) {
    auto it = std::remove_if(keyframes_.begin(), keyframes_.end(),
        [frame](const Keyframe& kf) { return kf.getFrame() == frame; });
    
    if (it != keyframes_.end()) {
        keyframes_.erase(it, keyframes_.end());
    }
}

void Timeline::clearKeyframes() {
    keyframes_.clear();
    sorted_ = false;
}

const std::vector<Keyframe>& Timeline::getKeyframes() const {
    ensureSorted();
    return keyframes_;
}

std::optional<Keyframe> Timeline::getKeyframeAt(uint32_t frame) const {
    ensureSorted();
    for (const auto& kf : keyframes_) {
        if (kf.getFrame() == frame) {
            return kf;
        }
    }
    return std::nullopt;
}

bool Timeline::hasKeyframeAt(uint32_t frame) const {
    return getKeyframeAt(frame).has_value();
}

Transform Timeline::evaluate(uint32_t frame) const {
    ensureSorted();

    if (keyframes_.empty()) {
        return Transform();
    }

    // If frame is before first keyframe, return first keyframe's transform
    if (frame <= keyframes_.front().getFrame()) {
        return keyframes_.front().getTransform();
    }

    // If frame is after last keyframe, return last keyframe's transform
    if (frame >= keyframes_.back().getFrame()) {
        return keyframes_.back().getTransform();
    }

    // Find surrounding keyframes
    const Keyframe* prev = nullptr;
    const Keyframe* next = nullptr;

    for (size_t i = 0; i < keyframes_.size(); ++i) {
        if (keyframes_[i].getFrame() >= frame) {
            if (i > 0) {
                prev = &keyframes_[i - 1];
            }
            next = &keyframes_[i];
            break;
        }
    }

    if (!prev || !next) {
        return keyframes_.front().getTransform();
    }

    // Calculate interpolation factor
    float t = static_cast<float>(frame - prev->getFrame()) /
              static_cast<float>(next->getFrame() - prev->getFrame());

    // Apply interpolation based on type
    switch (next->getInterpolation()) {
        case InterpolationType::Step:
            return prev->getTransform();
        
        case InterpolationType::EaseIn:
            t = t * t;
            break;
        
        case InterpolationType::EaseOut:
            t = 1.0f - (1.0f - t) * (1.0f - t);
            break;
        
        case InterpolationType::CubicBezier:
            // Simplified cubic bezier (would need proper bezier evaluation)
            t = t * t * (3.0f - 2.0f * t);
            break;
        
        case InterpolationType::Linear:
        default:
            // t is already linear
            break;
    }

    return Transform::lerp(prev->getTransform(), next->getTransform(), t);
}

Transform Timeline::evaluate(float time, float fps) const {
    uint32_t frame = timeToFrame(time, fps);
    return evaluate(frame);
}

uint32_t Timeline::timeToFrame(float time, float fps) const {
    return static_cast<uint32_t>(std::round(time * fps));
}

float Timeline::frameToTime(uint32_t frame, float fps) const {
    return static_cast<float>(frame) / fps;
}

std::optional<Keyframe> Timeline::getPreviousKeyframe(uint32_t frame) const {
    ensureSorted();
    for (int i = static_cast<int>(keyframes_.size()) - 1; i >= 0; --i) {
        if (keyframes_[i].getFrame() < frame) {
            return keyframes_[i];
        }
    }
    return std::nullopt;
}

std::optional<Keyframe> Timeline::getNextKeyframe(uint32_t frame) const {
    ensureSorted();
    for (const auto& kf : keyframes_) {
        if (kf.getFrame() > frame) {
            return kf;
        }
    }
    return std::nullopt;
}

uint32_t Timeline::getStartFrame() const {
    if (keyframes_.empty()) {
        return 0;
    }
    ensureSorted();
    return keyframes_.front().getFrame();
}

uint32_t Timeline::getEndFrame() const {
    if (keyframes_.empty()) {
        return 0;
    }
    ensureSorted();
    return keyframes_.back().getFrame();
}

bool Timeline::isEmpty() const {
    return keyframes_.empty();
}

void Timeline::ensureSorted() const {
    if (!sorted_) {
        std::sort(keyframes_.begin(), keyframes_.end());
        sorted_ = true;
    }
}

} // namespace tamayo
