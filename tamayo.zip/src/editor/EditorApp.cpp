#include "tamayo/editor/EditorApp.h"
#include "tamayo/io/ProjectFile.h"
#include "tamayo/io/JsonExporter.h"
#include "tamayo/io/WebGLExporter.h"
#include <iostream>

namespace tamayo {

EditorApp::EditorApp() = default;

void EditorApp::initialize() {
    // Create default scene
    newScene();
}

void EditorApp::shutdown() {
    currentScene_.reset();
}

void EditorApp::update(float deltaTime) {
    if (playing_ && currentScene_) {
        playbackTime_ += deltaTime;
        uint32_t frame = static_cast<uint32_t>(playbackTime_ * fps_);
        
        if (frame >= currentScene_->getTotalFrames()) {
            // Loop back to start
            playbackTime_ = 0.0f;
            frame = 0;
        }
        
        currentScene_->setCurrentFrame(frame);
    }
}

void EditorApp::newScene(float width, float height) {
    currentScene_ = std::make_shared<Scene>(width, height);
    playing_ = false;
    playbackTime_ = 0.0f;
}

void EditorApp::openScene(const std::string& filePath) {
    ProjectFile projectFile;
    auto scene = projectFile.load(filePath);
    if (scene) {
        currentScene_ = scene;
        playing_ = false;
        playbackTime_ = 0.0f;
        std::cout << "Scene loaded: " << filePath << std::endl;
    } else {
        std::cerr << "Failed to load scene: " << filePath << std::endl;
    }
}

void EditorApp::saveScene(const std::string& filePath) {
    if (!currentScene_) {
        std::cerr << "No scene to save" << std::endl;
        return;
    }

    ProjectFile projectFile;
    if (projectFile.save(*currentScene_, filePath)) {
        std::cout << "Scene saved: " << filePath << std::endl;
    } else {
        std::cerr << "Failed to save scene: " << filePath << std::endl;
    }
}

void EditorApp::exportScene(const std::string& filePath, const std::string& format) {
    if (!currentScene_) {
        std::cerr << "No scene to export" << std::endl;
        return;
    }

    if (format == "json") {
        JsonExporter jsonExporter;
        if (jsonExporter.exportToFile(*currentScene_, filePath)) {
            std::cout << "Scene exported to JSON: " << filePath << std::endl;
        } else {
            std::cerr << "Failed to export scene to JSON: " << filePath << std::endl;
        }
    } else if (format == "webgl") {
        WebGLExporter webglExporter;
        if (webglExporter.exportToFile(*currentScene_, filePath)) {
            std::cout << "Scene exported to WebGL: " << filePath << std::endl;
        } else {
            std::cerr << "Failed to export scene to WebGL: " << filePath << std::endl;
        }
    } else {
        std::cerr << "Unknown export format: " << format << std::endl;
    }
}

void EditorApp::play() {
    playing_ = true;
}

void EditorApp::pause() {
    playing_ = false;
}

void EditorApp::stop() {
    playing_ = false;
    playbackTime_ = 0.0f;
    if (currentScene_) {
        currentScene_->setCurrentFrame(0);
    }
}

void EditorApp::goToFrame(uint32_t frame) {
    if (currentScene_) {
        currentScene_->setCurrentFrame(frame);
        playbackTime_ = static_cast<float>(frame) / fps_;
    }
}

void EditorApp::nextFrame() {
    if (currentScene_) {
        uint32_t frame = currentScene_->getCurrentFrame() + 1;
        if (frame >= currentScene_->getTotalFrames()) {
            frame = 0;
        }
        goToFrame(frame);
    }
}

void EditorApp::prevFrame() {
    if (currentScene_) {
        uint32_t frame = currentScene_->getCurrentFrame();
        if (frame > 0) {
            frame--;
        } else {
            frame = currentScene_->getTotalFrames() - 1;
        }
        goToFrame(frame);
    }
}

std::shared_ptr<Scene> EditorApp::getCurrentScene() const {
    return currentScene_;
}

uint32_t EditorApp::getCurrentFrame() const {
    if (currentScene_) {
        return currentScene_->getCurrentFrame();
    }
    return 0;
}

bool EditorApp::isPlaying() const {
    return playing_;
}

} // namespace tamayo
