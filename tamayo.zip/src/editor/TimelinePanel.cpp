#include "tamayo/editor/TimelinePanel.h"
#include <algorithm>

namespace tamayo {

TimelinePanel::TimelinePanel() = default;

void TimelinePanel::setScene(std::shared_ptr<Scene> scene) {
    scene_ = scene;
}

uint32_t TimelinePanel::positionToFrame(float x, float panelWidth) const {
    if (!scene_ || panelWidth <= 0.0f) {
        return 0;
    }

    float visibleFrames = scene_->getTotalFrames() / zoom_;
    float frameWidth = panelWidth / visibleFrames;
    float frame = (x + scroll_) / frameWidth;

    return static_cast<uint32_t>(std::clamp(frame, 0.0f, static_cast<float>(scene_->getTotalFrames() - 1)));
}

float TimelinePanel::frameToPosition(uint32_t frame, float panelWidth) const {
    if (!scene_ || panelWidth <= 0.0f) {
        return 0.0f;
    }

    float visibleFrames = scene_->getTotalFrames() / zoom_;
    float frameWidth = panelWidth / visibleFrames;
    return frame * frameWidth - scroll_;
}

void TimelinePanel::setZoom(float zoom) {
    zoom_ = std::clamp(zoom, 0.1f, 10.0f);
}

float TimelinePanel::getZoom() const {
    return zoom_;
}

void TimelinePanel::setScroll(float scroll) {
    scroll_ = scroll;
}

float TimelinePanel::getScroll() const {
    return scroll_;
}

void TimelinePanel::setSelectedLayer(LayerID layerId) {
    selectedLayer_ = layerId;
    if (layerSelectedCallback_) {
        layerSelectedCallback_(layerId);
    }
}

LayerID TimelinePanel::getSelectedLayer() const {
    return selectedLayer_;
}

void TimelinePanel::setFrameSelectedCallback(FrameSelectedCallback callback) {
    frameSelectedCallback_ = callback;
}

void TimelinePanel::setLayerSelectedCallback(LayerSelectedCallback callback) {
    layerSelectedCallback_ = callback;
}

void TimelinePanel::update(float deltaTime) {
    // Update logic if needed
}

} // namespace tamayo
