#include "tamayo/editor/LayerPanel.h"

namespace tamayo {

LayerPanel::LayerPanel() = default;

void LayerPanel::setScene(std::shared_ptr<Scene> scene) {
    scene_ = scene;
}

void LayerPanel::setSelectedLayer(LayerID layerId) {
    selectedLayer_ = layerId;
    if (layerSelectedCallback_) {
        layerSelectedCallback_(layerId);
    }
}

LayerID LayerPanel::getSelectedLayer() const {
    return selectedLayer_;
}

void LayerPanel::setLayerSelectedCallback(LayerSelectedCallback callback) {
    layerSelectedCallback_ = callback;
}

void LayerPanel::setVisibilityChangedCallback(VisibilityChangedCallback callback) {
    visibilityChangedCallback_ = callback;
}

void LayerPanel::update(float deltaTime) {
    // Update logic if needed
}

} // namespace tamayo
