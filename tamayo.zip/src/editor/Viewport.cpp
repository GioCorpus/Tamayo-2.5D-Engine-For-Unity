#include "tamayo/editor/Viewport.h"
#include <algorithm>

namespace tamayo {

Viewport::Viewport() = default;

Viewport::Viewport(float width, float height) : width_(width), height_(height) {}

void Viewport::setScene(std::shared_ptr<Scene> scene) {
    scene_ = scene;
}

void Viewport::setSize(float width, float height) {
    width_ = width;
    height_ = height;
}

float Viewport::getWidth() const {
    return width_;
}

float Viewport::getHeight() const {
    return height_;
}

void Viewport::setCameraOffset(float x, float y) {
    cameraOffset_ = glm::vec2(x, y);
}

void Viewport::setCameraOffset(const glm::vec2& offset) {
    cameraOffset_ = offset;
}

glm::vec2 Viewport::getCameraOffset() const {
    return cameraOffset_;
}

void Viewport::setCameraZoom(float zoom) {
    cameraZoom_ = std::clamp(zoom, 0.1f, 10.0f);
}

float Viewport::getCameraZoom() const {
    return cameraZoom_;
}

glm::vec2 Viewport::screenToWorld(const glm::vec2& screenPos) const {
    // Convert screen coordinates to world coordinates
    glm::vec2 worldPos;
    worldPos.x = (screenPos.x - width_ * 0.5f) / cameraZoom_ + cameraOffset_.x;
    worldPos.y = (screenPos.y - height_ * 0.5f) / cameraZoom_ + cameraOffset_.y;
    return worldPos;
}

glm::vec2 Viewport::worldToScreen(const glm::vec2& worldPos) const {
    // Convert world coordinates to screen coordinates
    glm::vec2 screenPos;
    screenPos.x = (worldPos.x - cameraOffset_.x) * cameraZoom_ + width_ * 0.5f;
    screenPos.y = (worldPos.y - cameraOffset_.y) * cameraZoom_ + height_ * 0.5f;
    return screenPos;
}

void Viewport::pan(float dx, float dy) {
    cameraOffset_.x += dx / cameraZoom_;
    cameraOffset_.y += dy / cameraZoom_;
}

void Viewport::zoom(float factor, const glm::vec2& center) {
    float oldZoom = cameraZoom_;
    cameraZoom_ = std::clamp(cameraZoom_ * factor, 0.1f, 10.0f);

    // Adjust camera offset to zoom towards center
    float zoomRatio = cameraZoom_ / oldZoom;
    cameraOffset_.x = center.x - (center.x - cameraOffset_.x) * zoomRatio;
    cameraOffset_.y = center.y - (center.y - cameraOffset_.y) * zoomRatio;
}

void Viewport::update(float deltaTime) {
    // Update logic if needed
}

} // namespace tamayo
