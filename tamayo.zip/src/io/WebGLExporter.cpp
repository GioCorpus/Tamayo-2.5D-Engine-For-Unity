#include "tamayo/io/WebGLExporter.h"
#include "tamayo/io/JsonExporter.h"
#include <filesystem>
#include <fstream>

namespace tamayo {

WebGLExporter::WebGLExporter() = default;

bool WebGLExporter::exportToFile(const Scene& scene, const std::string& outputDir) const {
    // Create output directory if it doesn't exist
    std::filesystem::create_directories(outputDir);

    // Write HTML file
    std::ofstream htmlFile(outputDir + "/index.html");
    if (!htmlFile.is_open()) {
        return false;
    }
    htmlFile << generateHtml(scene);
    htmlFile.close();

    // Write JavaScript file
    std::ofstream jsFile(outputDir + "/scene.js");
    if (!jsFile.is_open()) {
        return false;
    }
    jsFile << generateJavaScript(scene);
    jsFile.close();

    // Write JSON data file
    std::ofstream jsonFile(outputDir + "/scene.json");
    if (!jsonFile.is_open()) {
        return false;
    }
    jsonFile << generateJsonData(scene);
    jsonFile.close();

    return true;
}

std::string WebGLExporter::exportToString(const Scene& scene) const {
    return generateHtml(scene);
}

std::string WebGLExporter::generateHtml(const Scene& scene) const {
    std::string html = R"(<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tamayo 2.5D - WebGL Preview</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background-color: #000;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        canvas {
            border: 1px solid #333;
        }
    </style>
</head>
<body>
    <canvas id="canvas" width=")" + std::to_string(static_cast<int>(scene.getCanvasWidth())) + R"(" height=")" + std::to_string(static_cast<int>(scene.getCanvasHeight())) + R"("></canvas>
    <script src="scene.js"></script>
</body>
</html>)";

    return html;
}

std::string WebGLExporter::generateJavaScript(const Scene& scene) const {
    std::string js = R"(// Tamayo 2.5D WebGL Preview
const canvas = document.getElementById('canvas');
const gl = canvas.getContext('webgl');

if (!gl) {
    alert('WebGL not supported');
    throw new Error('WebGL not supported');
}

// Vertex shader
const vertexShaderSource = `
    attribute vec2 a_position;
    attribute vec2 a_texCoord;
    uniform mat3 u_matrix;
    varying vec2 v_texCoord;
    void main() {
        gl_Position = vec4((u_matrix * vec3(a_position, 1.0)).xy, 0.0, 1.0);
        v_texCoord = a_texCoord;
    }
`;

// Fragment shader
const fragmentShaderSource = `
    precision mediump float;
    varying vec2 v_texCoord;
    uniform sampler2D u_texture;
    uniform vec4 u_color;
    void main() {
        gl_FragColor = texture2D(u_texture, v_texCoord) * u_color;
    }
`;

// Compile shader
function compileShader(gl, source, type) {
    const shader = gl.createShader(type);
    gl.shaderSource(shader, source);
    gl.compileShader(shader);
    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
        console.error('Shader compile error:', gl.getShaderInfoLog(shader));
        gl.deleteShader(shader);
        return null;
    }
    return shader;
}

// Create program
function createProgram(gl, vertexShader, fragmentShader) {
    const program = gl.createProgram();
    gl.attachShader(program, vertexShader);
    gl.attachShader(program, fragmentShader);
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
        console.error('Program link error:', gl.getProgramInfoLog(program));
        gl.deleteProgram(program);
        return null;
    }
    return program;
}

// Initialize shaders
const vertexShader = compileShader(gl, vertexShaderSource, gl.VERTEX_SHADER);
const fragmentShader = compileShader(gl, fragmentShaderSource, gl.FRAGMENT_SHADER);
const program = createProgram(gl, vertexShader, fragmentShader);

// Get attribute and uniform locations
const positionLocation = gl.getAttribLocation(program, 'a_position');
const texCoordLocation = gl.getAttribLocation(program, 'a_texCoord');
const matrixLocation = gl.getUniformLocation(program, 'u_matrix');
const colorLocation = gl.getUniformLocation(program, 'u_color');

// Create buffers
const positionBuffer = gl.createBuffer();
const texCoordBuffer = gl.createBuffer();

// Set up geometry
const positions = new Float32Array([
    0, 0,
    1, 0,
    0, 1,
    0, 1,
    1, 0,
    1, 1,
]);

const texCoords = new Float32Array([
    0, 0,
    1, 0,
    0, 1,
    0, 1,
    1, 0,
    1, 1,
]);

gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
gl.bufferData(gl.ARRAY_BUFFER, positions, gl.STATIC_DRAW);

gl.bindBuffer(gl.ARRAY_BUFFER, texCoordBuffer);
gl.bufferData(gl.ARRAY_BUFFER, texCoords, gl.STATIC_DRAW);

// Load scene data
let sceneData = null;
fetch('scene.json')
    .then(response => response.json())
    .then(data => {
        sceneData = data;
        render();
    })
    .catch(error => {
        console.error('Error loading scene:', error);
    });

// Render function
function render() {
    if (!sceneData) return;

    gl.clearColor(0.0, 0.0, 0.0, 1.0);
    gl.clear(gl.COLOR_BUFFER_BIT);

    gl.useProgram(program);

    // Set up attributes
    gl.enableVertexAttribArray(positionLocation);
    gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
    gl.vertexAttribPointer(positionLocation, 2, gl.FLOAT, false, 0, 0);

    gl.enableVertexAttribArray(texCoordLocation);
    gl.bindBuffer(gl.ARRAY_BUFFER, texCoordBuffer);
    gl.vertexAttribPointer(texCoordLocation, 2, gl.FLOAT, false, 0, 0);

    // Render layers
    for (const layer of sceneData.layers) {
        if (!layer.visible) continue;

        // Create identity matrix
        const matrix = [
            1, 0, 0,
            0, 1, 0,
            0, 0, 1
        ];

        gl.uniformMatrix3fv(matrixLocation, false, matrix);
        gl.uniform4f(colorLocation, 1.0, 1.0, 1.0, 1.0);

        gl.drawArrays(gl.TRIANGLES, 0, 6);
    }
}

// Animation loop
function animate() {
    render();
    requestAnimationFrame(animate);
}

animate();
)";

    return js;
}

std::string WebGLExporter::generateJsonData(const Scene& scene) const {
    JsonExporter jsonExporter;
    return jsonExporter.exportToString(scene, false);
}

std::string WebGLExporter::generateVertexShader() const {
    return R"(
        attribute vec2 a_position;
        attribute vec2 a_texCoord;
        uniform mat3 u_matrix;
        varying vec2 v_texCoord;
        void main() {
            gl_Position = vec4((u_matrix * vec3(a_position, 1.0)).xy, 0.0, 1.0);
            v_texCoord = a_texCoord;
        }
    )";
}

std::string WebGLExporter::generateFragmentShader() const {
    return R"(
        precision mediump float;
        varying vec2 v_texCoord;
        uniform sampler2D u_texture;
        uniform vec4 u_color;
        void main() {
            gl_FragColor = texture2D(u_texture, v_texCoord) * u_color;
        }
    )";
}

} // namespace tamayo
