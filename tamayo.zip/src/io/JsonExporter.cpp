#include "tamayo/io/JsonExporter.h"
#include <fstream>

namespace tamayo {

JsonExporter::JsonExporter() = default;

nlohmann::json JsonExporter::exportScene(const Scene& scene, bool includeMetadata) const {
    nlohmann::json json;

    // Scene info
    json["canvasWidth"] = scene.getCanvasWidth();
    json["canvasHeight"] = scene.getCanvasHeight();
    json["backgroundColor"] = {
        {"r", scene.getBackgroundColor().r},
        {"g", scene.getBackgroundColor().g},
        {"b", scene.getBackgroundColor().b},
        {"a", scene.getBackgroundColor().a}
    };
    json["currentFrame"] = scene.getCurrentFrame();
    json["totalFrames"] = scene.getTotalFrames();

    // Layers
    json["layers"] = nlohmann::json::array();
    for (const auto& layer : scene.getLayers()) {
        json["layers"].push_back(exportLayer(*layer));
    }

    // Metadata
    if (includeMetadata) {
        json["metadata"] = {
            {"version", "1.0"},
            {"generator", "Tamayo 2.5D"},
            {"format", "scene"}
        };
    }

    return json;
}

bool JsonExporter::exportToFile(const Scene& scene, const std::string& filePath, bool includeMetadata) const {
    std::ofstream file(filePath);
    if (!file.is_open()) {
        return false;
    }

    file << exportScene(scene, includeMetadata).dump(4);
    return true;
}

std::string JsonExporter::exportToString(const Scene& scene, bool includeMetadata) const {
    return exportScene(scene, includeMetadata).dump(4);
}

nlohmann::json JsonExporter::exportLayer(const Layer& layer) const {
    nlohmann::json json;

    json["id"] = layer.getID();
    json["name"] = layer.getName();
    json["visible"] = layer.isVisible();
    json["zDepth"] = layer.getZDepth();
    json["blendMode"] = static_cast<int>(layer.getBlendMode());
    json["imagePath"] = layer.getImagePath();
    json["contentWidth"] = layer.getContentWidth();
    json["contentHeight"] = layer.getContentHeight();
    json["transform"] = exportTransform(layer.getTransform());
    json["timeline"] = exportTimeline(layer.getTimeline());

    // Children
    json["children"] = nlohmann::json::array();
    for (const auto& child : layer.getChildren()) {
        json["children"].push_back(exportLayer(*child));
    }

    return json;
}

nlohmann::json JsonExporter::exportTransform(const Transform& transform) const {
    nlohmann::json json;

    json["position"] = {
        {"x", transform.getX()},
        {"y", transform.getY()},
        {"z", transform.getZ()}
    };
    json["scale"] = {
        {"sx", transform.getSX()},
        {"sy", transform.getSY()}
    };
    json["rotation"] = transform.getRotation();
    json["alpha"] = transform.getAlpha();
    json["anchor"] = {
        {"ax", transform.getAnchor().x},
        {"ay", transform.getAnchor().y}
    };

    return json;
}

nlohmann::json JsonExporter::exportTimeline(const Timeline& timeline) const {
    nlohmann::json json;

    json["keyframes"] = nlohmann::json::array();
    for (const auto& keyframe : timeline.getKeyframes()) {
        json["keyframes"].push_back(exportKeyframe(keyframe));
    }

    return json;
}

nlohmann::json JsonExporter::exportKeyframe(const Keyframe& keyframe) const {
    nlohmann::json json;

    json["frame"] = keyframe.getFrame();
    json["interpolation"] = static_cast<int>(keyframe.getInterpolation());
    json["transform"] = exportTransform(keyframe.getTransform());
    json["bezierIn"] = {
        {"x", keyframe.getBezierIn().x},
        {"y", keyframe.getBezierIn().y}
    };
    json["bezierOut"] = {
        {"x", keyframe.getBezierOut().x},
        {"y", keyframe.getBezierOut().y}
    };

    return json;
}

} // namespace tamayo
