#include "tamayo/io/PngImporter.h"
#include <filesystem>
#include <algorithm>
#include <regex>

namespace tamayo {

PngImporter::PngImporter() = default;

std::shared_ptr<Layer> PngImporter::importFile(const std::string& filePath) const {
    if (!std::filesystem::exists(filePath)) {
        return nullptr;
    }

    auto layer = std::make_shared<Layer>(std::filesystem::path(filePath).stem().string());
    layer->setImagePath(filePath);

    // Get image dimensions
    int width, height;
    if (getImageDimensions(filePath, width, height)) {
        layer->setContentSize(static_cast<float>(width), static_cast<float>(height));
    }

    return layer;
}

std::vector<std::shared_ptr<Layer>> PngImporter::importSequence(
    const std::string& directory,
    const std::string& prefix,
    const std::string& suffix
) const {
    std::vector<std::shared_ptr<Layer>> layers;

    if (!std::filesystem::exists(directory)) {
        return layers;
    }

    // Find all PNG files
    auto pngFiles = findPngFiles(directory);

    // Filter by prefix and suffix
    std::vector<std::string> filteredFiles;
    for (const auto& file : pngFiles) {
        std::string filename = std::filesystem::path(file).filename().string();
        if (filename.find(prefix) == 0 && filename.find(suffix) != std::string::npos) {
            filteredFiles.push_back(file);
        }
    }

    // Sort by frame number
    std::sort(filteredFiles.begin(), filteredFiles.end(),
        [this](const std::string& a, const std::string& b) {
            return extractFrameNumber(a) < extractFrameNumber(b);
        });

    // Create layers
    for (const auto& file : filteredFiles) {
        auto layer = importFile(file);
        if (layer) {
            layers.push_back(layer);
        }
    }

    return layers;
}

std::vector<std::shared_ptr<Layer>> PngImporter::importDirectory(const std::string& directory) const {
    std::vector<std::shared_ptr<Layer>> layers;

    if (!std::filesystem::exists(directory)) {
        return layers;
    }

    // Find all PNG files
    auto pngFiles = findPngFiles(directory);

    // Create layers
    for (const auto& file : pngFiles) {
        auto layer = importFile(file);
        if (layer) {
            layers.push_back(layer);
        }
    }

    return layers;
}

bool PngImporter::getImageDimensions(const std::string& filePath, int& width, int& height) const {
    // This is a placeholder implementation
    // In a real implementation, you would use a library like stb_image or libpng
    // to read the PNG file header and extract dimensions
    
    // For now, return default dimensions
    width = 1920;
    height = 1080;
    return true;
}

std::vector<std::string> PngImporter::findPngFiles(const std::string& directory) const {
    std::vector<std::string> pngFiles;

    for (const auto& entry : std::filesystem::directory_iterator(directory)) {
        if (entry.is_regular_file()) {
            std::string extension = entry.path().extension().string();
            std::transform(extension.begin(), extension.end(), extension.begin(), ::tolower);
            if (extension == ".png") {
                pngFiles.push_back(entry.path().string());
            }
        }
    }

    return pngFiles;
}

int PngImporter::extractFrameNumber(const std::string& filename) const {
    // Try to extract frame number from filename
    // Common patterns: frame_001.png, frame001.png, 001.png, etc.
    std::regex frameRegex(R"((\d+))");
    std::smatch match;

    if (std::regex_search(filename, match, frameRegex)) {
        return std::stoi(match[1].str());
    }

    return 0;
}

} // namespace tamayo
