#include "tamayo/io/ProjectFile.h"
#include "tamayo/io/JsonExporter.h"
#include <fstream>
#include <cstring>

namespace tamayo {

ProjectFile::ProjectFile() = default;

bool ProjectFile::save(const Scene& scene, const std::string& filePath) const {
    std::ofstream file(filePath, std::ios::binary);
    if (!file.is_open()) {
        return false;
    }

    // Serialize scene to JSON
    JsonExporter jsonExporter;
    std::string jsonData = jsonExporter.exportToString(scene, false);
    std::vector<uint8_t> data(jsonData.begin(), jsonData.end());

    // Write header
    FileHeader header;
    header.dataSize = static_cast<uint32_t>(data.size());
    file.write(reinterpret_cast<const char*>(&header), sizeof(FileHeader));

    // Write data
    file.write(reinterpret_cast<const char*>(data.data()), data.size());

    return true;
}

std::shared_ptr<Scene> ProjectFile::load(const std::string& filePath) const {
    std::ifstream file(filePath, std::ios::binary);
    if (!file.is_open()) {
        return nullptr;
    }

    // Read header
    FileHeader header;
    file.read(reinterpret_cast<char*>(&header), sizeof(FileHeader));

    // Verify magic
    if (std::memcmp(header.magic, "TAMA", 4) != 0) {
        return nullptr;
    }

    // Verify version
    if (header.version != FORMAT_VERSION) {
        return nullptr;
    }

    // Read data
    std::vector<uint8_t> data(header.dataSize);
    file.read(reinterpret_cast<char*>(data.data()), header.dataSize);

    // Deserialize
    return deserialize(data);
}

std::vector<uint8_t> ProjectFile::serialize(const Scene& scene) const {
    JsonExporter jsonExporter;
    std::string jsonData = jsonExporter.exportToString(scene, false);
    return std::vector<uint8_t>(jsonData.begin(), jsonData.end());
}

std::shared_ptr<Scene> ProjectFile::deserialize(const std::vector<uint8_t>& data) const {
    // Convert data to string
    std::string jsonData(data.begin(), data.end());

    // Parse JSON
    nlohmann::json json = nlohmann::json::parse(jsonData, nullptr, false);
    if (json.is_discarded()) {
        return nullptr;
    }

    // Create scene
    auto scene = std::make_shared<Scene>(
        json.value("canvasWidth", 1920.0f),
        json.value("canvasHeight", 1080.0f)
    );

    // Set background color
    if (json.contains("backgroundColor")) {
        auto& bgColor = json["backgroundColor"];
        scene->setBackgroundColor(Color(
            bgColor.value("r", 0.0f),
            bgColor.value("g", 0.0f),
            bgColor.value("b", 0.0f),
            bgColor.value("a", 1.0f)
        ));
    }

    // Set playback state
    scene->setCurrentFrame(json.value("currentFrame", 0));
    scene->setTotalFrames(json.value("totalFrames", 100));

    // Load layers
    if (json.contains("layers")) {
        for (auto& layerJson : json["layers"]) {
            auto layer = std::make_shared<Layer>(layerJson.value("name", ""));
            layer->setVisible(layerJson.value("visible", true));
            layer->setZDepth(layerJson.value("zDepth", 0.0f));
            layer->setBlendMode(static_cast<BlendMode>(layerJson.value("blendMode", 0)));
            layer->setImagePath(layerJson.value("imagePath", ""));
            layer->setContentSize(
                layerJson.value("contentWidth", 0.0f),
                layerJson.value("contentHeight", 0.0f)
            );

            // Load transform
            if (layerJson.contains("transform")) {
                auto& transformJson = layerJson["transform"];
                Transform transform;
                if (transformJson.contains("position")) {
                    auto& pos = transformJson["position"];
                    transform.setPosition(
                        pos.value("x", 0.0f),
                        pos.value("y", 0.0f),
                        pos.value("z", 0.0f)
                    );
                }
                if (transformJson.contains("scale")) {
                    auto& scale = transformJson["scale"];
                    transform.setScale(
                        scale.value("sx", 1.0f),
                        scale.value("sy", 1.0f)
                    );
                }
                transform.setRotation(transformJson.value("rotation", 0.0f));
                transform.setAlpha(transformJson.value("alpha", 1.0f));
                if (transformJson.contains("anchor")) {
                    auto& anchor = transformJson["anchor"];
                    transform.setAnchor(
                        anchor.value("ax", 0.5f),
                        anchor.value("ay", 0.5f)
                    );
                }
                layer->setTransform(transform);
            }

            // Load timeline
            if (layerJson.contains("timeline") && layerJson["timeline"].contains("keyframes")) {
                Timeline timeline;
                for (auto& keyframeJson : layerJson["timeline"]["keyframes"]) {
                    Keyframe keyframe;
                    keyframe.setFrame(keyframeJson.value("frame", 0));
                    keyframe.setInterpolation(static_cast<InterpolationType>(
                        keyframeJson.value("interpolation", 0)
                    ));

                    // Load keyframe transform
                    if (keyframeJson.contains("transform")) {
                        auto& transformJson = keyframeJson["transform"];
                        Transform transform;
                        if (transformJson.contains("position")) {
                            auto& pos = transformJson["position"];
                            transform.setPosition(
                                pos.value("x", 0.0f),
                                pos.value("y", 0.0f),
                                pos.value("z", 0.0f)
                            );
                        }
                        if (transformJson.contains("scale")) {
                            auto& scale = transformJson["scale"];
                            transform.setScale(
                                scale.value("sx", 1.0f),
                                scale.value("sy", 1.0f)
                            );
                        }
                        transform.setRotation(transformJson.value("rotation", 0.0f));
                        transform.setAlpha(transformJson.value("alpha", 1.0f));
                        if (transformJson.contains("anchor")) {
                            auto& anchor = transformJson["anchor"];
                            transform.setAnchor(
                                anchor.value("ax", 0.5f),
                                anchor.value("ay", 0.5f)
                            );
                        }
                        keyframe.setTransform(transform);
                    }

                    // Load bezier handles
                    if (keyframeJson.contains("bezierIn") && keyframeJson.contains("bezierOut")) {
                        auto& bezierIn = keyframeJson["bezierIn"];
                        auto& bezierOut = keyframeJson["bezierOut"];
                        keyframe.setBezierHandles(
                            glm::vec2(bezierIn.value("x", 0.0f), bezierIn.value("y", 0.0f)),
                            glm::vec2(bezierOut.value("x", 1.0f), bezierOut.value("y", 1.0f))
                        );
                    }

                    timeline.addKeyframe(keyframe);
                }
                layer->setTimeline(timeline);
            }

            scene->addLayer(layer);
        }
    }

    return scene;
}

} // namespace tamayo
