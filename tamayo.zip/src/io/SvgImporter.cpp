#include "tamayo/io/SvgImporter.h"
#include <filesystem>
#include <fstream>
#include <sstream>
#include <regex>

namespace tamayo {

SvgImporter::SvgImporter() = default;

std::shared_ptr<Layer> SvgImporter::importFile(const std::string& filePath, float scale) const {
    if (!std::filesystem::exists(filePath)) {
        return nullptr;
    }

    auto layer = std::make_shared<Layer>(std::filesystem::path(filePath).stem().string());
    layer->setImagePath(filePath);

    // Get SVG dimensions
    float width, height;
    if (getSvgDimensions(filePath, width, height)) {
        layer->setContentSize(width * scale, height * scale);
    }

    return layer;
}

bool SvgImporter::getSvgDimensions(const std::string& filePath, float& width, float& height) const {
    return parseSvg(filePath, width, height);
}

bool SvgImporter::parseSvg(const std::string& filePath, float& width, float& height) const {
    std::ifstream file(filePath);
    if (!file.is_open()) {
        return false;
    }

    std::string content((std::istreambuf_iterator<char>(file)),
                        std::istreambuf_iterator<char>());

    // Try to find width and height attributes
    std::regex widthRegex(R"(width=["']([^"']+)["'])");
    std::regex heightRegex(R"(height=["']([^"']+)["'])");
    std::regex viewBoxRegex(R"(viewBox=["']([^"']+)["'])");

    std::smatch match;

    // Try to get width
    if (std::regex_search(content, match, widthRegex)) {
        std::string widthStr = match[1].str();
        // Remove 'px' suffix if present
        if (widthStr.find("px") != std::string::npos) {
            widthStr = widthStr.substr(0, widthStr.find("px"));
        }
        try {
            width = std::stof(widthStr);
        } catch (...) {
            width = 1920.0f;
        }
    } else {
        width = 1920.0f;
    }

    // Try to get height
    if (std::regex_search(content, match, heightRegex)) {
        std::string heightStr = match[1].str();
        // Remove 'px' suffix if present
        if (heightStr.find("px") != std::string::npos) {
            heightStr = heightStr.substr(0, heightStr.find("px"));
        }
        try {
            height = std::stof(heightStr);
        } catch (...) {
            height = 1080.0f;
        }
    } else {
        height = 1080.0f;
    }

    // If no width/height, try viewBox
    if (width == 1920.0f && height == 1080.0f) {
        if (std::regex_search(content, match, viewBoxRegex)) {
            std::string viewBox = match[1].str();
            std::istringstream iss(viewBox);
            float x, y, w, h;
            char comma;
            if (iss >> x >> comma >> y >> comma >> w >> comma >> h) {
                width = w;
                height = h;
            }
        }
    }

    return true;
}

} // namespace tamayo
