#pragma once

#include "tamayo/core/types.h"
#include "tamayo/core/Layer.h"
#include "tamayo/core/Scene.h"
#include "DepthSorter.h"
#include "LightingSystem.h"
#include <vector>
#include <memory>

namespace tamayo {

struct RenderCommand {
    std::shared_ptr<Layer> layer;
    glm::mat4 transform;
    Color color;
    BlendMode blendMode;
};

class RenderContext {
public:
    RenderContext();
    RenderContext(float canvasWidth, float canvasHeight);
    ~RenderContext() = default;

    // Canvas size
    void setCanvasSize(float width, float height);
    float getCanvasWidth() const;
    float getCanvasHeight() const;

    // Build render command list
    std::vector<RenderCommand> buildRenderCommands(
        const Scene& scene,
        const LightingSystem& lighting,
        bool frontToBack = false
    ) const;

    // Get sorted layers
    std::vector<std::shared_ptr<Layer>> getSortedLayers(
        const Scene& scene,
        bool frontToBack = false
    ) const;

    // Calculate layer transform with parallax
    glm::mat4 calculateLayerTransform(
        const Layer& layer,
        const glm::vec2& cameraOffset,
        float cameraZoom
    ) const;

private:
    float canvasWidth_ = 1920.0f;
    float canvasHeight_ = 1080.0f;
    DepthSorter depthSorter_;
};

} // namespace tamayo
