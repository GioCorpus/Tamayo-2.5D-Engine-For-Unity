#pragma once

#include "tamayo/core/types.h"
#include "tamayo/core/Layer.h"
#include <vector>
#include <memory>

namespace tamayo {

class DepthSorter {
public:
    DepthSorter();
    ~DepthSorter() = default;

    // Sort layers by depth
    std::vector<std::shared_ptr<Layer>> sort(
        const std::vector<std::shared_ptr<Layer>>& layers,
        bool frontToBack = false
    ) const;

    // Filter visible layers
    std::vector<std::shared_ptr<Layer>> filterVisible(
        const std::vector<std::shared_ptr<Layer>>& layers
    ) const;

    // Sort and filter
    std::vector<std::shared_ptr<Layer>> sortAndFilter(
        const std::vector<std::shared_ptr<Layer>>& layers,
        bool frontToBack = false
    ) const;

private:
    // Comparison functions
    static bool compareBackToFront(const std::shared_ptr<Layer>& a, const std::shared_ptr<Layer>& b);
    static bool compareFrontToBack(const std::shared_ptr<Layer>& a, const std::shared_ptr<Layer>& b);
};

} // namespace tamayo
