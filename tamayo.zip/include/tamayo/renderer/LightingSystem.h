#pragma once

#include "tamayo/core/types.h"
#include <vector>
#include <glm/glm.hpp>

namespace tamayo {

struct PointLight {
    glm::vec2 position{0.0f, 0.0f};
    Color color{1.0f, 1.0f, 1.0f, 1.0f};
    float intensity = 1.0f;
    float radius = 100.0f;
    float falloff = 1.0f;
};

class LightingSystem {
public:
    LightingSystem();
    ~LightingSystem() = default;

    // Ambient light
    void setAmbientColor(const Color& color);
    const Color& getAmbientColor() const;
    void setAmbientIntensity(float intensity);
    float getAmbientIntensity() const;

    // Point lights
    void addPointLight(const PointLight& light);
    void removePointLight(size_t index);
    void clearPointLights();
    const std::vector<PointLight>& getPointLights() const;
    std::vector<PointLight>& getPointLights();

    // Calculate lighting for a point
    Color calculateLighting(const glm::vec2& position, float depth = 0.0f) const;

    // Depth-based falloff
    void setDepthFalloff(float falloff);
    float getDepthFalloff() const;

private:
    Color ambientColor_{1.0f, 1.0f, 1.0f, 1.0f};
    float ambientIntensity_ = 0.3f;
    std::vector<PointLight> pointLights_;
    float depthFalloff_ = 0.5f;
};

} // namespace tamayo
