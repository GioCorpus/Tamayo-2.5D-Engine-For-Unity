#pragma once

#include <cstdint>
#include <string>
#include <vector>
#include <memory>

namespace tamayo {

// Color structure
struct Color {
    float r = 1.0f;
    float g = 1.0f;
    float b = 1.0f;
    float a = 1.0f;

    Color() = default;
    Color(float r, float g, float b, float a = 1.0f) : r(r), g(g), b(b), a(a) {}
};

// Rectangle structure
struct Rect {
    float x = 0.0f;
    float y = 0.0f;
    float width = 0.0f;
    float height = 0.0f;

    Rect() = default;
    Rect(float x, float y, float width, float height) : x(x), y(y), width(width), height(height) {}
};

// Blend mode enum
enum class BlendMode {
    Normal,
    Additive,
    Multiply,
    Screen,
    Overlay
};

// Interpolation type enum
enum class InterpolationType {
    Linear,
    EaseIn,
    EaseOut,
    Step,
    CubicBezier
};

// ID types
using LayerID = uint32_t;
using KeyframeID = uint32_t;
using SceneID = uint32_t;

constexpr LayerID INVALID_LAYER_ID = 0;
constexpr KeyframeID INVALID_KEYFRAME_ID = 0;
constexpr SceneID INVALID_SCENE_ID = 0;

} // namespace tamayo
