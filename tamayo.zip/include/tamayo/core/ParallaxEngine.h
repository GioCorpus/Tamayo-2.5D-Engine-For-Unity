#pragma once

#include "types.h"
#include "Layer.h"
#include <vector>
#include <memory>

namespace tamayo {

class ParallaxEngine {
public:
    ParallaxEngine();
    ParallaxEngine(float canvasWidth, float canvasHeight);
    ~ParallaxEngine() = default;

    // Camera settings
    void setCameraOffset(float x, float y);
    void setCameraOffset(const glm::vec2& offset);
    glm::vec2 getCameraOffset() const;

    void setCameraZoom(float zoom);
    float getCameraZoom() const;

    // Depth planes configuration
    void setDepthPlaneCount(uint32_t count);
    uint32_t getDepthPlaneCount() const;

    // Apply parallax effect to layers
    void applyParallax(std::vector<std::shared_ptr<Layer>>& layers) const;

    // Calculate depth-based offset and scale
    glm::vec2 calculateDepthOffset(float layerDepth) const;
    float calculateDepthScale(float layerDepth) const;

    // Generate layer depths for a given number of layers
    std::vector<float> generateLayerDepths(uint32_t layerCount) const;

    // Canvas size
    void setCanvasSize(float width, float height);
    float getCanvasWidth() const;
    float getCanvasHeight() const;

private:
    float canvasWidth_ = 1920.0f;
    float canvasHeight_ = 1080.0f;
    glm::vec2 cameraOffset_{0.0f, 0.0f};
    float cameraZoom_ = 1.0f;
    uint32_t depthPlaneCount_ = 5;

    // Depth plane settings
    float minDepth_ = 0.0f;
    float maxDepth_ = 1.0f;
    float parallaxStrength_ = 0.5f;
};

} // namespace tamayo
