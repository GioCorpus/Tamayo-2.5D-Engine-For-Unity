#pragma once

#include "types.h"
#include "Keyframe.h"
#include <vector>
#include <optional>

namespace tamayo {

class Timeline {
public:
    Timeline();
    ~Timeline() = default;

    // Keyframe management
    void addKeyframe(const Keyframe& keyframe);
    void removeKeyframe(uint32_t frame);
    void clearKeyframes();

    // Keyframe access
    const std::vector<Keyframe>& getKeyframes() const;
    std::optional<Keyframe> getKeyframeAt(uint32_t frame) const;
    bool hasKeyframeAt(uint32_t frame) const;

    // Evaluation
    Transform evaluate(uint32_t frame) const;
    Transform evaluate(float time, float fps = 30.0f) const;

    // Frame/time conversion
    uint32_t timeToFrame(float time, float fps = 30.0f) const;
    float frameToTime(uint32_t frame, float fps = 30.0f) const;

    // Get previous/next keyframes
    std::optional<Keyframe> getPreviousKeyframe(uint32_t frame) const;
    std::optional<Keyframe> getNextKeyframe(uint32_t frame) const;

    // Get frame range
    uint32_t getStartFrame() const;
    uint32_t getEndFrame() const;
    bool isEmpty() const;

private:
    std::vector<Keyframe> keyframes_;
    mutable bool sorted_ = false;

    void ensureSorted() const;
};

} // namespace tamayo
