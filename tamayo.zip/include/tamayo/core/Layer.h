#pragma once

#include "types.h"
#include "Transform.h"
#include "Timeline.h"
#include <string>
#include <vector>
#include <memory>

namespace tamayo {

class Layer {
public:
    Layer();
    Layer(const std::string& name);
    ~Layer() = default;

    // Name
    void setName(const std::string& name);
    const std::string& getName() const;

    // Visibility
    void setVisible(bool visible);
    bool isVisible() const;

    // Z-depth
    void setZDepth(float depth);
    float getZDepth() const;

    // Blend mode
    void setBlendMode(BlendMode mode);
    BlendMode getBlendMode() const;

    // Image path
    void setImagePath(const std::string& path);
    const std::string& getImagePath() const;

    // Content size
    void setContentSize(float width, float height);
    float getContentWidth() const;
    float getContentHeight() const;

    // Transform
    void setTransform(const Transform& transform);
    const Transform& getTransform() const;
    Transform& getTransform();

    // Timeline animation
    void setTimeline(const Timeline& timeline);
    const Timeline& getTimeline() const;
    Timeline& getTimeline();

    // Child hierarchy
    void addChild(std::shared_ptr<Layer> child);
    void removeChild(LayerID id);
    const std::vector<std::shared_ptr<Layer>>& getChildren() const;
    std::shared_ptr<Layer> findChild(LayerID id) const;

    // ID
    LayerID getID() const;

private:
    LayerID id_;
    std::string name_;
    bool visible_ = true;
    float zDepth_ = 0.0f;
    BlendMode blendMode_ = BlendMode::Normal;
    std::string imagePath_;
    float contentWidth_ = 0.0f;
    float contentHeight_ = 0.0f;
    Transform transform_;
    Timeline timeline_;
    std::vector<std::shared_ptr<Layer>> children_;

    static LayerID nextID_;
};

} // namespace tamayo
