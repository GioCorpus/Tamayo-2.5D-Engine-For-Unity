#pragma once

#include "types.h"
#include "Layer.h"
#include <vector>
#include <memory>

namespace tamayo {

class Scene {
public:
    Scene();
    Scene(float width, float height);
    ~Scene() = default;

    // Canvas size
    void setCanvasSize(float width, float height);
    float getCanvasWidth() const;
    float getCanvasHeight() const;

    // Background color
    void setBackgroundColor(const Color& color);
    const Color& getBackgroundColor() const;

    // Layer management
    void addLayer(std::shared_ptr<Layer> layer);
    void removeLayer(LayerID id);
    void moveLayer(LayerID id, int newIndex);
    const std::vector<std::shared_ptr<Layer>>& getLayers() const;
    std::shared_ptr<Layer> findLayer(LayerID id) const;

    // Depth sorting
    void sortLayersByDepth(bool frontToBack = false);
    std::vector<std::shared_ptr<Layer>> getSortedLayers(bool frontToBack = false) const;

    // Playback state
    void setCurrentFrame(uint32_t frame);
    uint32_t getCurrentFrame() const;
    void setTotalFrames(uint32_t frames);
    uint32_t getTotalFrames() const;

    // Frame clamping
    uint32_t clampFrame(uint32_t frame) const;

    // Scene ID
    SceneID getID() const;

private:
    SceneID id_;
    float canvasWidth_ = 1920.0f;
    float canvasHeight_ = 1080.0f;
    Color backgroundColor_{0.0f, 0.0f, 0.0f, 1.0f};
    std::vector<std::shared_ptr<Layer>> layers_;
    uint32_t currentFrame_ = 0;
    uint32_t totalFrames_ = 100;

    static SceneID nextID_;
};

} // namespace tamayo
