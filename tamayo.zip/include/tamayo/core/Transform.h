#pragma once

#include "types.h"
#include <glm/glm.hpp>

namespace tamayo {

class Transform {
public:
    Transform();
    Transform(float x, float y, float z = 0.0f);
    ~Transform() = default;

    // Position
    void setPosition(float x, float y, float z = 0.0f);
    void setPosition(const glm::vec3& position);
    glm::vec3 getPosition() const;
    float getX() const { return position_.x; }
    float getY() const { return position_.y; }
    float getZ() const { return position_.z; }

    // Scale
    void setScale(float sx, float sy);
    void setScale(const glm::vec2& scale);
    glm::vec2 getScale() const;
    float getSX() const { return scale_.x; }
    float getSY() const { return scale_.y; }

    // Rotation (in degrees)
    void setRotation(float degrees);
    float getRotation() const;

    // Alpha (opacity)
    void setAlpha(float alpha);
    float getAlpha() const;

    // Anchor point
    void setAnchor(float ax, float ay);
    void setAnchor(const glm::vec2& anchor);
    glm::vec2 getAnchor() const;

    // Matrix generation
    glm::mat4 getMatrix() const;

    // Linear interpolation
    static Transform lerp(const Transform& a, const Transform& b, float t);

    // Comparison
    bool operator==(const Transform& other) const;
    bool operator!=(const Transform& other) const;

private:
    glm::vec3 position_{0.0f, 0.0f, 0.0f};
    glm::vec2 scale_{1.0f, 1.0f};
    float rotation_ = 0.0f;  // degrees
    float alpha_ = 1.0f;
    glm::vec2 anchor_{0.5f, 0.5f};  // normalized (0-1)
};

} // namespace tamayo
