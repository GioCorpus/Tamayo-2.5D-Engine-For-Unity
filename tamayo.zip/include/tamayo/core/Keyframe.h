#pragma once

#include "types.h"
#include "Transform.h"

namespace tamayo {

class Keyframe {
public:
    Keyframe();
    Keyframe(uint32_t frame, const Transform& transform);
    ~Keyframe() = default;

    // Frame index
    void setFrame(uint32_t frame);
    uint32_t getFrame() const;

    // Transform
    void setTransform(const Transform& transform);
    const Transform& getTransform() const;
    Transform& getTransform();

    // Interpolation type
    void setInterpolation(InterpolationType type);
    InterpolationType getInterpolation() const;

    // Bezier handles (for CubicBezier interpolation)
    void setBezierHandles(const glm::vec2& in, const glm::vec2& out);
    glm::vec2 getBezierIn() const;
    glm::vec2 getBezierOut() const;

    // Comparison operators
    bool operator<(const Keyframe& other) const;
    bool operator==(const Keyframe& other) const;
    bool operator!=(const Keyframe& other) const;

private:
    uint32_t frame_ = 0;
    Transform transform_;
    InterpolationType interpolation_ = InterpolationType::Linear;
    glm::vec2 bezierIn_{0.0f, 0.0f};
    glm::vec2 bezierOut_{1.0f, 1.0f};
};

} // namespace tamayo
