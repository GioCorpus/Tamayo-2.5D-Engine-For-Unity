#pragma once

#include "tamayo/core/types.h"
#include "tamayo/core/Scene.h"
#include <string>
#include <memory>

namespace tamayo {

class EditorApp {
public:
    EditorApp();
    ~EditorApp() = default;

    // Application lifecycle
    void initialize();
    void shutdown();
    void update(float deltaTime);

    // Scene management
    void newScene(float width = 1920.0f, float height = 1080.0f);
    void openScene(const std::string& filePath);
    void saveScene(const std::string& filePath);
    void exportScene(const std::string& filePath, const std::string& format);

    // Playback control
    void play();
    void pause();
    void stop();
    void goToFrame(uint32_t frame);
    void nextFrame();
    void prevFrame();

    // Get current scene
    std::shared_ptr<Scene> getCurrentScene() const;

    // Get current frame
    uint32_t getCurrentFrame() const;

    // Check if playing
    bool isPlaying() const;

private:
    std::shared_ptr<Scene> currentScene_;
    bool playing_ = false;
    float playbackTime_ = 0.0f;
    float fps_ = 30.0f;
};

} // namespace tamayo
