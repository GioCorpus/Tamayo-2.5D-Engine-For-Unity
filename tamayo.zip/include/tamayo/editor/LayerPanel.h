#pragma once

#include "tamayo/core/types.h"
#include "tamayo/core/Scene.h"
#include <functional>
#include <memory>

namespace tamayo {

class LayerPanel {
public:
    LayerPanel();
    ~LayerPanel() = default;

    // Set scene
    void setScene(std::shared_ptr<Scene> scene);

    // Layer selection
    void setSelectedLayer(LayerID layerId);
    LayerID getSelectedLayer() const;

    // Callbacks
    using LayerSelectedCallback = std::function<void(LayerID)>;
    using VisibilityChangedCallback = std::function<void(LayerID, bool)>;

    void setLayerSelectedCallback(LayerSelectedCallback callback);
    void setVisibilityChangedCallback(VisibilityChangedCallback callback);

    // Update
    void update(float deltaTime);

private:
    std::shared_ptr<Scene> scene_;
    LayerID selectedLayer_ = INVALID_LAYER_ID;

    LayerSelectedCallback layerSelectedCallback_;
    VisibilityChangedCallback visibilityChangedCallback_;
};

} // namespace tamayo
