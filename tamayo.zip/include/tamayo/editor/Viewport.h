#pragma once

#include "tamayo/core/types.h"
#include "tamayo/core/Scene.h"
#include <glm/glm.hpp>
#include <memory>

namespace tamayo {

class Viewport {
public:
    Viewport();
    Viewport(float width, float height);
    ~Viewport() = default;

    // Set scene
    void setScene(std::shared_ptr<Scene> scene);

    // Viewport size
    void setSize(float width, float height);
    float getWidth() const;
    float getHeight() const;

    // Camera
    void setCameraOffset(float x, float y);
    void setCameraOffset(const glm::vec2& offset);
    glm::vec2 getCameraOffset() const;

    void setCameraZoom(float zoom);
    float getCameraZoom() const;

    // Coordinate transforms
    glm::vec2 screenToWorld(const glm::vec2& screenPos) const;
    glm::vec2 worldToScreen(const glm::vec2& worldPos) const;

    // Pan and zoom
    void pan(float dx, float dy);
    void zoom(float factor, const glm::vec2& center);

    // Update
    void update(float deltaTime);

private:
    std::shared_ptr<Scene> scene_;
    float width_ = 1920.0f;
    float height_ = 1080.0f;
    glm::vec2 cameraOffset_{0.0f, 0.0f};
    float cameraZoom_ = 1.0f;
};

} // namespace tamayo
