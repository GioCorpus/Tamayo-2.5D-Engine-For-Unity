#pragma once

#include "tamayo/core/types.h"
#include "tamayo/core/Scene.h"
#include <functional>
#include <memory>

namespace tamayo {

class TimelinePanel {
public:
    TimelinePanel();
    ~TimelinePanel() = default;

    // Set scene
    void setScene(std::shared_ptr<Scene> scene);

    // Frame/position mapping
    uint32_t positionToFrame(float x, float panelWidth) const;
    float frameToPosition(uint32_t frame, float panelWidth) const;

    // Zoom and scroll
    void setZoom(float zoom);
    float getZoom() const;
    void setScroll(float scroll);
    float getScroll() const;

    // Layer selection
    void setSelectedLayer(LayerID layerId);
    LayerID getSelectedLayer() const;

    // Callbacks
    using FrameSelectedCallback = std::function<void(uint32_t)>;
    using LayerSelectedCallback = std::function<void(LayerID)>;

    void setFrameSelectedCallback(FrameSelectedCallback callback);
    void setLayerSelectedCallback(LayerSelectedCallback callback);

    // Update
    void update(float deltaTime);

private:
    std::shared_ptr<Scene> scene_;
    float zoom_ = 1.0f;
    float scroll_ = 0.0f;
    LayerID selectedLayer_ = INVALID_LAYER_ID;

    FrameSelectedCallback frameSelectedCallback_;
    LayerSelectedCallback layerSelectedCallback_;
};

} // namespace tamayo
