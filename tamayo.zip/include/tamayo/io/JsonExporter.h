#pragma once

#include "tamayo/core/types.h"
#include "tamayo/core/Scene.h"
#include <string>
#include <nlohmann/json.hpp>

namespace tamayo {

class JsonExporter {
public:
    JsonExporter();
    ~JsonExporter() = default;

    // Export scene to JSON
    nlohmann::json exportScene(const Scene& scene, bool includeMetadata = true) const;

    // Export scene to file
    bool exportToFile(const Scene& scene, const std::string& filePath, bool includeMetadata = true) const;

    // Export scene to string
    std::string exportToString(const Scene& scene, bool includeMetadata = true) const;

private:
    // Export layer to JSON
    nlohmann::json exportLayer(const Layer& layer) const;

    // Export transform to JSON
    nlohmann::json exportTransform(const Transform& transform) const;

    // Export timeline to JSON
    nlohmann::json exportTimeline(const Timeline& timeline) const;

    // Export keyframe to JSON
    nlohmann::json exportKeyframe(const Keyframe& keyframe) const;
};

} // namespace tamayo
