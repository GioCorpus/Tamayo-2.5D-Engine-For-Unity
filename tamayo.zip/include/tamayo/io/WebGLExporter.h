#pragma once

#include "tamayo/core/types.h"
#include "tamayo/core/Scene.h"
#include <string>

namespace tamayo {

class WebGLExporter {
public:
    WebGLExporter();
    ~WebGLExporter() = default;

    // Export scene to WebGL HTML
    bool exportToFile(const Scene& scene, const std::string& outputDir) const;

    // Export scene to HTML string
    std::string exportToString(const Scene& scene) const;

private:
    // Generate HTML file
    std::string generateHtml(const Scene& scene) const;

    // Generate JavaScript file
    std::string generateJavaScript(const Scene& scene) const;

    // Generate JSON data file
    std::string generateJsonData(const Scene& scene) const;

    // Generate vertex shader
    std::string generateVertexShader() const;

    // Generate fragment shader
    std::string generateFragmentShader() const;
};

} // namespace tamayo
