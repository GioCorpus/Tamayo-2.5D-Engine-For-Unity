#pragma once

#include "tamayo/core/types.h"
#include "tamayo/core/Layer.h"
#include <string>
#include <vector>
#include <memory>

namespace tamayo {

class PngImporter {
public:
    PngImporter();
    ~PngImporter() = default;

    // Import single PNG file
    std::shared_ptr<Layer> importFile(const std::string& filePath) const;

    // Import PNG sequence
    std::vector<std::shared_ptr<Layer>> importSequence(
        const std::string& directory,
        const std::string& prefix = "",
        const std::string& suffix = ".png"
    ) const;

    // Import all PNGs from directory
    std::vector<std::shared_ptr<Layer>> importDirectory(const std::string& directory) const;

    // Get image dimensions
    bool getImageDimensions(const std::string& filePath, int& width, int& height) const;

private:
    // Helper to find PNG files in directory
    std::vector<std::string> findPngFiles(const std::string& directory) const;

    // Helper to extract frame number from filename
    int extractFrameNumber(const std::string& filename) const;
};

} // namespace tamayo
