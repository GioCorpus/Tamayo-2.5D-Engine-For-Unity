#pragma once

#include "tamayo/core/types.h"
#include "tamayo/core/Layer.h"
#include <string>
#include <memory>

namespace tamayo {

class SvgImporter {
public:
    SvgImporter();
    ~SvgImporter() = default;

    // Import SVG file
    std::shared_ptr<Layer> importFile(const std::string& filePath, float scale = 1.0f) const;

    // Get SVG dimensions
    bool getSvgDimensions(const std::string& filePath, float& width, float& height) const;

private:
    // Parse SVG file
    bool parseSvg(const std::string& filePath, float& width, float& height) const;
};

} // namespace tamayo
