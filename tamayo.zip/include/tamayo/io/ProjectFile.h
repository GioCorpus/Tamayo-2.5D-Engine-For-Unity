#pragma once

#include "tamayo/core/types.h"
#include "tamayo/core/Scene.h"
#include <string>
#include <memory>

namespace tamayo {

class ProjectFile {
public:
    ProjectFile();
    ~ProjectFile() = default;

    // Save scene to .tamayo file
    bool save(const Scene& scene, const std::string& filePath) const;

    // Load scene from .tamayo file
    std::shared_ptr<Scene> load(const std::string& filePath) const;

    // Get file format version
    static constexpr uint32_t FORMAT_VERSION = 1;

private:
    // File header
    struct FileHeader {
        char magic[4] = {'T', 'A', 'M', 'A'};
        uint32_t version = FORMAT_VERSION;
        uint32_t dataSize = 0;
    };

    // Serialize scene to binary
    std::vector<uint8_t> serialize(const Scene& scene) const;

    // Deserialize scene from binary
    std::shared_ptr<Scene> deserialize(const std::vector<uint8_t>& data) const;
};

} // namespace tamayo
