Shader "Tamayo2D/QuantumGlow"
{
    Properties
    {
        _MainTex ("Texture", 2D) = "white" {}
        _GlowColor ("Glow Color", Color) = (0.2, 0.5, 1.0, 1.0)
        _GlowIntensity ("Glow Intensity", Range(0, 5)) = 2.0
        _WaveSpeed ("Wave Speed", Float) = 2.0
        _WaveAmplitude ("Wave Amplitude", Float) = 1.0
        _WaveFrequency ("Wave Frequency", Float) = 1.0
        _TimeOffset ("Time Offset", Float) = 0.0
        _NoiseScale ("Noise Scale", Float) = 1.0
        _VoronoiScale ("Voronoi Scale", Float) = 1.0
    }
    
    SubShader
    {
        Tags 
        { 
            "RenderType" = "Transparent" 
            "Queue" = "Transparent"
            "RenderPipeline" = "UniversalPipeline"
        }
        
        Blend SrcAlpha OneMinusSrcAlpha
        ZWrite Off
        Cull Off
        
        Pass
        {
            Name "QuantumGlow"
            Tags { "LightMode" = "UniversalForward" }
            
            HLSLPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma multi_compile_fog
            
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Lighting.hlsl"
            
            struct Attributes
            {
                float4 positionOS : POSITION;
                float2 uv : TEXCOORD0;
                float4 color : COLOR;
            };
            
            struct Varyings
            {
                float4 positionCS : SV_POSITION;
                float2 uv : TEXCOORD0;
                float4 color : COLOR;
                float fogFactor : TEXCOORD1;
            };
            
            TEXTURE2D(_MainTex);
            SAMPLER(sampler_MainTex);
            
            CBUFFER_START(UnityPerMaterial)
                float4 _MainTex_ST;
                float4 _GlowColor;
                float _GlowIntensity;
                float _WaveSpeed;
                float _WaveAmplitude;
                float _WaveFrequency;
                float _TimeOffset;
                float _NoiseScale;
                float _VoronoiScale;
            CBUFFER_END
            
            // Simplex noise function
            float3 mod289(float3 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
            float2 mod289(float2 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
            float3 permute(float3 x) { return mod289(((x*34.0)+1.0)*x); }
            
            float snoise(float2 v)
            {
                const float4 C = float4(0.211324865405187, 0.366025403784439,
                                       -0.577350269189626, 0.024390243902439);
                float2 i  = floor(v + dot(v, C.yy));
                float2 x0 = v -   i + dot(i, C.xx);
                float2 i1;
                i1 = (x0.x > x0.y) ? float2(1.0, 0.0) : float2(0.0, 1.0);
                float4 x12 = x0.xyxy + C.xxzz;
                x12.xy -= i1;
                i = mod289(i);
                float3 p = permute(permute(i.y + float3(0.0, i1.y, 1.0))
                                        + i.x + float3(0.0, i1.x, 1.0));
                float3 m = max(0.5 - float3(dot(x0,x0), dot(x12.xy,x12.xy),
                                           dot(x12.zw,x12.zw)), 0.0);
                m = m*m;
                m = m*m;
                float3 x = 2.0 * frac(p * C.www) - 1.0;
                float3 h = abs(x) - 0.5;
                float3 ox = floor(x + 0.5);
                float3 a0 = x - ox;
                m *= 1.79284291400159 - 0.85373472095314 * (a0*a0 + h*h);
                float3 g;
                g.x  = a0.x  * x0.x  + h.x  * x0.y;
                g.yz = a0.yz * x12.xz + h.yz * x12.yw;
                return 130.0 * dot(m, g);
            }
            
            // Voronoi noise
            float2 voronoi(float2 x)
            {
                float2 n = floor(x);
                float2 f = frac(x);
                
                float2 mg, mr;
                float md = 8.0;
                
                for(int j=-1; j<=1; j++)
                {
                    for(int i=-1; i<=1; i++)
                    {
                        float2 g = float2(float(i),float(j));
                        float2 o = hash2(n + g);
                        float2 r = g + o - f;
                        float d = dot(r,r);
                        
                        if(d < md)
                        {
                            md = d;
                            mr = r;
                            mg = g;
                        }
                    }
                }
                
                return float2(md, mr.x + mr.y);
            }
            
            float hash(float2 p)
            {
                float3 p3 = frac(float3(p.xyx) * 0.1031);
                p3 += dot(p3, p3.yzx + 33.33);
                return frac((p3.x + p3.y) * p3.z);
            }
            
            float2 hash2(float2 p)
            {
                float3 p3 = frac(float3(p.xyx) * float3(0.1031, 0.1030, 0.0973));
                p3 += dot(p3, p3.yzx + 33.33);
                return frac((p3.xx + p3.yz) * p3.zy);
            }
            
            Varyings vert(Attributes input)
            {
                Varyings output;
                
                // Apply wave distortion
                float wave = sin(_TimeOffset * _WaveSpeed + input.positionOS.x * _WaveFrequency) * _WaveAmplitude;
                input.positionOS.y += wave;
                
                output.positionCS = TransformObjectToHClip(input.positionOS.xyz);
                output.uv = TRANSFORM_TEX(input.uv, _MainTex);
                output.color = input.color;
                output.fogFactor = ComputeFogFactor(output.positionCS.z);
                
                return output;
            }
            
            half4 frag(Varyings input) : SV_Target
            {
                // Sample main texture
                half4 texColor = SAMPLE_TEXTURE2D(_MainTex, sampler_MainTex, input.uv);
                
                // Calculate noise
                float noise = snoise(input.uv * _NoiseScale + _TimeOffset * 0.5);
                float voronoiNoise = voronoi(input.uv * _VoronoiScale + _TimeOffset).x;
                
                // Combine noise for quantum effect
                float quantumNoise = (noise + voronoiNoise) * 0.5;
                
                // Create glow effect
                float glow = quantumNoise * _GlowIntensity;
                float3 glowColor = _GlowColor.rgb * glow;
                
                // Apply wave animation
                float wave = sin(_TimeOffset * _WaveSpeed + input.uv.x * _WaveFrequency) * 0.5 + 0.5;
                glowColor *= wave;
                
                // Final color
                half4 finalColor;
                finalColor.rgb = texColor.rgb + glowColor;
                finalColor.a = texColor.a * (0.5 + glow * 0.5);
                
                // Apply fog
                finalColor.rgb = MixFog(finalColor.rgb, input.fogFactor);
                
                return finalColor;
            }
            ENDHLSL
        }
    }
    
    FallBack "Universal Render Pipeline/Lit"
}
