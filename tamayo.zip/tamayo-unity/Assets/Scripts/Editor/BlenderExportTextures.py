import bpy
import sys
import os

# Get command line arguments
argv = sys.argv
argv = argv[argv.index('--') + 1:] if '--' in argv else []

# Set export settings
export_path = argv[0] if len(argv) > 0 else 'Assets/Textures/'
texture_resolution = 1024

# Create export directory
if not os.path.exists(export_path):
    os.makedirs(export_path)

# Export textures for all materials
for material in bpy.data.materials:
    if material.use_nodes:
        for node in material.node_tree.nodes:
            if node.type == 'TEX_IMAGE' and node.image:
                # Get image
                image = node.image
                
                # Set resolution
                image.scale(texture_resolution, texture_resolution)
                
                # Save image
                texture_name = f"{material.name}_{node.name}.png"
                texture_path = os.path.join(export_path, texture_name)
                
                # Save as PNG
                image.filepath_raw = texture_path
                image.file_format = 'PNG'
                image.save()
                
                print(f'Exported texture: {texture_name}')

print(f'Exported all textures to {export_path}')
