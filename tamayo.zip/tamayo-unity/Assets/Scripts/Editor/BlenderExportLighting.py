import bpy
import sys
import os

# Get command line arguments
argv = sys.argv
argv = argv[argv.index('--') + 1:] if '--' in argv else []

# Set export settings
export_path = argv[0] if len(argv) > 0 else 'Assets/Lighting/'
lighting_name = argv[1] if len(argv) > 1 else 'DesertLighting'

# Create export directory
if not os.path.exists(export_path):
    os.makedirs(export_path)

# Get current scene
scene = bpy.context.scene

# Export lighting file
lighting_path = os.path.join(export_path, f"{lighting_name}.lighting")

# Write lighting file
with open(lighting_path, 'w') as f:
    f.write(f"Lighting: {lighting_name}\n")
    f.write(f"Frame Start: {scene.frame_start}\n")
    f.write(f"Frame End: {scene.frame_end}\n")
    f.write(f"FPS: {scene.render.fps}\n")
    
    # Write world settings
    f.write("World:\n")
    if scene.world:
        f.write(f"  Name: {scene.world.name}\n")
        if scene.world.use_nodes:
            for node in scene.world.node_tree.nodes:
                if node.type == 'BACKGROUND':
                    f.write(f"  Background Color: {node.inputs[0].default_value[0]:.3f}, {node.inputs[0].default_value[1]:.3f}, {node.inputs[0].default_value[2]:.3f}\n")
                    f.write(f"  Background Strength: {node.inputs[1].default_value:.3f}\n")
    
    # Write lights
    f.write("Lights:\n")
    for obj in scene.objects:
        if obj.type == 'LIGHT':
            f.write(f"  Light: {obj.name}\n")
            f.write(f"  Type: {obj.data.type}\n")
            f.write(f"  Color: {obj.data.color[0]:.3f}, {obj.data.color[1]:.3f}, {obj.data.color[2]:.3f}\n")
            f.write(f"  Energy: {obj.data.energy:.3f}\n")
            f.write(f"  Distance: {obj.data.distance:.3f}\n")
            f.write(f"  Size: {obj.data.size:.3f}\n")
            if obj.data.type == 'SPOT':
                f.write(f"  Spot Size: {obj.data.spot_size:.3f}\n")
                f.write(f"  Spot Blend: {obj.data.spot_blend:.3f}\n")

print(f'Exported lighting: {lighting_name}')
