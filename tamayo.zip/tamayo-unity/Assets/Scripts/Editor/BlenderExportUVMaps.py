import bpy
import sys
import os

# Get command line arguments
argv = sys.argv
argv = argv[argv.index('--') + 1:] if '--' in argv else []

# Set export settings
export_path = argv[0] if len(argv) > 0 else 'Assets/UVMaps/'
uv_maps_name = argv[1] if len(argv) > 1 else 'DesertUVMaps'

# Create export directory
if not os.path.exists(export_path):
    os.makedirs(export_path)

# Get current scene
scene = bpy.context.scene

# Export UV maps file
uv_maps_path = os.path.join(export_path, f"{uv_maps_name}.uv_maps")

# Write UV maps file
with open(uv_maps_path, 'w') as f:
    f.write(f"UV Maps: {uv_maps_name}\n")
    f.write(f"Frame Start: {scene.frame_start}\n")
    f.write(f"Frame End: {scene.frame_end}\n")
    f.write(f"FPS: {scene.render.fps}\n")
    
    # Write object UV maps
    f.write("Object UV Maps:\n")
    for obj in scene.objects:
        if obj.data and obj.data.uv_layers:
            f.write(f"  Object: {obj.name}\n")
            for uv_layer in obj.data.uv_layers:
                f.write(f"    UV Layer: {uv_layer.name}\n")
                f.write(f"    Active: {uv_layer.active}\n")
                f.write(f"    Active Render: {uv_layer.active_render}\n")
                f.write(f"    Active Clone: {uv_layer.active_clone}\n")

print(f'Exported UV maps: {uv_maps_name}')
