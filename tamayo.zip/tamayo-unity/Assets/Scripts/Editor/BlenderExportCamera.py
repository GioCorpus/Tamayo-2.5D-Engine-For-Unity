import bpy
import sys
import os

# Get command line arguments
argv = sys.argv
argv = argv[argv.index('--') + 1:] if '--' in argv else []

# Set export settings
export_path = argv[0] if len(argv) > 0 else 'Assets/Camera/'
camera_name = argv[1] if len(argv) > 1 else 'DesertCamera'

# Create export directory
if not os.path.exists(export_path):
    os.makedirs(export_path)

# Get current scene
scene = bpy.context.scene

# Export camera file
camera_path = os.path.join(export_path, f"{camera_name}.camera")

# Write camera file
with open(camera_path, 'w') as f:
    f.write(f"Camera: {camera_name}\n")
    f.write(f"Frame Start: {scene.frame_start}\n")
    f.write(f"Frame End: {scene.frame_end}\n")
    f.write(f"FPS: {scene.render.fps}\n")
    
    # Write camera settings
    f.write("Camera Settings:\n")
    for obj in scene.objects:
        if obj.type == 'CAMERA':
            f.write(f"  Camera: {obj.name}\n")
            f.write(f"  Type: {obj.data.type}\n")
            f.write(f"  Focal Length: {obj.data.lens:.3f}\n")
            f.write(f"  Sensor Width: {obj.data.sensor_width:.3f}\n")
            f.write(f"  Sensor Height: {obj.data.sensor_height:.3f}\n")
            f.write(f"  Clip Start: {obj.data.clip_start:.3f}\n")
            f.write(f"  Clip End: {obj.data.clip_end:.3f}\n")
            f.write(f"  DOF: {obj.data.dof.use_dof}\n")
            if obj.data.dof.use_dof:
                f.write(f"  DOF Distance: {obj.data.dof.focus_distance:.3f}\n")
                f.write(f"  DOF F-Stop: {obj.data.dof.aperture_fstop:.3f}\n")
            f.write(f"  Location: {obj.location[0]:.3f}, {obj.location[1]:.3f}, {obj.location[2]:.3f}\n")
            f.write(f"  Rotation: {obj.rotation_euler[0]:.3f}, {obj.rotation_euler[1]:.3f}, {obj.rotation_euler[2]:.3f}\n")

print(f'Exported camera: {camera_name}')
