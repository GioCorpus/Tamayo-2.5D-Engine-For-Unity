import bpy
import sys
import os

# Get command line arguments
argv = sys.argv
argv = argv[argv.index('--') + 1:] if '--' in argv else []

# Set export settings
export_path = argv[0] if len(argv) > 0 else 'Assets/Sequencer/'
sequencer_name = argv[1] if len(argv) > 1 else 'DesertSequencer'

# Create export directory
if not os.path.exists(export_path):
    os.makedirs(export_path)

# Get current scene
scene = bpy.context.scene

# Export sequencer file
sequencer_path = os.path.join(export_path, f"{sequencer_name}.sequencer")

# Write sequencer file
with open(sequencer_path, 'w') as f:
    f.write(f"Sequencer: {sequencer_name}\n")
    f.write(f"Frame Start: {scene.frame_start}\n")
    f.write(f"Frame End: {scene.frame_end}\n")
    f.write(f"FPS: {scene.render.fps}\n")
    
    # Write sequencer strips
    f.write("Sequencer Strips:\n")
    if scene.sequence_editor:
        for strip in scene.sequence_editor.sequences:
            f.write(f"  Strip: {strip.name}\n")
            f.write(f"  Type: {strip.type}\n")
            f.write(f"  Frame Start: {strip.frame_start}\n")
            f.write(f"  Frame End: {strip.frame_final_end}\n")
            f.write(f"  Channel: {strip.channel}\n")
            f.write(f"  Blend Type: {strip.blend_type}\n")
            f.write(f"  Blend Alpha: {strip.blend_alpha:.3f}\n")
            f.write(f"  Use Blend: {strip.use_blend}\n")
            
            # Write strip-specific properties
            if strip.type == 'IMAGE':
                f.write(f"  Directory: {strip.directory}\n")
                f.write(f"  Use Placeholder: {strip.use_placeholder}\n")
                f.write(f"  Use Proxy: {strip.use_proxy}\n")
            elif strip.type == 'MOVIE':
                f.write(f"  Filepath: {strip.filepath}\n")
                f.write(f"  Use Proxy: {strip.use_proxy}\n")
            elif strip.type == 'SOUND':
                f.write(f"  Filepath: {strip.filepath}\n")
                f.write(f"  Volume: {strip.volume:.3f}\n")
                f.write(f"  Pitch: {strip.pitch:.3f}\n")
                f.write(f"  Pan: {strip.pan:.3f}\n")
            elif strip.type == 'COLOR':
                f.write(f"  Color: {strip.color[0]:.3f}, {strip.color[1]:.3f}, {strip.color[2]:.3f}\n")
            elif strip.type == 'TEXT':
                f.write(f"  Text: {strip.text}\n")
                f.write(f"  Font Size: {strip.font_size}\n")
                f.write(f"  Color: {strip.color[0]:.3f}, {strip.color[1]:.3f}, {strip.color[2]:.3f}\n")
            elif strip.type == 'ADJUSTMENT':
                f.write(f"  Use Crop: {strip.use_crop}\n")
                if strip.use_crop:
                    f.write(f"  Crop Min X: {strip.crop_min_x}\n")
                    f.write(f"  Crop Max X: {strip.crop_max_x}\n")
                    f.write(f"  Crop Min Y: {strip.crop_min_y}\n")
                    f.write(f"  Crop Max Y: {strip.crop_max_y}\n")

print(f'Exported sequencer: {sequencer_name}')
