import bpy
import sys
import os

# Get command line arguments
argv = sys.argv
argv = argv[argv.index('--') + 1:] if '--' in argv else []

# Set export settings
export_path = argv[0] if len(argv) > 0 else 'Assets/VertexGroups/'
vertex_groups_name = argv[1] if len(argv) > 1 else 'DesertVertexGroups'

# Create export directory
if not os.path.exists(export_path):
    os.makedirs(export_path)

# Get current scene
scene = bpy.context.scene

# Export vertex groups file
vertex_groups_path = os.path.join(export_path, f"{vertex_groups_name}.vertex_groups")

# Write vertex groups file
with open(vertex_groups_path, 'w') as f:
    f.write(f"Vertex Groups: {vertex_groups_name}\n")
    f.write(f"Frame Start: {scene.frame_start}\n")
    f.write(f"Frame End: {scene.frame_end}\n")
    f.write(f"FPS: {scene.render.fps}\n")
    
    # Write object vertex groups
    f.write("Object Vertex Groups:\n")
    for obj in scene.objects:
        if obj.vertex_groups:
            f.write(f"  Object: {obj.name}\n")
            for vertex_group in obj.vertex_groups:
                f.write(f"    Vertex Group: {vertex_group.name}\n")
                f.write(f"    Index: {vertex_group.index}\n")
                
                # Write vertex weights
                f.write(f"    Vertex Weights:\n")
                for vertex in obj.data.vertices:
                    for group_element in vertex.groups:
                        if group_element.group == vertex_group.index:
                            f.write(f"      Vertex {vertex.index}: {group_element.weight:.3f}\n")

print(f'Exported vertex groups: {vertex_groups_name}')
