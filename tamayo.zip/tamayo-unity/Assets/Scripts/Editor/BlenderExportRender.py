import bpy
import sys
import os

# Get command line arguments
argv = sys.argv
argv = argv[argv.index('--') + 1:] if '--' in argv else []

# Set export settings
export_path = argv[0] if len(argv) > 0 else 'Assets/Render/'
render_name = argv[1] if len(argv) > 1 else 'DesertRender'

# Create export directory
if not os.path.exists(export_path):
    os.makedirs(export_path)

# Get current scene
scene = bpy.context.scene

# Export render file
render_path = os.path.join(export_path, f"{render_name}.render")

# Write render file
with open(render_path, 'w') as f:
    f.write(f"Render: {render_name}\n")
    f.write(f"Frame Start: {scene.frame_start}\n")
    f.write(f"Frame End: {scene.frame_end}\n")
    f.write(f"FPS: {scene.render.fps}\n")
    
    # Write render settings
    f.write("Render Settings:\n")
    f.write(f"  Engine: {scene.render.engine}\n")
    f.write(f"  Resolution X: {scene.render.resolution_x}\n")
    f.write(f"  Resolution Y: {scene.render.resolution_y}\n")
    f.write(f"  Resolution Percentage: {scene.render.resolution_percentage}\n")
    f.write(f"  Pixel Aspect X: {scene.render.pixel_aspect_x:.3f}\n")
    f.write(f"  Pixel Aspect Y: {scene.render.pixel_aspect_y:.3f}\n")
    f.write(f"  Frame Range: {scene.frame_start} - {scene.frame_end}\n")
    f.write(f"  Frame Step: {scene.frame_step}\n")
    f.write(f"  File Format: {scene.render.image_settings.file_format}\n")
    f.write(f"  Color Mode: {scene.render.image_settings.color_mode}\n")
    f.write(f"  Color Depth: {scene.render.image_settings.color_depth}\n")
    f.write(f"  Compression: {scene.render.image_settings.compression}\n")
    
    # Write output settings
    f.write("Output Settings:\n")
    f.write(f"  Output Path: {scene.render.filepath}\n")
    f.write(f"  File Extension: {scene.render.use_file_extension}\n")
    f.write(f"  Placeholders: {scene.render.use_placeholder}\n")
    f.write(f"  Overwrite: {scene.render.use_overwrite}\n")
    
    # Write performance settings
    f.write("Performance:\n")
    f.write(f"  Threads: {scene.render.threads}\n")
    f.write(f"  Threads Mode: {scene.render.threads_mode}\n")
    f.write(f"  Tile Size X: {scene.render.tile_x}\n")
    f.write(f"  Tile Size Y: {scene.render.tile_y}\n")
    f.write(f"  Use Tiling: {scene.render.use_tiling}\n")

print(f'Exported render: {render_name}')
