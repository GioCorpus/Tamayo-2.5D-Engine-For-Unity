import bpy
import sys
import os

# Get command line arguments
argv = sys.argv
argv = argv[argv.index('--') + 1:] if '--' in argv else []

# Set export settings
export_path = argv[0] if len(argv) > 0 else 'Assets/Animations/'
animation_name = argv[1] if len(argv) > 1 else 'DesertAnimation'

# Create export directory
if not os.path.exists(export_path):
    os.makedirs(export_path)

# Get current scene
scene = bpy.context.scene

# Export animation file
animation_path = os.path.join(export_path, f"{animation_name}.anim")

# Write animation file
with open(animation_path, 'w') as f:
    f.write(f"Animation: {animation_name}\n")
    f.write(f"Frame Start: {scene.frame_start}\n")
    f.write(f"Frame End: {scene.frame_end}\n")
    f.write(f"FPS: {scene.render.fps}\n")
    
    # Write keyframes
    f.write("Keyframes:\n")
    for obj in scene.objects:
        if obj.animation_data and obj.animation_data.action:
            f.write(f"  Object: {obj.name}\n")
            for fcurve in obj.animation_data.action.fcurves:
                f.write(f"    Channel: {fcurve.data_path}[{fcurve.array_index}]\n")
                for keyframe in fcurve.keyframe_points:
                    f.write(f"      Frame: {keyframe.co[0]:.1f}, Value: {keyframe.co[1]:.3f}\n")

print(f'Exported animation: {animation_name}')
