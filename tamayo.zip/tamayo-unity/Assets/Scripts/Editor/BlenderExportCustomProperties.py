import bpy
import sys
import os

# Get command line arguments
argv = sys.argv
argv = argv[argv.index('--') + 1:] if '--' in argv else []

# Set export settings
export_path = argv[0] if len(argv) > 0 else 'Assets/CustomProperties/'
custom_properties_name = argv[1] if len(argv) > 1 else 'DesertCustomProperties'

# Create export directory
if not os.path.exists(export_path):
    os.makedirs(export_path)

# Get current scene
scene = bpy.context.scene

# Export custom properties file
custom_properties_path = os.path.join(export_path, f"{custom_properties_name}.custom_properties")

# Write custom properties file
with open(custom_properties_path, 'w') as f:
    f.write(f"Custom Properties: {custom_properties_name}\n")
    f.write(f"Frame Start: {scene.frame_start}\n")
    f.write(f"Frame End: {scene.frame_end}\n")
    f.write(f"FPS: {scene.render.fps}\n")
    
    # Write object custom properties
    f.write("Object Custom Properties:\n")
    for obj in scene.objects:
        if obj.items():
            f.write(f"  Object: {obj.name}\n")
            for key, value in obj.items():
                f.write(f"    {key}: {value}\n")
    
    # Write scene custom properties
    f.write("Scene Custom Properties:\n")
    for key, value in scene.items():
        f.write(f"  {key}: {value}\n")

print(f'Exported custom properties: {custom_properties_name}')
