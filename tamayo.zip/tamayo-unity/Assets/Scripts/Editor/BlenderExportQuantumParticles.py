import bpy
import sys
import os

# Get command line arguments
argv = sys.argv
argv = argv[argv.index('--') + 1:] if '--' in argv else []

# Set export settings
export_path = argv[0] if len(argv) > 0 else 'Assets/Models/Blender/QuantumParticles.fbx'
apply_transform = True
export_scale = 1.0
export_textures = True
export_materials = True

# Deselect all
bpy.ops.object.select_all(action='DESELECT')

# Select quantum particle objects
for obj in bpy.data.objects:
    if 'quantum' in obj.name.lower() or 'particle' in obj.name.lower() or 'energy' in obj.name.lower():
        obj.select_set(True)

# Export FBX
bpy.ops.export_scene.fbx(
    filepath=export_path,
    use_selection=True,
    apply_scale_options='FBX_SCALE_ALL' if apply_transform else 'FBX_SCALE_NONE',
    axis_forward='-Z',
    axis_up='Y',
    use_mesh_modifiers=True,
    use_mesh_modifiers_render=True,
    mesh_smooth_type='FACE',
    use_subsurf=False,
    use_default_take=True,
    use_anim=False,
    use_anim_action_all=False,
    use_anim_optimize=False,
    use_anim_optimize_precision=6.0,
    use_custom_props=False,
    path_mode='AUTO' if export_textures else 'COPY',
    embed_textures=export_textures,
    batch_mode='OFF',
    use_batch_own_dir=True,
    use_metadata=True,
    global_scale=export_scale
)

print(f'Exported quantum particles to {export_path}')
