import bpy
import sys
import os

# Get command line arguments
argv = sys.argv
argv = argv[argv.index('--') + 1:] if '--' in argv else []

# Set export settings
export_path = argv[0] if len(argv) > 0 else 'Assets/VertexColors/'
vertex_colors_name = argv[1] if len(argv) > 1 else 'DesertVertexColors'

# Create export directory
if not os.path.exists(export_path):
    os.makedirs(export_path)

# Get current scene
scene = bpy.context.scene

# Export vertex colors file
vertex_colors_path = os.path.join(export_path, f"{vertex_colors_name}.vertex_colors")

# Write vertex colors file
with open(vertex_colors_path, 'w') as f:
    f.write(f"Vertex Colors: {vertex_colors_name}\n")
    f.write(f"Frame Start: {scene.frame_start}\n")
    f.write(f"Frame End: {scene.frame_end}\n")
    f.write(f"FPS: {scene.render.fps}\n")
    
    # Write object vertex colors
    f.write("Object Vertex Colors:\n")
    for obj in scene.objects:
        if obj.data and obj.data.vertex_colors:
            f.write(f"  Object: {obj.name}\n")
            for vertex_color in obj.data.vertex_colors:
                f.write(f"    Vertex Color: {vertex_color.name}\n")
                f.write(f"    Active: {vertex_color.active}\n")
                f.write(f"    Active Render: {vertex_color.active_render}\n")

print(f'Exported vertex colors: {vertex_colors_name}')
