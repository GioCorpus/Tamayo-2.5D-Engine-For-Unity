import bpy
import sys
import os

# Get command line arguments
argv = sys.argv
argv = argv[argv.index('--') + 1:] if '--' in argv else []

# Set export settings
export_path = argv[0] if len(argv) > 0 else 'Assets/Particles/'
particle_name = argv[1] if len(argv) > 1 else 'QuantumParticles'

# Create export directory
if not os.path.exists(export_path):
    os.makedirs(export_path)

# Get current scene
scene = bpy.context.scene

# Export particle file
particle_path = os.path.join(export_path, f"{particle_name}.particle")

# Write particle file
with open(particle_path, 'w') as f:
    f.write(f"Particles: {particle_name}\n")
    f.write(f"Frame Start: {scene.frame_start}\n")
    f.write(f"Frame End: {scene.frame_end}\n")
    f.write(f"FPS: {scene.render.fps}\n")
    
    # Write particle systems
    f.write("Particle Systems:\n")
    for obj in scene.objects:
        if obj.particle_systems:
            for ps in obj.particle_systems:
                f.write(f"  Object: {obj.name}\n")
                f.write(f"  System: {ps.name}\n")
                f.write(f"  Count: {ps.settings.count}\n")
                f.write(f"  Lifetime: {ps.settings.lifetime:.3f}\n")
                f.write(f"  Size: {ps.settings.particle_size:.3f}\n")
                f.write(f"  Size Random: {ps.settings.size_random:.3f}\n")
                f.write(f"  Velocity: {ps.settings.normal_factor:.3f}\n")
                f.write(f"  Velocity Random: {ps.settings.factor_random:.3f}\n")
                f.write(f"  Physics: {ps.settings.physics_type}\n")
                f.write(f"  Render: {ps.settings.render_type}\n")

print(f'Exported particles: {particle_name}')
