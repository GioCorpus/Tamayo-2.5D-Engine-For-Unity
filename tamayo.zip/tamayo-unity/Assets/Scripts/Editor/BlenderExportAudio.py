import bpy
import sys
import os

# Get command line arguments
argv = sys.argv
argv = argv[argv.index('--') + 1:] if '--' in argv else []

# Set export settings
export_path = argv[0] if len(argv) > 0 else 'Assets/Audio/'
audio_name = argv[1] if len(argv) > 1 else 'DesertAudio'

# Create export directory
if not os.path.exists(export_path):
    os.makedirs(export_path)

# Get current scene
scene = bpy.context.scene

# Export audio file
audio_path = os.path.join(export_path, f"{audio_name}.audio")

# Write audio file
with open(audio_path, 'w') as f:
    f.write(f"Audio: {audio_name}\n")
    f.write(f"Frame Start: {scene.frame_start}\n")
    f.write(f"Frame End: {scene.frame_end}\n")
    f.write(f"FPS: {scene.render.fps}\n")
    
    # Write audio sequences
    f.write("Audio Sequences:\n")
    if scene.sequence_editor:
        for sequence in scene.sequence_editor.sequences:
            if sequence.type == 'SOUND':
                f.write(f"  Sequence: {sequence.name}\n")
                f.write(f"  File: {sequence.sound.filepath}\n")
                f.write(f"  Frame Start: {sequence.frame_start}\n")
                f.write(f"  Frame End: {sequence.frame_final_end}\n")
                f.write(f"  Volume: {sequence.volume:.3f}\n")
                f.write(f"  Pitch: {sequence.pitch:.3f}\n")
                f.write(f"  Pan: {sequence.pan:.3f}\n")

print(f'Exported audio: {audio_name}')
