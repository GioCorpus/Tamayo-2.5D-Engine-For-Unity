import bpy
import sys
import os

# Get command line arguments
argv = sys.argv
argv = argv[argv.index('--') + 1:] if '--' in argv else []

# Set export settings
export_path = argv[0] if len(argv) > 0 else 'Assets/Modifiers/'
modifiers_name = argv[1] if len(argv) > 1 else 'DesertModifiers'

# Create export directory
if not os.path.exists(export_path):
    os.makedirs(export_path)

# Get current scene
scene = bpy.context.scene

# Export modifiers file
modifiers_path = os.path.join(export_path, f"{modifiers_name}.modifiers")

# Write modifiers file
with open(modifiers_path, 'w') as f:
    f.write(f"Modifiers: {modifiers_name}\n")
    f.write(f"Frame Start: {scene.frame_start}\n")
    f.write(f"Frame End: {scene.frame_end}\n")
    f.write(f"FPS: {scene.render.fps}\n")
    
    # Write object modifiers
    f.write("Object Modifiers:\n")
    for obj in scene.objects:
        if obj.modifiers:
            f.write(f"  Object: {obj.name}\n")
            for modifier in obj.modifiers:
                f.write(f"    Modifier: {modifier.name}\n")
                f.write(f"    Type: {modifier.type}\n")
                f.write(f"    Enabled: {modifier.show_viewport}\n")
                f.write(f"    Render: {modifier.show_render}\n")
                f.write(f"    Apply: {modifier.show_in_editmode}\n")
                
                # Write modifier-specific properties
                if modifier.type == 'SUBSURF':
                    f.write(f"      Levels: {modifier.levels}\n")
                    f.write(f"      Render Levels: {modifier.render_levels}\n")
                    f.write(f"      Use Creases: {modifier.use_creases}\n")
                    f.write(f"      Use Custom Normals: {modifier.use_custom_normals}\n")
                elif modifier.type == 'ARRAY':
                    f.write(f"      Count: {modifier.count}\n")
                    f.write(f"      Use Relative Offset: {modifier.use_relative_offset}\n")
                    f.write(f"      Relative Offset: {modifier.relative_offset_displace[0]:.3f}, {modifier.relative_offset_displace[1]:.3f}, {modifier.relative_offset_displace[2]:.3f}\n")
                    f.write(f"      Use Constant Offset: {modifier.use_constant_offset}\n")
                    f.write(f"      Constant Offset: {modifier.constant_offset_displace[0]:.3f}, {modifier.constant_offset_displace[1]:.3f}, {modifier.constant_offset_displace[2]:.3f}\n")
                    f.write(f"      Use Merge: {modifier.use_merge_vertices}\n")
                    f.write(f"      Merge Distance: {modifier.merge_threshold:.3f}\n")
                elif modifier.type == 'MIRROR':
                    f.write(f"      Use X: {modifier.use_axis[0]}\n")
                    f.write(f"      Use Y: {modifier.use_axis[1]}\n")
                    f.write(f"      Use Z: {modifier.use_axis[2]}\n")
                    f.write(f"      Use Mirror Merge: {modifier.use_mirror_merge}\n")
                    f.write(f"      Merge Limit: {modifier.merge_threshold:.3f}\n")
                    f.write(f"      Use Mirror U: {modifier.use_mirror_u}\n")
                    f.write(f"      Use Mirror V: {modifier.use_mirror_v}\n")
                elif modifier.type == 'BOOLEAN':
                    f.write(f"      Operation: {modifier.operation}\n")
                    f.write(f"      Object: {modifier.object.name if modifier.object else 'None'}\n")
                    f.write(f"      Use Self Intersection: {modifier.use_self}\n")
                    f.write(f"      Use Hole Tolerant: {modifier.use_hole_tolerant}\n")
                elif modifier.type == 'BEVEL':
                    f.write(f"      Width: {modifier.width:.3f}\n")
                    f.write(f"      Segments: {modifier.segments}\n")
                    f.write(f"      Use Only Vertices: {modifier.use_only_vertices}\n")
                    f.write(f"      Clamp Overlap: {modifier.use_clamp_overlap}\n")
                    f.write(f"      Loop Slide: {modifier.loop_slide}\n")
                elif modifier.type == 'EDGE_SPLIT':
                    f.write(f"      Split Angle: {modifier.split_angle:.3f}\n")
                    f.write(f"      Use Edge Angle: {modifier.use_edge_angle}\n")
                    f.write(f"      Use Sharp Edges: {modifier.use_edge_sharp}\n")
                elif modifier.type == 'DISPLACE':
                    f.write(f"      Direction: {modifier.direction}\n")
                    f.write(f"      Space: {modifier.space}\n")
                    f.write(f"      Strength: {modifier.strength:.3f}\n")
                    f.write(f"      Midlevel: {modifier.mid_level:.3f}\n")
                    f.write(f"      Texture: {modifier.texture.name if modifier.texture else 'None'}\n")
                elif modifier.type == 'SMOOTH':
                    f.write(f"      Factor: {modifier.factor:.3f}\n")
                    f.write(f"      Iterations: {modifier.iterations}\n")
                    f.write(f"      Use X: {modifier.use_x}\n")
                    f.write(f"      Use Y: {modifier.use_y}\n")
                    f.write(f"      Use Z: {modifier.use_z}\n")
                elif modifier.type == 'CAST':
                    f.write(f"      Type: {modifier.cast_type}\n")
                    f.write(f"      Factor: {modifier.factor:.3f}\n")
                    f.write(f"      Radius: {modifier.radius:.3f}\n")
                    f.write(f"      Size: {modifier.size:.3f}\n")
                    f.write(f"      Use X: {modifier.use_x}\n")
                    f.write(f"      Use Y: {modifier.use_y}\n")
                    f.write(f"      Use Z: {modifier.use_z}\n")
                elif modifier.type == 'WAVE':
                    f.write(f"      Use X: {modifier.use_x}\n")
                    f.write(f"      Use Y: {modifier.use_y}\n")
                    f.write(f"      Use Z: {modifier.use_z}\n")
                    f.write(f"      Use Normal: {modifier.use_normal}\n")
                    f.write(f"      Height: {modifier.height:.3f}\n")
                    f.write(f"      Width: {modifier.width:.3f}\n")
                    f.write(f"      Narrow: {modifier.narrow:.3f}\n")
                    f.write(f"      Speed: {modifier.speed:.3f}\n")
                    f.write(f"      Lifetime: {modifier.lifetime:.3f}\n")
                    f.write(f"      Damping: {modifier.damping:.3f}\n")
                elif modifier.type == 'ARMATURE':
                    f.write(f"      Object: {modifier.object.name if modifier.object else 'None'}\n")
                    f.write(f"      Use Deform Preserve Volume: {modifier.use_deform_preserve_volume}\n")
                    f.write(f"      Use Multi Modifier: {modifier.use_multi_modifier}\n")
                elif modifier.type == 'CLOTH':
                    f.write(f"      Quality: {modifier.settings.quality}\n")
                    f.write(f"      Use Self Collision: {modifier.settings.use_self_collision}\n")
                    f.write(f"      Self Collision Distance: {modifier.settings.self_collision_distance:.3f}\n")
                    f.write(f"      Self Collision Impulse Clamping: {modifier.settings.self_collision_impulse_clamp:.3f}\n")
                elif modifier.type == 'COLLISION':
                    f.write(f"      Use Kill Particles: {modifier.settings.use_particle_kill}\n")
                    f.write(f"      Damping: {modifier.settings.damping:.3f}\n")
                    f.write(f"      Damping Random: {modifier.settings.damping_factor:.3f}\n")
                    f.write(f"      Friction: {modifier.settings.friction:.3f}\n")
                    f.write(f"      Friction Random: {modifier.settings.friction_factor:.3f}\n")
                elif modifier.type == 'FLUID':
                    f.write(f"      Type: {modifier.settings.type}\n")
                    f.write(f"      Use: {modifier.settings.use}\n")
                elif modifier.type == 'PARTICLE_INSTANCE':
                    f.write(f"      Object: {modifier.object.name if modifier.object else 'None'}\n")
                    f.write(f"      Particle System: {modifier.particle_system.name if modifier.particle_system else 'None'}\n")
                    f.write(f"      Use Normal: {modifier.use_normal}\n")
                    f.write(f"      Use Children: {modifier.use_children}\n")
                    f.write(f"      Use Size: {modifier.use_size}\n")
                elif modifier.type == 'PARTICLE_SYSTEM':
                    f.write(f"      Particle System: {modifier.particle_system.name if modifier.particle_system else 'None'}\n")
                elif modifier.type == 'SHRINKWRAP':
                    f.write(f"      Target: {modifier.target.name if modifier.target else 'None'}\n")
                    f.write(f"      Mode: {modifier.wrap_method}\n")
                    f.write(f"      Use Negative: {modifier.use_negative_direction}\n")
                    f.write(f"      Use Positive: {modifier.use_positive_direction}\n")
                    f.write(f"      Offset: {modifier.offset:.3f}\n")
                elif modifier.type == 'SIMPLE_DEFORM':
                    f.write(f"      Deform Method: {modifier.deform_method}\n")
                    f.write(f"      Origin: {modifier.origin.name if modifier.origin else 'None'}\n")
                    f.write(f"      Factor: {modifier.factor:.3f}\n")
                    f.write(f"      Angle: {modifier.angle:.3f}\n")
                    f.write(f"      Limits: {modifier.limit[0]:.3f}, {modifier.limit[1]:.3f}\n")
                elif modifier.type == 'SOLIDIFY':
                    f.write(f"      Thickness: {modifier.thickness:.3f}\n")
                    f.write(f"      Offset: {modifier.offset:.3f}\n")
                    f.write(f"      Use Even: {modifier.use_even_offset}\n")
                    f.write(f"      Use Quality: {modifier.use_quality_normals}\n")
                    f.write(f"      Use Rims: {modifier.use_rim}\n")
                    f.write(f"      Use Rim: {modifier.use_rim_only}\n")
                elif modifier.type == 'UV_PROJECT':
                    f.write(f"      Object: {modifier.object.name if modifier.object else 'None'}\n")
                    f.write(f"      UV Layer: {modifier.uv_layer}\n")
                    f.write(f"      Use Image: {modifier.use_image}\n")
                    f.write(f"      Image: {modifier.image.name if modifier.image else 'None'}\n")
                elif modifier.type == 'WARP':
                    f.write(f"      Object From: {modifier.object_from.name if modifier.object_from else 'None'}\n")
                    f.write(f"      Object To: {modifier.object_to.name if modifier.object_to else 'None'}\n")
                    f.write(f"      Strength: {modifier.strength:.3f}\n")
                    f.write(f"      Falloff: {modifier.falloff_radius:.3f}\n")
                    f.write(f"      Use Volume: {modifier.use_volume_preserve}\n")
                elif modifier.type == 'WIREFRAME':
                    f.write(f"      Thickness: {modifier.thickness:.3f}\n")
                    f.write(f"      Offset: {modifier.offset:.3f}\n")
                    f.write(f"      Use Even: {modifier.use_even_offset}\n")
                    f.write(f"      Use Relative: {modifier.use_relative_offset}\n")
                    f.write(f"      Use Replace: {modifier.use_replace}\n")
                    f.write(f"      Use Boundary: {modifier.use_boundary}\n")
                    f.write(f"      Use Crease: {modifier.use_crease}\n")
                    f.write(f"      Crease Weight: {modifier.crease_weight:.3f}\n")
                elif modifier.type == 'DATA_TRANSFER':
                    f.write(f"      Object: {modifier.object.name if modifier.object else 'None'}\n")
                    f.write(f"      Use Object Transform: {modifier.use_object_transform}\n")
                    f.write(f"      Use Loop Data: {modifier.use_loop_data}\n")
                    f.write(f"      Use Poly Data: {modifier.use_poly_data}\n")
                    f.write(f"      Use Edge Data: {modifier.use_edge_data}\n")
                    f.write(f"      Use Vert Data: {modifier.use_vert_data}\n")
                elif modifier.type == 'MESH_CACHE':
                    f.write(f"      Cache Format: {modifier.cache_format}\n")
                    f.write(f"      Evaluation Mode: {modifier.evaluation_mode}\n")
                    f.write(f"      Play Mode: {modifier.play_mode}\n")
                    f.write(f"      Frame Start: {modifier.frame_start}\n")
                    f.write(f"      Frame Scale: {modifier.frame_scale:.3f}\n")
                    f.write(f"      Influence: {modifier.influence:.3f}\n")
                elif modifier.type == 'LAPLACIANDEFORM':
                    f.write(f"      Iterations: {modifier.iterations}\n")
                    f.write(f"      Use Mesh: {modifier.use_mesh}\n")
                    f.write(f"      Use Bind: {modifier.is_bind}\n")
                elif modifier.type == 'LAPLACIANSMOOTH':
                    f.write(f"      Lambda Factor: {modifier.lambda_factor:.3f}\n")
                    f.write(f"      Lambda Border: {modifier.lambda_border:.3f}\n")
                    f.write(f"      Use X: {modifier.use_x}\n")
                    f.write(f"      Use Y: {modifier.use_y}\n")
                    f.write(f"      Use Z: {modifier.use_z}\n")
                    f.write(f"      Use Volume: {modifier.preserve_volume}\n")
                elif modifier.type == 'CORRECTIVE_SMOOTH':
                    f.write(f"      Factor: {modifier.factor:.3f}\n")
                    f.write(f"      Iterations: {modifier.iterations}\n")
                    f.write(f"      Scale: {modifier.scale:.3f}\n")
                    f.write(f"      Smooth Type: {modifier.smooth_type}\n")
                    f.write(f"      Use Only Smooth: {modifier.use_only_smooth}\n")
                    f.write(f"      Use Pin Boundaries: {modifier.use_pin_boundary}\n")
                elif modifier.type == 'SURFACE_DEFORM':
                    f.write(f"      Target: {modifier.target.name if modifier.target else 'None'}\n")
                    f.write(f"      Falloff: {modifier.falloff:.3f}\n")
                    f.write(f"      Strength: {modifier.strength:.3f}\n")
                    f.write(f"      Use Sparse Bind: {modifier.use_sparse_bind}\n")
                elif modifier.type == 'MESH_DEFORM':
                    f.write(f"      Object: {modifier.object.name if modifier.object else 'None'}\n")
                    f.write(f"      Precision: {modifier.precision}\n")
                    f.write(f"      Use Dynamic: {modifier.use_dynamic_bind}\n")
                elif modifier.type == 'DECIMATE':
                    f.write(f"      Decimate Type: {modifier.decimate_type}\n")
                    f.write(f"      Ratio: {modifier.ratio:.3f}\n")
                    f.write(f"      Use Symmetry: {modifier.use_symmetry}\n")
                    f.write(f"      Symmetry Axis: {modifier.symmetry_axis}\n")
                    f.write(f"      Use Even: {modifier.use_even}\n")
                    f.write(f"      Use Sharp: {modifier.use_sharp}\n")
                    f.write(f"      Use Material Boundaries: {modifier.use_material_boundaries}\n")
                elif modifier.type == 'REMESH':
                    f.write(f"      Mode: {modifier.mode}\n")
                    f.write(f"      Octree Depth: {modifier.octree_depth}\n")
                    f.write(f"      Scale: {modifier.scale:.3f}\n")
                    f.write(f"      Sharpness: {modifier.sharpness:.3f}\n")
                    f.write(f"      Use Smooth: {modifier.use_smooth_shade}\n")
                    f.write(f"      Use Remove Disconnected: {modifier.use_remove_disconnected}\n")
                elif modifier.type == 'TRIANGULATE':
                    f.write(f"      Quad Method: {modifier.quad_method}\n")
                    f.write(f"      Ngon Method: {modifier.ngon_method}\n")
                    f.write(f"      Minimum Vertices: {modifier.min_vertices}\n")
                    f.write(f"      Use Beauty: {modifier.use_beauty}\n")
                elif modifier.type == 'UV_WARP':
                    f.write(f"      Object From: {modifier.object_from.name if modifier.object_from else 'None'}\n")
                    f.write(f"      Object To: {modifier.object_to.name if modifier.object_to else 'None'}\n")
                    f.write(f"      UV Layer: {modifier.uv_layer}\n")
                    f.write(f"      Center: {modifier.center[0]:.3f}, {modifier.center[1]:.3f}\n")
                elif modifier.type == 'VERTEX_WEIGHT_EDIT':
                    f.write(f"      Vertex Group: {modifier.vertex_group}\n")
                    f.write(f"      Default Weight: {modifier.default_weight:.3f}\n")
                    f.write(f"      Use Add: {modifier.use_add}\n")
                    f.write(f"      Use Remove: {modifier.use_remove}\n")
                    f.write(f"      Add Threshold: {modifier.add_threshold:.3f}\n")
                    f.write(f"      Remove Threshold: {modifier.remove_threshold:.3f}\n")
                elif modifier.type == 'VERTEX_WEIGHT_PROXIMITY':
                    f.write(f"      Vertex Group: {modifier.vertex_group}\n")
                    f.write(f"      Target: {modifier.target.name if modifier.target else 'None'}\n")
                    f.write(f"      Proximity Mode: {modifier.proximity_mode}\n")
                    f.write(f"      Proximity Geometry: {modifier.proximity_geometry}\n")
                    f.write(f"      Min Distance: {modifier.min_dist:.3f}\n")
                    f.write(f"      Max Distance: {modifier.max_dist:.3f}\n")
                elif modifier.type == 'VERTEX_WEIGHT_MIX':
                    f.write(f"      Vertex Group A: {modifier.vertex_group_a}\n")
                    f.write(f"      Vertex Group B: {modifier.vertex_group_b}\n")
                    f.write(f"      Default Weight A: {modifier.default_weight_a:.3f}\n")
                    f.write(f"      Default Weight B: {modifier.default_weight_b:.3f}\n")
                    f.write(f"      Mix Mode: {modifier.mix_mode}\n")
                    f.write(f"      Mix Set: {modifier.mix_set}\n")
                elif modifier.type == 'SKIN':
                    f.write(f"      Branch Smoothing: {modifier.branch_smoothing:.3f}\n")
                    f.write(f"      Use Smooth: {modifier.use_smooth_shade}\n")
                elif modifier.type == 'MASK':
                    f.write(f"      Vertex Group: {modifier.vertex_group}\n")
                    f.write(f"      Use Invert: {modifier.invert_vertex_group}\n")
                elif modifier.type == 'HOOK':
                    f.write(f"      Object: {modifier.object.name if modifier.object else 'None'}n")
                    f.write(f"      Vertex Group: {modifier.vertex_group}\n")
                    f.write(f"      Strength: {modifier.strength:.3f}\n")
                    f.write(f"      Falloff: {modifier.falloff:.3f}\n")
                elif modifier.type == 'SOFT_BODY':
                    f.write(f"      Friction: {modifier.settings.friction:.3f}\n")
                    f.write(f"      Mass: {modifier.settings.mass:.3f}\n")
                    f.write(f"      Speed: {modifier.settings.speed:.3f}\n")
                elif modifier.type == 'MULTIRES':
                    f.write(f"      Levels: {modifier.levels}\n")
                    f.write(f"      Render Levels: {modifier.render_levels}\n")
                    f.write(f"      Sculpt Levels: {modifier.sculpt_levels}\n")
                    f.write(f"      Use Sculpt: {modifier.use_sculpt}\n")
                elif modifier.type == 'DYNAMIC_PAINT':
                    f.write(f"      Canvas Settings: {modifier.canvas_settings.name if modifier.canvas_settings else 'None'}\n")
                    f.write(f"      Brush Settings: {modifier.brush_settings.name if modifier.brush_settings else 'None'}\n")
                elif modifier.type == 'OCEAN':
                    f.write(f"      Geometry Mode: {modifier.geometry_mode}\n")
                    f.write(f"      Size: {modifier.size:.3f}\n")
                    f.write(f"      Repeat X: {modifier.repeat_x}\n")
                    f.write(f"      Repeat Y: {modifier.repeat_y}\n")
                    f.write(f"      Use Normals: {modifier.use_normals}\n")
                    f.write(f"      Use Foam: {modifier.use_foam}\n")
                elif modifier.type == 'EXPLODE':
                    f.write(f"      Use Edge Cut: {modifier.use_edge_cut}\n")
                    f.write(f"      Use Unborn: {modifier.show_unborn}\n")
                    f.write(f"      Use Alive: {modifier.show_alive}\n")
                    f.write(f"      Use Dead: {modifier.show_dead}\n")
                elif modifier.type == 'FLUID_SIMULATION':
                    f.write(f"      Settings: {modifier.settings.name if modifier.settings else 'None'}\n")
                elif modifier.type == 'SMOKE':
                    f.write(f"      Flow Settings: {modifier.flow_settings.name if modifier.flow_settings else 'None'}\n")
                    f.write(f"      Coll Settings: {modifier.coll_settings.name if modifier.coll_settings else 'None'}\n")
                elif modifier.type == 'MULTIRES':
                    f.write(f"      Levels: {modifier.levels}\n")
                    f.write(f"      Render Levels: {modifier.render_levels}\n")
                    f.write(f"      Sculpt Levels: {modifier.sculpt_levels}\n")
                    f.write(f"      Use Sculpt: {modifier.use_sculpt}\n")
                elif modifier.type == 'DYNAMIC_PAINT':
                    f.write(f"      Canvas Settings: {modifier.canvas_settings.name if modifier.canvas_settings else 'None'}\n")
                    f.write(f"      Brush Settings: {modifier.brush_settings.name if modifier.brush_settings else 'None'}\n")
                elif modifier.type == 'OCEAN':
                    f.write(f"      Geometry Mode: {modifier.geometry_mode}\n")
                    f.write(f"      Size: {modifier.size:.3f}\n")
                    f.write(f"      Repeat X: {modifier.repeat_x}\n")
                    f.write(f"      Repeat Y: {modifier.repeat_y}\n")
                    f.write(f"      Use Normals: {modifier.use_normals}\n")
                    f.write(f"      Use Foam: {modifier.use_foam}\n")
                elif modifier.type == 'EXPLODE':
                    f.write(f"      Use Edge Cut: {modifier.use_edge_cut}\n")
                    f.write(f"      Use Unborn: {modifier.show_unborn}\n")
                    f.write(f"      Use Alive: {modifier.show_alive}\n")
                    f.write(f"      Use Dead: {modifier.show_dead}\n")
                elif modifier.type == 'FLUID_SIMULATION':
                    f.write(f"      Settings: {modifier.settings.name if modifier.settings else 'None'}\n")
                elif modifier.type == 'SMOKE':
                    f.write(f"      Flow Settings: {modifier.flow_settings.name if modifier.flow_settings else 'None'}\n")
                    f.write(f"      Coll Settings: {modifier.coll_settings.name if modifier.coll_settings else 'None'}\n")

print(f'Exported modifiers: {modifiers_name}')
