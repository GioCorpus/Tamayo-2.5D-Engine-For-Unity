import bpy
import sys
import os

# Get command line arguments
argv = sys.argv
argv = argv[argv.index('--') + 1:] if '--' in argv else []

# Set export settings
export_path = argv[0] if len(argv) > 0 else 'Assets/ShapeKeys/'
shape_keys_name = argv[1] if len(argv) > 1 else 'DesertShapeKeys'

# Create export directory
if not os.path.exists(export_path):
    os.makedirs(export_path)

# Get current scene
scene = bpy.context.scene

# Export shape keys file
shape_keys_path = os.path.join(export_path, f"{shape_keys_name}.shape_keys")

# Write shape keys file
with open(shape_keys_path, 'w') as f:
    f.write(f"Shape Keys: {shape_keys_name}\n")
    f.write(f"Frame Start: {scene.frame_start}\n")
    f.write(f"Frame End: {scene.frame_end}\n")
    f.write(f"FPS: {scene.render.fps}\n")
    
    # Write object shape keys
    f.write("Object Shape Keys:\n")
    for obj in scene.objects:
        if obj.data and obj.data.shape_keys:
            f.write(f"  Object: {obj.name}\n")
            for shape_key in obj.data.shape_keys.key_blocks:
                f.write(f"    Shape Key: {shape_key.name}\n")
                f.write(f"    Value: {shape_key.value:.3f}\n")
                f.write(f"    Slider Min: {shape_key.slider_min:.3f}\n")
                f.write(f"    Slider Max: {shape_key.slider_max:.3f}\n")
                f.write(f"    Relative Key: {shape_key.relative_key.name if shape_key.relative_key else 'None'}\n")
                f.write(f"    Vertex Group: {shape_key.vertex_group}\n")
                f.write(f"    Interpolation: {shape_key.interpolation}\n")
                f.write(f"    Use: {shape_key.mute}\n")

print(f'Exported shape keys: {shape_keys_name}')
