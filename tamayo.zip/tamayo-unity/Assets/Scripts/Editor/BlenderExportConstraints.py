import bpy
import sys
import os

# Get command line arguments
argv = sys.argv
argv = argv[argv.index('--') + 1:] if '--' in argv else []

# Set export settings
export_path = argv[0] if len(argv) > 0 else 'Assets/Constraints/'
constraints_name = argv[1] if len(argv) > 1 else 'DesertConstraints'

# Create export directory
if not os.path.exists(export_path):
    os.makedirs(export_path)

# Get current scene
scene = bpy.context.scene

# Export constraints file
constraints_path = os.path.join(export_path, f"{constraints_name}.constraints")

# Write constraints file
with open(constraints_path, 'w') as f:
    f.write(f"Constraints: {constraints_name}\n")
    f.write(f"Frame Start: {scene.frame_start}\n")
    f.write(f"Frame End: {scene.frame_end}\n")
    f.write(f"FPS: {scene.render.fps}\n")
    
    # Write object constraints
    f.write("Object Constraints:\n")
    for obj in scene.objects:
        if obj.constraints:
            f.write(f"  Object: {obj.name}\n")
            for constraint in obj.constraints:
                f.write(f"    Constraint: {constraint.name}\n")
                f.write(f"    Type: {constraint.type}\n")
                f.write(f"    Enabled: {constraint.enabled}\n")
                f.write(f"    Influence: {constraint.influence:.3f}\n")
                
                # Write constraint-specific properties
                if constraint.type == 'COPY_LOCATION':
                    f.write(f"      Target: {constraint.target.name if constraint.target else 'None'}\n")
                    f.write(f"      Use X: {constraint.use_x}\n")
                    f.write(f"      Use Y: {constraint.use_y}\n")
                    f.write(f"      Use Z: {constraint.use_z}\n")
                    f.write(f"      Invert X: {constraint.invert_x}\n")
                    f.write(f"      Invert Y: {constraint.invert_y}\n")
                    f.write(f"      Invert Z: {constraint.invert_z}\n")
                elif constraint.type == 'COPY_ROTATION':
                    f.write(f"      Target: {constraint.target.name if constraint.target else 'None'}\n")
                    f.write(f"      Use X: {constraint.use_x}\n")
                    f.write(f"      Use Y: {constraint.use_y}\n")
                    f.write(f"      Use Z: {constraint.use_z}\n")
                    f.write(f"      Invert X: {constraint.invert_x}\n")
                    f.write(f"      Invert Y: {constraint.invert_y}\n")
                    f.write(f"      Invert Z: {constraint.invert_z}\n")
                elif constraint.type == 'COPY_SCALE':
                    f.write(f"      Target: {constraint.target.name if constraint.target else 'None'}\n")
                    f.write(f"      Use X: {constraint.use_x}\n")
                    f.write(f"      Use Y: {constraint.use_y}\n")
                    f.write(f"      Use Z: {constraint.use_z}\n")
                    f.write(f"      Power: {constraint.power:.3f}\n")
                elif constraint.type == 'LIMIT_LOCATION':
                    f.write(f"      Use Min X: {constraint.use_min_x}\n")
                    f.write(f"      Use Min Y: {constraint.use_min_y}\n")
                    f.write(f"      Use Min Z: {constraint.use_min_z}\n")
                    f.write(f"      Use Max X: {constraint.use_max_x}\n")
                    f.write(f"      Use Max Y: {constraint.use_max_y}\n")
                    f.write(f"      Use Max Z: {constraint.use_max_z}\n")
                    f.write(f"      Min X: {constraint.min_x:.3f}\n")
                    f.write(f"      Min Y: {constraint.min_y:.3f}\n")
                    f.write(f"      Min Z: {constraint.min_z:.3f}\n")
                    f.write(f"      Max X: {constraint.max_x:.3f}\n")
                    f.write(f"      Max Y: {constraint.max_y:.3f}\n")
                    f.write(f"      Max Z: {constraint.max_z:.3f}\n")
                elif constraint.type == 'LIMIT_ROTATION':
                    f.write(f"      Use Limit X: {constraint.use_limit_x}\n")
                    f.write(f"      Use Limit Y: {constraint.use_limit_y}\n")
                    f.write(f"      Use Limit Z: {constraint.use_limit_z}\n")
                    f.write(f"      Min X: {constraint.min_x:.3f}\n")
                    f.write(f"      Min Y: {constraint.min_y:.3f}\n")
                    f.write(f"      Min Z: {constraint.min_z:.3f}\n")
                    f.write(f"      Max X: {constraint.max_x:.3f}\n")
                    f.write(f"      Max Y: {constraint.max_y:.3f}\n")
                    f.write(f"      Max Z: {constraint.max_z:.3f}\n")
                elif constraint.type == 'LIMIT_SCALE':
                    f.write(f"      Use Min X: {constraint.use_min_x}\n")
                    f.write(f"      Use Min Y: {constraint.use_min_y}\n")
                    f.write(f"      Use Min Z: {constraint.use_min_z}\n")
                    f.write(f"      Use Max X: {constraint.use_max_x}\n")
                    f.write(f"      Use Max Y: {constraint.use_max_y}\n")
                    f.write(f"      Use Max Z: {constraint.use_max_z}\n")
                    f.write(f"      Min X: {constraint.min_x:.3f}\n")
                    f.write(f"      Min Y: {constraint.min_y:.3f}\n")
                    f.write(f"      Min Z: {constraint.min_z:.3f}\n")
                    f.write(f"      Max X: {constraint.max_x:.3f}\n")
                    f.write(f"      Max Y: {constraint.max_y:.3f}\n")
                    f.write(f"      Max Z: {constraint.max_z:.3f}\n")
                elif constraint.type == 'TRACK_TO':
                    f.write(f"      Target: {constraint.target.name if constraint.target else 'None'}\n")
                    f.write(f"      Track Axis: {constraint.track_axis}\n")
                    f.write(f"      Up Axis: {constraint.up_axis}\n")
                    f.write(f"      Use Target Z: {constraint.use_target_z}\n")
                elif constraint.type == 'DAMPED_TRACK':
                    f.write(f"      Target: {constraint.target.name if constraint.target else 'None'}\n")
                    f.write(f"      Track Axis: {constraint.track_axis}\n")
                elif constraint.type == 'IK':
                    f.write(f"      Target: {constraint.target.name if constraint.target else 'None'}\n")
                    f.write(f"      Chain Length: {constraint.chain_count}\n")
                    f.write(f"      Use Tail: {constraint.use_tail}\n")
                    f.write(f"      Influence: {constraint.influence:.3f}\n")
                elif constraint.type == 'FLOOR':
                    f.write(f"      Target: {constraint.target.name if constraint.target else 'None'}\n")
                    f.write(f"      Floor Location: {constraint.floor_location}\n")
                    f.write(f"      Use Rotation: {constraint.use_rotation}\n")
                elif constraint.type == 'RIGID_BODY_JOINT':
                    f.write(f"      Target: {constraint.target.name if constraint.target else 'None'}\n")
                    f.write(f"      Pivot Type: {constraint.pivot_type}\n")
                    f.write(f"      Use Linked Collision: {constraint.use_linked_collision}\n")
                    f.write(f"      Use Override Solver: {constraint.use_override_solver}\n")
                    f.write(f"      Solver Iterations: {constraint.solver_iterations}\n")

print(f'Exported constraints: {constraints_name}')
