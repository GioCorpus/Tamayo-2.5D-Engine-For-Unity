import bpy
import sys
import os

# Get command line arguments
argv = sys.argv
argv = argv[argv.index('--') + 1:] if '--' in argv else []

# Set export settings
export_path = argv[0] if len(argv) > 0 else 'Assets/Nodes/'
nodes_name = argv[1] if len(argv) > 1 else 'DesertNodes'

# Create export directory
if not os.path.exists(export_path):
    os.makedirs(export_path)

# Get current scene
scene = bpy.context.scene

# Export nodes file
nodes_path = os.path.join(export_path, f"{nodes_name}.nodes")

# Write nodes file
with open(nodes_path, 'w') as f:
    f.write(f"Nodes: {nodes_name}\n")
    f.write(f"Frame Start: {scene.frame_start}\n")
    f.write(f"Frame End: {scene.frame_end}\n")
    f.write(f"FPS: {scene.render.fps}\n")
    
    # Write material nodes
    f.write("Material Nodes:\n")
    for material in bpy.data.materials:
        if material.use_nodes:
            f.write(f"  Material: {material.name}\n")
            for node in material.node_tree.nodes:
                f.write(f"    Node: {node.name}\n")
                f.write(f"    Type: {node.type}\n")
                f.write(f"    Location: {node.location[0]:.1f}, {node.location[1]:.1f}\n")
                
                # Write node inputs
                for input in node.inputs:
                    f.write(f"      Input: {input.name} ({input.type})\n")
                    if input.type == 'VALUE':
                        f.write(f"        Default: {input.default_value:.3f}\n")
                    elif input.type == 'RGBA':
                        f.write(f"        Default: {input.default_value[0]:.3f}, {input.default_value[1]:.3f}, {input.default_value[2]:.3f}, {input.default_value[3]:.3f}\n")
                    elif input.type == 'VECTOR':
                        f.write(f"        Default: {input.default_value[0]:.3f}, {input.default_value[1]:.3f}, {input.default_value[2]:.3f}\n")
                
                # Write node outputs
                for output in node.outputs:
                    f.write(f"      Output: {output.name} ({output.type})\n")
    
    # Write world nodes
    f.write("World Nodes:\n")
    if scene.world and scene.world.use_nodes:
        f.write(f"  World: {scene.world.name}\n")
        for node in scene.world.node_tree.nodes:
            f.write(f"    Node: {node.name}\n")
            f.write(f"    Type: {node.type}\n")
            f.write(f"    Location: {node.location[0]:.1f}, {node.location[1]:.1f}\n")
            
            # Write node inputs
            for input in node.inputs:
                f.write(f"      Input: {input.name} ({input.type})\n")
                if input.type == 'VALUE':
                    f.write(f"        Default: {input.default_value:.3f}\n")
                elif input.type == 'RGBA':
                    f.write(f"        Default: {input.default_value[0]:.3f}, {input.default_value[1]:.3f}, {input.default_value[2]:.3f}, {input.default_value[3]:.3f}\n")
                elif input.type == 'VECTOR':
                    f.write(f"        Default: {input.default_value[0]:.3f}, {input.default_value[1]:.3f}, {input.default_value[2]:.3f}\n")
            
            # Write node outputs
            for output in node.outputs:
                f.write(f"      Output: {output.name} ({output.type})\n")

print(f'Exported nodes: {nodes_name}')
