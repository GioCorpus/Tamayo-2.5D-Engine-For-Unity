import bpy
import sys
import os

# Get command line arguments
argv = sys.argv
argv = argv[argv.index('--') + 1:] if '--' in argv else []

# Set export settings
export_path = argv[0] if len(argv) > 0 else 'Assets/Physics/'
physics_name = argv[1] if len(argv) > 1 else 'DesertPhysics'

# Create export directory
if not os.path.exists(export_path):
    os.makedirs(export_path)

# Get current scene
scene = bpy.context.scene

# Export physics file
physics_path = os.path.join(export_path, f"{physics_name}.physics")

# Write physics file
with open(physics_path, 'w') as f:
    f.write(f"Physics: {physics_name}\n")
    f.write(f"Frame Start: {scene.frame_start}\n")
    f.write(f"Frame End: {scene.frame_end}\n")
    f.write(f"FPS: {scene.render.fps}\n")
    
    # Write rigid body settings
    f.write("Rigid Bodies:\n")
    for obj in scene.objects:
        if obj.rigid_body:
            f.write(f"  Object: {obj.name}\n")
            f.write(f"  Type: {obj.rigid_body.type}\n")
            f.write(f"  Mass: {obj.rigid_body.mass:.3f}\n")
            f.write(f"  Friction: {obj.rigid_body.friction:.3f}\n")
            f.write(f"  Restitution: {obj.rigid_body.restitution:.3f}\n")
            f.write(f"  Damping: {obj.rigid_body.linear_damping:.3f}, {obj.rigid_body.angular_damping:.3f}\n")
            f.write(f"  Collision Shape: {obj.rigid_body.collision_shape}\n")
            f.write(f"  Collision Margin: {obj.rigid_body.collision_margin:.3f}\n")
    
    # Write collision settings
    f.write("Collisions:\n")
    for obj in scene.objects:
        if obj.rigid_body and obj.rigid_body.collision_shape:
            f.write(f"  Object: {obj.name}\n")
            f.write(f"  Shape: {obj.rigid_body.collision_shape}\n")
            f.write(f"  Margin: {obj.rigid_body.collision_margin:.3f}\n")

print(f'Exported physics: {physics_name}')
