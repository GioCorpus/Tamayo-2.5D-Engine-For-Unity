import bpy
import sys
import os

# Get command line arguments
argv = sys.argv
argv = argv[argv.index('--') + 1:] if '--' in argv else []

# Set export settings
export_path = argv[0] if len(argv) > 0 else 'Assets/Compositing/'
compositing_name = argv[1] if len(argv) > 1 else 'DesertCompositing'

# Create export directory
if not os.path.exists(export_path):
    os.makedirs(export_path)

# Get current scene
scene = bpy.context.scene

# Export compositing file
compositing_path = os.path.join(export_path, f"{compositing_name}.compositing")

# Write compositing file
with open(compositing_path, 'w') as f:
    f.write(f"Compositing: {compositing_name}\n")
    f.write(f"Frame Start: {scene.frame_start}\n")
    f.write(f"Frame End: {scene.frame_end}\n")
    f.write(f"FPS: {scene.render.fps}\n")
    
    # Write compositing nodes
    f.write("Compositing Nodes:\n")
    if scene.use_nodes and scene.node_tree:
        for node in scene.node_tree.nodes:
            f.write(f"  Node: {node.name}\n")
            f.write(f"  Type: {node.type}\n")
            f.write(f"  Location: {node.location[0]:.1f}, {node.location[1]:.1f}\n")
            
            # Write node-specific properties
            if node.type == 'BLUR':
                f.write(f"  Size X: {node.size_x}\n")
                f.write(f"  Size Y: {node.size_y}\n")
                f.write(f"  Relative: {node.use_relative}\n")
                if node.use_relative:
                    f.write(f"  Relative Size X: {node.relative_size_x:.3f}\n")
                    f.write(f"  Relative Size Y: {node.relative_size_y:.3f}\n")
            elif node.type == 'COLOR_CORRECTION':
                f.write(f"  Red: {node.red:.3f}\n")
                f.write(f"  Green: {node.green:.3f}\n")
                f.write(f"  Blue: {node.blue:.3f}\n")
                f.write(f"  Saturation: {node.saturation:.3f}\n")
                f.write(f"  Contrast: {node.contrast:.3f}\n")
            elif node.type == 'GLARE':
                f.write(f"  Quality: {node.quality}\n")
                f.write(f"  Type: {node.glare_type}\n")
                f.write(f"  Mix: {node.mix:.3f}\n")
                f.write(f"  Threshold: {node.threshold:.3f}\n")
                f.write(f"  Size: {node.size:.3f}\n")
            elif node.type == 'LENS_DISTORTION':
                f.write(f"  Projector: {node.use_projector}\n")
                f.write(f"  Jitter: {node.use_jitter}\n")
                f.write(f"  Fit: {node.fit}\n")
            elif node.type in ['R_LAYERS', 'COMPOSITE', 'VIEWER']:
                pass  # These nodes don't have additional properties to export

print(f'Exported compositing: {compositing_name}')
