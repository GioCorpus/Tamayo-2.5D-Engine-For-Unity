import bpy
import sys
import os

# Get command line arguments
argv = sys.argv
argv = argv[argv.index('--') + 1:] if '--' in argv else []

# Set export settings
export_path = argv[0] if len(argv) > 0 else 'Assets/Scenes/'
scene_name = argv[1] if len(argv) > 1 else 'DesertScene'

# Create export directory
if not os.path.exists(export_path):
    os.makedirs(export_path)

# Get current scene
scene = bpy.context.scene

# Export scene file
scene_path = os.path.join(export_path, f"{scene_name}.unity")

# Write scene file
with open(scene_path, 'w') as f:
    f.write(f"Scene: {scene_name}\n")
    f.write(f"Frame Start: {scene.frame_start}\n")
    f.write(f"Frame End: {scene.frame_end}\n")
    f.write(f"Frame Current: {scene.frame_current}\n")
    f.write(f"FPS: {scene.render.fps}\n")
    f.write(f"Resolution: {scene.render.resolution_x}x{scene.render.resolution_y}\n")
    f.write(f"Background Color: {scene.world.node_tree.nodes['Background'].inputs[0].default_value[0]:.3f}, {scene.world.node_tree.nodes['Background'].inputs[0].default_value[1]:.3f}, {scene.world.node_tree.nodes['Background'].inputs[0].default_value[2]:.3f}\n")
    
    # Write objects
    f.write("Objects:\n")
    for obj in scene.objects:
        f.write(f"  - {obj.name} ({obj.type})\n")
        f.write(f"    Location: {obj.location[0]:.3f}, {obj.location[1]:.3f}, {obj.location[2]:.3f}\n")
        f.write(f"    Rotation: {obj.rotation_euler[0]:.3f}, {obj.rotation_euler[1]:.3f}, {obj.rotation_euler[2]:.3f}\n")
        f.write(f"    Scale: {obj.scale[0]:.3f}, {obj.scale[1]:.3f}, {obj.scale[2]:.3f}\n")
        
        # Write material if available
        if obj.data and hasattr(obj.data, 'materials'):
            for mat in obj.data.materials:
                if mat:
                    f.write(f"    Material: {mat.name}\n")

print(f'Exported scene: {scene_name}')
