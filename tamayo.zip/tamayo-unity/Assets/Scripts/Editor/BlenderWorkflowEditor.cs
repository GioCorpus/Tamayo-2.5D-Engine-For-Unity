using UnityEngine;
using UnityEditor;
using System.IO;
using System.Diagnostics;

namespace Tamayo2D.Editor
{
    /// <summary>
    /// Editor window for Blender workflow integration
    /// Provides tools for exporting from Blender and importing to Unity
    /// </summary>
    public class BlenderWorkflowEditor : EditorWindow
    {
        [MenuItem("Tamayo 2D/Blender Workflow")]
        public static void ShowWindow()
        {
            GetWindow<BlenderWorkflowEditor>("Blender Workflow");
        }

        private string blenderPath = "C:/Program Files/Blender Foundation/Blender 3.6/blender.exe";
        private string blenderProjectPath = "";
        private string exportPath = "Assets/Models/Blender/";
        private string pythonScriptPath = "Assets/Scripts/Editor/BlenderExport.py";

        private bool applyTransform = true;
        private float exportScale = 1.0f;
        private bool exportTextures = true;
        private bool exportMaterials = true;

        private Vector2 scrollPosition;

        void OnGUI()
        {
            scrollPosition = EditorGUILayout.BeginScrollView(scrollPosition);

            GUILayout.Label("Blender Workflow Integration", EditorStyles.boldLabel);
            EditorGUILayout.Space();

            // Blender Path
            EditorGUILayout.LabelField("Blender Configuration", EditorStyles.boldLabel);
            blenderPath = EditorGUILayout.TextField("Blender Executable", blenderPath);
            if (GUILayout.Button("Browse Blender"))
            {
                string path = EditorUtility.OpenFilePanel("Select Blender Executable", "", "exe");
                if (!string.IsNullOrEmpty(path))
                {
                    blenderPath = path;
                }
            }

            EditorGUILayout.Space();

            // Blender Project
            EditorGUILayout.LabelField("Blender Project", EditorStyles.boldLabel);
            blenderProjectPath = EditorGUILayout.TextField("Blender File", blenderProjectPath);
            if (GUILayout.Button("Browse Blender File"))
            {
                string path = EditorUtility.OpenFilePanel("Select Blender File", "", "blend");
                if (!string.IsNullOrEmpty(path))
                {
                    blenderProjectPath = path;
                }
            }

            EditorGUILayout.Space();

            // Export Settings
            EditorGUILayout.LabelField("Export Settings", EditorStyles.boldLabel);
            exportPath = EditorGUILayout.TextField("Export Path", exportPath);
            applyTransform = EditorGUILayout.Toggle("Apply Transform", applyTransform);
            exportScale = EditorGUILayout.FloatField("Export Scale", exportScale);
            exportTextures = EditorGUILayout.Toggle("Export Textures", exportTextures);
            exportMaterials = EditorGUILayout.Toggle("Export Materials", exportMaterials);

            EditorGUILayout.Space();

            // Export Buttons
            EditorGUILayout.LabelField("Export Actions", EditorStyles.boldLabel);

            if (GUILayout.Button("Export Desert Scene"))
            {
                ExportDesertScene();
            }

            if (GUILayout.Button("Export Solar Panels"))
            {
                ExportSolarPanels();
            }

            if (GUILayout.Button("Export Quantum Particles"))
            {
                ExportQuantumParticles();
            }

            if (GUILayout.Button("Export All"))
            {
                ExportAll();
            }

            EditorGUILayout.Space();

            // Import Actions
            EditorGUILayout.LabelField("Import Actions", EditorStyles.boldLabel);

            if (GUILayout.Button("Import FBX Files"))
            {
                ImportFBXFiles();
            }

            if (GUILayout.Button("Extract Materials"))
            {
                ExtractMaterials();
            }

            if (GUILayout.Button("Bake Textures"))
            {
                BakeTextures();
            }

            EditorGUILayout.Space();

            // Quick Setup
            EditorGUILayout.LabelField("Quick Setup", EditorStyles.boldLabel);

            if (GUILayout.Button("Setup Desert Scene"))
            {
                SetupDesertScene();
            }

            if (GUILayout.Button("Create Quantum Materials"))
            {
                CreateQuantumMaterials();
            }

            EditorGUILayout.EndScrollView();
        }

        /// <summary>
        /// Export desert scene from Blender
        /// </summary>
        void ExportDesertScene()
        {
            if (string.IsNullOrEmpty(blenderProjectPath))
            {
                EditorUtility.DisplayDialog("Error", "Please select a Blender file first.", "OK");
                return;
            }

            string exportFile = Path.Combine(exportPath, "Desert.fbx");
            RunBlenderScript("export_desert", exportFile);

            UnityEngine.Debug.Log($"Exported desert scene to: {exportFile}");
        }

        /// <summary>
        /// Export solar panels from Blender
        /// </summary>
        void ExportSolarPanels()
        {
            if (string.IsNullOrEmpty(blenderProjectPath))
            {
                EditorUtility.DisplayDialog("Error", "Please select a Blender file first.", "OK");
                return;
            }

            string exportFile = Path.Combine(exportPath, "SolarPanel.fbx");
            RunBlenderScript("export_solar_panels", exportFile);

            UnityEngine.Debug.Log($"Exported solar panels to: {exportFile}");
        }

        /// <summary>
        /// Export quantum particles from Blender
        /// </summary>
        void ExportQuantumParticles()
        {
            if (string.IsNullOrEmpty(blenderProjectPath))
            {
                EditorUtility.DisplayDialog("Error", "Please select a Blender file first.", "OK");
                return;
            }

            string exportFile = Path.Combine(exportPath, "QuantumParticles.fbx");
            RunBlenderScript("export_quantum_particles", exportFile);

            UnityEngine.Debug.Log($"Exported quantum particles to: {exportFile}");
        }

        /// <summary>
        /// Export all assets from Blender
        /// </summary>
        void ExportAll()
        {
            ExportDesertScene();
            ExportSolarPanels();
            ExportQuantumParticles();

            UnityEngine.Debug.Log("Exported all assets from Blender");
        }

        /// <summary>
        /// Run Blender Python script
        /// </summary>
        void RunBlenderScript(string scriptName, string exportFile)
        {
            if (!File.Exists(blenderPath))
            {
                EditorUtility.DisplayDialog("Error", "Blender executable not found.", "OK");
                return;
            }

            if (!File.Exists(blenderProjectPath))
            {
                EditorUtility.DisplayDialog("Error", "Blender file not found.", "OK");
                return;
            }

            // Create Python script
            string scriptContent = GenerateBlenderScript(scriptName, exportFile);
            string tempScriptPath = Path.Combine(Application.temporaryCachePath, $"{scriptName}.py");
            File.WriteAllText(tempScriptPath, scriptContent);

            // Run Blender
            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.FileName = blenderPath;
            startInfo.Arguments = $"--background --python \"{tempScriptPath}\" \"{blenderProjectPath}\"";
            startInfo.UseShellExecute = false;
            startInfo.RedirectStandardOutput = true;
            startInfo.RedirectStandardError = true;
            startInfo.CreateNoWindow = true;

            try
            {
                Process process = Process.Start(startInfo);
                string output = process.StandardOutput.ReadToEnd();
                string error = process.StandardError.ReadToEnd();
                process.WaitForExit();

                if (process.ExitCode == 0)
                {
                    UnityEngine.Debug.Log($"Blender export successful: {output}");
                }
                else
                {
                    UnityEngine.Debug.LogError($"Blender export failed: {error}");
                }
            }
            catch (System.Exception e)
            {
                UnityEngine.Debug.LogError($"Failed to run Blender: {e.Message}");
            }

            // Clean up
            if (File.Exists(tempScriptPath))
            {
                File.Delete(tempScriptPath);
            }
        }

        /// <summary>
        /// Generate Blender Python script
        /// </summary>
        string GenerateBlenderScript(string scriptName, string exportFile)
        {
            string script = $@"
import bpy
import sys
import os

# Get command line arguments
argv = sys.argv
argv = argv[argv.index('--') + 1:] if '--' in argv else []

# Set export settings
export_path = '{exportFile.Replace('\\', '/')}'
apply_transform = {applyTransform.ToString().ToLower()}
export_scale = {exportScale}
export_textures = {exportTextures.ToString().ToLower()}
export_materials = {exportMaterials.ToString().ToLower()}

# Select objects based on script name
if '{scriptName}' == 'export_desert':
    # Select desert objects
    for obj in bpy.data.objects:
        if 'desert' in obj.name.lower() or 'terrain' in obj.name.lower() or 'sand' in obj.name.lower():
            obj.select_set(True)
elif '{scriptName}' == 'export_solar_panels':
    # Select solar panel objects
    for obj in bpy.data.objects:
        if 'solar' in obj.name.lower() or 'panel' in obj.name.lower():
            obj.select_set(True)
elif '{scriptName}' == 'export_quantum_particles':
    # Select quantum particle objects
    for obj in bpy.data.objects:
        if 'quantum' in obj.name.lower() or 'particle' in obj.name.lower() or 'energy' in obj.name.lower():
            obj.select_set(True)

# Export FBX
bpy.ops.export_scene.fbx(
    filepath=export_path,
    use_selection=True,
    apply_scale_options='FBX_SCALE_ALL' if apply_transform else 'FBX_SCALE_NONE',
    axis_forward='-Z',
    axis_up='Y',
    use_mesh_modifiers=True,
    use_mesh_modifiers_render=True,
    mesh_smooth_type='FACE',
    use_subsurf=False,
    use_default_take=True,
    use_anim=False,
    use_anim_action_all=False,
    use_anim_optimize=False,
    use_anim_optimize_precision=6.0,
    use_custom_props=False,
    path_mode='AUTO' if export_textures else 'COPY',
    embed_textures=export_textures,
    batch_mode='OFF',
    use_batch_own_dir=True,
    use_metadata=True,
    global_scale=export_scale
)

print(f'Exported {{scriptName}} to {{export_path}}')
";
            return script;
        }

        /// <summary>
        /// Import FBX files
        /// </summary>
        void ImportFBXFiles()
        {
            string[] fbxFiles = Directory.GetFiles(exportPath, "*.fbx");
            foreach (string fbxFile in fbxFiles)
            {
                string fileName = Path.GetFileNameWithoutExtension(fbxFile);
                string modelPath = Path.Combine("Assets/Models", fileName);

                // Create directory
                if (!Directory.Exists(modelPath))
                {
                    Directory.CreateDirectory(modelPath);
                }

                // Copy file
                string destPath = Path.Combine(modelPath, Path.GetFileName(fbxFile));
                File.Copy(fbxFile, destPath, true);

                UnityEngine.Debug.Log($"Imported: {fileName}");
            }

            AssetDatabase.Refresh();
            UnityEngine.Debug.Log("Imported all FBX files");
        }

        /// <summary>
        /// Extract materials from imported models
        /// </summary>
        void ExtractMaterials()
        {
            string[] modelDirs = Directory.GetDirectories("Assets/Models");
            foreach (string modelDir in modelDirs)
            {
                string modelName = Path.GetFileName(modelDir);
                string fbxPath = Path.Combine(modelDir, $"{modelName}.fbx");

                if (File.Exists(fbxPath))
                {
                    // Load model
                    GameObject model = AssetDatabase.LoadAssetAtPath<GameObject>(fbxPath);
                    if (model != null)
                    {
                        // Get renderers
                        Renderer[] renderers = model.GetComponentsInChildren<Renderer>();
                        foreach (Renderer renderer in renderers)
                        {
                            // Create material
                            Material material = new Material(Shader.Find("Universal Render Pipeline/Lit"));
                            material.name = $"{renderer.gameObject.name}_Material";

                            // Save material
                            string materialPath = Path.Combine("Assets/Materials", $"{material.name}.mat");
                            AssetDatabase.CreateAsset(material, materialPath);

                            // Assign material
                            renderer.sharedMaterial = material;

                            UnityEngine.Debug.Log($"Created material: {material.name}");
                        }
                    }
                }
            }

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            UnityEngine.Debug.Log("Extracted all materials");
        }

        /// <summary>
        /// Bake textures from models
        /// </summary>
        void BakeTextures()
        {
            // This would typically use Unity's baking system
            // For now, we'll just log the workflow
            UnityEngine.Debug.Log("To bake textures:");
            UnityEngine.Debug.Log("1. Select model in Project window");
            UnityEngine.Debug.Log("2. Go to Model tab in Inspector");
            UnityEngine.Debug.Log("3. Enable 'Generate Lightmap UVs'");
            UnityEngine.Debug.Log("4. Click 'Apply'");
            UnityEngine.Debug.Log("5. Use Window > Rendering > Lighting to bake");
        }

        /// <summary>
        /// Setup desert scene
        /// </summary>
        void SetupDesertScene()
        {
            // Create scene manager
            GameObject sceneManager = new GameObject("DesertSceneManager");
            DesertSceneManager manager = sceneManager.AddComponent<DesertSceneManager>();

            // Create layers
            GameObject backgroundLayer = new GameObject("BackgroundLayer");
            backgroundLayer.transform.SetParent(sceneManager.transform);
            backgroundLayer.AddComponent<ParallaxController>();

            GameObject middleLayer = new GameObject("MiddleLayer");
            middleLayer.transform.SetParent(sceneManager.transform);
            middleLayer.AddComponent<ParallaxController>();

            GameObject foregroundLayer = new GameObject("ForegroundLayer");
            foregroundLayer.transform.SetParent(sceneManager.transform);
            foregroundLayer.AddComponent<ParallaxController>();

            // Assign to manager
            manager.backgroundLayer = backgroundLayer;
            manager.middleLayer = middleLayer;
            manager.foregroundLayer = foregroundLayer;

            // Create camera
            GameObject cameraObj = new GameObject("Main Camera");
            Camera camera = cameraObj.AddComponent<Camera>();
            camera.orthographic = true;
            camera.orthographicSize = 5f;
            camera.backgroundColor = new Color(0.8f, 0.6f, 0.4f, 1.0f);

            CameraController cameraController = cameraObj.AddComponent<CameraController>();
            cameraController.followTarget = sceneManager.transform;

            // Assign camera to manager
            manager.mainCamera = camera;

            UnityEngine.Debug.Log("Setup desert scene complete");
        }

        /// <summary>
        /// Create quantum materials
        /// </summary>
        void CreateQuantumMaterials()
        {
            // Create quantum glow material
            Material quantumMaterial = new Material(Shader.Find("Tamayo2D/QuantumGlow"));
            quantumMaterial.name = "QuantumGlow";
            quantumMaterial.SetColor("_GlowColor", new Color(0.2f, 0.5f, 1.0f, 1.0f));
            quantumMaterial.SetFloat("_GlowIntensity", 2.0f);
            quantumMaterial.SetFloat("_WaveSpeed", 2.0f);
            quantumMaterial.SetFloat("_WaveAmplitude", 1.0f);
            quantumMaterial.SetFloat("_WaveFrequency", 1.0f);

            string materialPath = Path.Combine("Assets/Materials", "QuantumGlow.mat");
            AssetDatabase.CreateAsset(quantumMaterial, materialPath);

            // Create solar panel material
            Material solarMaterial = new Material(Shader.Find("Universal Render Pipeline/Lit"));
            solarMaterial.name = "SolarPanel";
            solarMaterial.color = new Color(0.2f, 0.2f, 0.3f, 1.0f);
            solarMaterial.SetFloat("_Metallic", 0.8f);
            solarMaterial.SetFloat("_Smoothness", 0.9f);

            string solarPath = Path.Combine("Assets/Materials", "SolarPanel.mat");
            AssetDatabase.CreateAsset(solarMaterial, solarPath);

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();

            UnityEngine.Debug.Log("Created quantum materials");
        }
    }
}
