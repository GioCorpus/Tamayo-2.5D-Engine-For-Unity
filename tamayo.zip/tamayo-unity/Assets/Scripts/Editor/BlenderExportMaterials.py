import bpy
import sys
import os

# Get command line arguments
argv = sys.argv
argv = argv[argv.index('--') + 1:] if '--' in argv else []

# Set export settings
export_path = argv[0] if len(argv) > 0 else 'Assets/Materials/'

# Create export directory
if not os.path.exists(export_path):
    os.makedirs(export_path)

# Export materials
for material in bpy.data.materials:
    # Create material file
    material_name = material.name
    material_path = os.path.join(export_path, f"{material_name}.mat")
    
    # Write material properties
    with open(material_path, 'w') as f:
        f.write(f"Material: {material_name}\n")
        f.write(f"Diffuse Color: {material.diffuse_color[0]:.3f}, {material.diffuse_color[1]:.3f}, {material.diffuse_color[2]:.3f}\n")
        f.write(f"Specular Color: {material.specular_color[0]:.3f}, {material.specular_color[1]:.3f}, {material.specular_color[2]:.3f}\n")
        f.write(f"Roughness: {material.roughness:.3f}\n")
        f.write(f"Metallic: {material.metallic:.3f}\n")
        f.write(f"Alpha: {material.diffuse_color[3]:.3f}\n")
        
        # Write node information if available
        if material.use_nodes:
            f.write("Nodes:\n")
            for node in material.node_tree.nodes:
                f.write(f"  - {node.name} ({node.type})\n")
    
    print(f'Exported material: {material_name}')

print(f'Exported all materials to {export_path}')
