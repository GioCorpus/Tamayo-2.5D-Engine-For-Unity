using UnityEngine;

namespace Tamayo2D
{
    /// <summary>
    /// Controls camera behavior for 2.5D scene
    /// Handles orthographic camera, zoom, pan, and follow
    /// </summary>
    public class CameraController : MonoBehaviour
    {
        [Header("Camera Settings")]
        [Tooltip("Target to follow")]
        public Transform followTarget;

        [Tooltip("Enable camera follow")]
        public bool enableFollow = true;

        [Tooltip("Follow speed")]
        public float followSpeed = 5f;

        [Tooltip("Follow offset")]
        public Vector3 followOffset = new Vector3(0, 2, -10);

        [Header("Zoom Settings")]
        [Tooltip("Enable zoom")]
        public bool enableZoom = true;

        [Tooltip("Zoom speed")]
        public float zoomSpeed = 5f;

        [Tooltip("Minimum zoom size")]
        public float minZoom = 2f;

        [Tooltip("Maximum zoom size")]
        public float maxZoom = 10f;

        [Tooltip("Current zoom size")]
        public float currentZoom = 5f;

        [Header("Pan Settings")]
        [Tooltip("Enable panning")]
        public bool enablePan = true;

        [Tooltip("Pan speed")]
        public float panSpeed = 10f;

        [Tooltip("Pan boundaries")]
        public Rect panBounds = new Rect(-50, -50, 100, 100);

        [Header("Visual Effects")]
        [Tooltip("Enable camera shake")]
        public bool enableShake = true;

        [Tooltip("Shake intensity")]
        public float shakeIntensity = 0.1f;

        [Tooltip("Shake duration")]
        public float shakeDuration = 0.5f;

        private Camera cam;
        private Vector3 targetPosition;
        private float shakeTimer = 0f;
        private Vector3 originalPosition;

        void Start()
        {
            cam = GetComponent<Camera>();
            if (cam == null)
            {
                cam = gameObject.AddComponent<Camera>();
            }

            // Set orthographic for 2.5D
            cam.orthographic = true;
            cam.orthographicSize = currentZoom;

            originalPosition = transform.position;
            targetPosition = transform.position;
        }

        void Update()
        {
            if (enableFollow && followTarget != null)
            {
                FollowTarget();
            }

            if (enableZoom)
            {
                HandleZoom();
            }

            if (enablePan)
            {
                HandlePan();
            }

            if (enableShake && shakeTimer > 0)
            {
                ApplyShake();
            }

            UpdateCamera();
        }

        /// <summary>
        /// Follow the target
        /// </summary>
        void FollowTarget()
        {
            Vector3 desiredPosition = followTarget.position + followOffset;
            targetPosition = Vector3.Lerp(transform.position, desiredPosition, Time.deltaTime * followSpeed);

            // Clamp to pan bounds
            targetPosition.x = Mathf.Clamp(targetPosition.x, panBounds.xMin, panBounds.xMax);
            targetPosition.y = Mathf.Clamp(targetPosition.y, panBounds.yMin, panBounds.yMax);
        }

        /// <summary>
        /// Handle zoom input
        /// </summary>
        void HandleZoom()
        {
            float scrollInput = Input.GetAxis("Mouse ScrollWheel");
            if (Mathf.Abs(scrollInput) > 0.01f)
            {
                currentZoom -= scrollInput * zoomSpeed;
                currentZoom = Mathf.Clamp(currentZoom, minZoom, maxZoom);
            }
        }

        /// <summary>
        /// Handle pan input
        /// </summary>
        void HandlePan()
        {
            float horizontalInput = Input.GetAxis("Horizontal");
            float verticalInput = Input.GetAxis("Vertical");

            if (Mathf.Abs(horizontalInput) > 0.01f || Mathf.Abs(verticalInput) > 0.01f)
            {
                Vector3 panMovement = new Vector3(horizontalInput, verticalInput, 0) * panSpeed * Time.deltaTime;
                targetPosition += panMovement;

                // Clamp to pan bounds
                targetPosition.x = Mathf.Clamp(targetPosition.x, panBounds.xMin, panBounds.xMax);
                targetPosition.y = Mathf.Clamp(targetPosition.y, panBounds.yMin, panBounds.yMax);
            }
        }

        /// <summary>
        /// Apply camera shake
        /// </summary>
        void ApplyShake()
        {
            shakeTimer -= Time.deltaTime;
            Vector3 shakeOffset = Random.insideUnitSphere * shakeIntensity;
            shakeOffset.z = 0; // Keep 2D
            transform.position += shakeOffset;
        }

        /// <summary>
        /// Update camera position and zoom
        /// </summary>
        void UpdateCamera()
        {
            // Smoothly move to target position
            transform.position = Vector3.Lerp(transform.position, targetPosition, Time.deltaTime * followSpeed);

            // Update zoom
            cam.orthographicSize = Mathf.Lerp(cam.orthographicSize, currentZoom, Time.deltaTime * zoomSpeed);
        }

        /// <summary>
        /// Trigger camera shake
        /// </summary>
        public void TriggerShake(float intensity = -1f, float duration = -1f)
        {
            if (intensity > 0)
            {
                shakeIntensity = intensity;
            }
            if (duration > 0)
            {
                shakeDuration = duration;
            }
            shakeTimer = shakeDuration;
        }

        /// <summary>
        /// Set zoom level
        /// </summary>
        public void SetZoom(float zoom)
        {
            currentZoom = Mathf.Clamp(zoom, minZoom, maxZoom);
        }

        /// <summary>
        /// Set follow target
        /// </summary>
        public void SetFollowTarget(Transform target)
        {
            followTarget = target;
        }

        /// <summary>
        /// Set pan bounds
        /// </summary>
        public void SetPanBounds(Rect bounds)
        {
            panBounds = bounds;
        }

        /// <summary>
        /// Reset camera to original position
        /// </summary>
        public void ResetCamera()
        {
            targetPosition = originalPosition;
            currentZoom = 5f;
        }

        /// <summary>
        /// Toggle camera follow
        /// </summary>
        public void ToggleFollow()
        {
            enableFollow = !enableFollow;
        }

        /// <summary>
        /// Toggle zoom
        /// </summary>
        public void ToggleZoom()
        {
            enableZoom = !enableZoom;
        }

        /// <summary>
        /// Toggle panning
        /// </summary>
        public void TogglePan()
        {
            enablePan = !enablePan;
        }

        /// <summary>
        /// Get current zoom level
        /// </summary>
        public float GetZoomLevel()
        {
            return currentZoom;
        }

        /// <summary>
        /// Get camera bounds
        /// </summary>
        public Rect GetCameraBounds()
        {
            float height = 2f * cam.orthographicSize;
            float width = height * cam.aspect;
            return new Rect(
                transform.position.x - width / 2,
                transform.position.y - height / 2,
                width,
                height
            );
        }
    }
}
