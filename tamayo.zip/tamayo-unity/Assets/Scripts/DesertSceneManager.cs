using UnityEngine;
using System.Collections.Generic;

namespace Tamayo2D
{
    /// <summary>
    /// Manages the desert scene with solar panels and quantum effects
    /// Controls scene setup, layer management, and visual effects
    /// </summary>
    public class DesertSceneManager : MonoBehaviour
    {
        [Header("Scene References")]
        [Tooltip("Main camera for the scene")]
        public Camera mainCamera;

        [Tooltip("Canvas for UI elements")]
        public Canvas uiCanvas;

        [Header("Layer Settings")]
        [Tooltip("Background layer (desert)")]
        public GameObject backgroundLayer;

        [Tooltip("Middle layer (solar panels)")]
        public GameObject middleLayer;

        [Tooltip("Foreground layer (quantum effects)")]
        public GameObject foregroundLayer;

        [Header("Visual Effects")]
        [Tooltip("Bloom post-processing profile")]
        public UnityEngine.Rendering.Volume postProcessVolume;

        [Tooltip("Ambient light color")]
        public Color ambientColor = new Color(1.0f, 0.8f, 0.6f, 1.0f);

        [Tooltip("Sun light intensity")]
        public float sunIntensity = 1.2f;

        [Header("Quantum Effects")]
        [Tooltip("Quantum wave controller")]
        public QuantumWaveController quantumWave;

        [Tooltip("Particle system for sand/dust")]
        public ParticleSystem sandParticles;

        [Tooltip("Particle system for energy waves")]
        public ParticleSystem energyWaves;

        [Header("Animation Settings")]
        [Tooltip("Enable automatic scene animation")]
        public bool autoAnimate = true;

        [Tooltip("Speed of scene animation")]
        public float animationSpeed = 1.0f;

        private List<ParallaxController> parallaxLayers = new List<ParallaxController>();
        private float timeOffset = 0f;

        void Start()
        {
            InitializeScene();
            SetupParallaxLayers();
            SetupLighting();
        }

        void Update()
        {
            if (autoAnimate)
            {
                timeOffset += Time.deltaTime * animationSpeed;
                UpdateSceneAnimation();
            }
        }

        /// <summary>
        /// Initialize the desert scene
        /// </summary>
        void InitializeScene()
        {
            // Set camera to orthographic for 2.5D
            if (mainCamera != null)
            {
                mainCamera.orthographic = true;
                mainCamera.orthographicSize = 5f;
                mainCamera.backgroundColor = new Color(0.8f, 0.6f, 0.4f, 1.0f);
            }

            // Setup layers
            if (backgroundLayer != null)
            {
                backgroundLayer.transform.position = new Vector3(0, 0, 10);
            }

            if (middleLayer != null)
            {
                middleLayer.transform.position = new Vector3(0, 0, 5);
            }

            if (foregroundLayer != null)
            {
                foregroundLayer.transform.position = new Vector3(0, 0, 0);
            }
        }

        /// <summary>
        /// Setup parallax layers
        /// </summary>
        void SetupParallaxLayers()
        {
            parallaxLayers.Clear();

            // Add parallax to each layer
            if (backgroundLayer != null)
            {
                var parallax = backgroundLayer.GetComponent<ParallaxController>();
                if (parallax == null)
                {
                    parallax = backgroundLayer.AddComponent<ParallaxController>();
                }
                parallax.parallaxFactor = 0.2f;
                parallaxLayers.Add(parallax);
            }

            if (middleLayer != null)
            {
                var parallax = middleLayer.GetComponent<ParallaxController>();
                if (parallax == null)
                {
                    parallax = middleLayer.AddComponent<ParallaxController>();
                }
                parallax.parallaxFactor = 0.5f;
                parallaxLayers.Add(parallax);
            }

            if (foregroundLayer != null)
            {
                var parallax = foregroundLayer.GetComponent<ParallaxController>();
                if (parallax == null)
                {
                    parallax = foregroundLayer.AddComponent<ParallaxController>();
                }
                parallax.parallaxFactor = 0.8f;
                parallaxLayers.Add(parallax);
            }
        }

        /// <summary>
        /// Setup lighting for the desert scene
        /// </summary>
        void SetupLighting()
        {
            // Set ambient color
            RenderSettings.ambientLight = ambientColor;

            // Find or create directional light
            Light[] lights = FindObjectsOfType<Light>();
            Light sunLight = null;

            foreach (Light light in lights)
            {
                if (light.type == LightType.Directional)
                {
                    sunLight = light;
                    break;
                }
            }

            if (sunLight == null)
            {
                GameObject lightObj = new GameObject("Sun Light");
                sunLight = lightObj.AddComponent<Light>();
                sunLight.type = LightType.Directional;
            }

            sunLight.intensity = sunIntensity;
            sunLight.color = new Color(1.0f, 0.9f, 0.7f, 1.0f);
            sunLight.transform.rotation = Quaternion.Euler(50, -30, 0);
        }

        /// <summary>
        /// Update scene animation
        /// </summary>
        void UpdateSceneAnimation()
        {
            // Animate sand particles
            if (sandParticles != null)
            {
                var emission = sandParticles.emission;
                emission.rateOverTime = 10 + Mathf.Sin(timeOffset) * 5;
            }

            // Animate energy waves
            if (energyWaves != null)
            {
                var emission = energyWaves.emission;
                emission.rateOverTime = 5 + Mathf.Sin(timeOffset * 2) * 3;
            }

            // Trigger quantum waves periodically
            if (quantumWave != null && Mathf.Sin(timeOffset * 0.5f) > 0.9f)
            {
                quantumWave.TriggerWaveBurst();
            }
        }

        /// <summary>
        /// Set parallax factor for a specific layer
        /// </summary>
        public void SetLayerParallax(int layerIndex, float factor)
        {
            if (layerIndex >= 0 && layerIndex < parallaxLayers.Count)
            {
                parallaxLayers[layerIndex].SetParallaxFactor(factor);
            }
        }

        /// <summary>
        /// Toggle auto animation
        /// </summary>
        public void ToggleAutoAnimation()
        {
            autoAnimate = !autoAnimate;
        }

        /// <summary>
        /// Set animation speed
        /// </summary>
        public void SetAnimationSpeed(float speed)
        {
            animationSpeed = Mathf.Max(0, speed);
        }

        /// <summary>
        /// Trigger a quantum wave burst
        /// </summary>
        public void TriggerQuantumBurst()
        {
            if (quantumWave != null)
            {
                quantumWave.TriggerWaveBurst();
            }
        }

        /// <summary>
        /// Set ambient color
        /// </summary>
        public void SetAmbientColor(Color color)
        {
            ambientColor = color;
            RenderSettings.ambientLight = ambientColor;
        }

        /// <summary>
        /// Set sun intensity
        /// </summary>
        public void SetSunIntensity(float intensity)
        {
            sunIntensity = intensity;
            Light[] lights = FindObjectsOfType<Light>();
            foreach (Light light in lights)
            {
                if (light.type == LightType.Directional)
                {
                    light.intensity = sunIntensity;
                    break;
                }
            }
        }
    }
}
