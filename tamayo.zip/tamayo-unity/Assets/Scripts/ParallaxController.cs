using UnityEngine;

namespace Tamayo2D
{
    /// <summary>
    /// Controls parallax scrolling for 2.5D depth effect
    /// Attach to each layer that needs parallax movement
    /// </summary>
    public class ParallaxController : MonoBehaviour
    {
        [Header("Parallax Settings")]
        [Tooltip("How much this layer moves relative to camera (0 = no movement, 1 = full movement)")]
        [Range(0f, 1f)]
        public float parallaxFactor = 0.5f;

        [Tooltip("Enable infinite scrolling")]
        public bool infiniteScrolling = true;

        [Tooltip("Width of the sprite for infinite scrolling")]
        public float spriteWidth = 0f;

        private Transform cameraTransform;
        private Vector3 previousCameraPosition;
        private float startPosition;

        void Start()
        {
            cameraTransform = Camera.main.transform;
            previousCameraPosition = cameraTransform.position;
            startPosition = transform.position.x;

            if (spriteWidth == 0f && GetComponent<SpriteRenderer>() != null)
            {
                spriteWidth = GetComponent<SpriteRenderer>().bounds.size.x;
            }
        }

        void LateUpdate()
        {
            float deltaX = cameraTransform.position.x - previousCameraPosition.x;
            float movement = deltaX * parallaxFactor;

            transform.position += new Vector3(movement, 0, 0);

            if (infiniteScrolling && spriteWidth > 0)
            {
                float temp = cameraTransform.position.x * (1 - parallaxFactor);
                if (Mathf.Abs(transform.position.x - cameraTransform.position.x) >= spriteWidth)
                {
                    float offset = (transform.position.x - cameraTransform.position.x) % spriteWidth;
                    transform.position = new Vector3(cameraTransform.position.x + offset, transform.position.y, transform.position.z);
                }
            }

            previousCameraPosition = cameraTransform.position;
        }

        /// <summary>
        /// Set parallax factor at runtime
        /// </summary>
        public void SetParallaxFactor(float factor)
        {
            parallaxFactor = Mathf.Clamp01(factor);
        }
    }
}
