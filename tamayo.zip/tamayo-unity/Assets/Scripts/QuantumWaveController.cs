using UnityEngine;

namespace Tamayo2D
{
    /// <summary>
    /// Controls quantum wave particle effects
    /// Creates glowing energy waves for the 2.5D scene
    /// </summary>
    public class QuantumWaveController : MonoBehaviour
    {
        [Header("Wave Settings")]
        [Tooltip("Speed of wave propagation")]
        public float waveSpeed = 2.0f;

        [Tooltip("Amplitude of the wave")]
        public float waveAmplitude = 1.0f;

        [Tooltip("Frequency of the wave")]
        public float waveFrequency = 1.0f;

        [Tooltip("Color of the quantum glow")]
        public Color glowColor = new Color(0.2f, 0.5f, 1.0f, 1.0f);

        [Tooltip("Intensity of the glow effect")]
        [Range(0f, 5f)]
        public float glowIntensity = 2.0f;

        [Header("Particle Settings")]
        [Tooltip("Particle system for quantum particles")]
        public ParticleSystem quantumParticles;

        [Tooltip("Number of particles to emit")]
        public int particleCount = 50;

        [Tooltip("Particle lifetime")]
        public float particleLifetime = 2.0f;

        [Header("Animation")]
        [Tooltip("Enable automatic wave animation")]
        public bool autoAnimate = true;

        [Tooltip("Wave animation speed")]
        public float animationSpeed = 1.0f;

        private Material waveMaterial;
        private float timeOffset = 0f;
        private Renderer renderer;

        void Start()
        {
            renderer = GetComponent<Renderer>();
            if (renderer != null)
            {
                waveMaterial = renderer.material;
            }

            if (quantumParticles != null)
            {
                var main = quantumParticles.main;
                main.startLifetime = particleLifetime;
                main.startColor = glowColor;
            }
        }

        void Update()
        {
            if (autoAnimate)
            {
                timeOffset += Time.deltaTime * animationSpeed;
            }

            UpdateWaveMaterial();
            UpdateParticles();
        }

        /// <summary>
        /// Update the wave shader material
        /// </summary>
        void UpdateWaveMaterial()
        {
            if (waveMaterial != null)
            {
                waveMaterial.SetFloat("_WaveSpeed", waveSpeed);
                waveMaterial.SetFloat("_WaveAmplitude", waveAmplitude);
                waveMaterial.SetFloat("_WaveFrequency", waveFrequency);
                waveMaterial.SetColor("_GlowColor", glowColor);
                waveMaterial.SetFloat("_GlowIntensity", glowIntensity);
                waveMaterial.SetFloat("_TimeOffset", timeOffset);
            }
        }

        /// <summary>
        /// Update particle system
        /// </summary>
        void UpdateParticles()
        {
            if (quantumParticles != null && autoAnimate)
            {
                // Emit particles based on wave
                float waveValue = Mathf.Sin(timeOffset * waveFrequency) * waveAmplitude;
                if (waveValue > 0.5f)
                {
                    quantumParticles.Emit(particleCount / 10);
                }
            }
        }

        /// <summary>
        /// Trigger a quantum wave burst
        /// </summary>
        public void TriggerWaveBurst()
        {
            if (quantumParticles != null)
            {
                quantumParticles.Emit(particleCount);
            }

            // Animate glow intensity
            StartCoroutine(GlowBurst());
        }

        System.Collections.IEnumerator GlowBurst()
        {
            float originalIntensity = glowIntensity;
            float elapsed = 0f;
            float duration = 0.5f;

            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                float t = elapsed / duration;
                glowIntensity = Mathf.Lerp(originalIntensity * 3f, originalIntensity, t);
                yield return null;
            }

            glowIntensity = originalIntensity;
        }

        /// <summary>
        /// Set wave parameters at runtime
        /// </summary>
        public void SetWaveParameters(float speed, float amplitude, float frequency)
        {
            waveSpeed = speed;
            waveAmplitude = amplitude;
            waveFrequency = frequency;
        }

        /// <summary>
        /// Set glow color at runtime
        /// </summary>
        public void SetGlowColor(Color color, float intensity)
        {
            glowColor = color;
            glowIntensity = intensity;
        }

        void OnDestroy()
        {
            if (waveMaterial != null)
            {
                Destroy(waveMaterial);
            }
        }
    }
}
