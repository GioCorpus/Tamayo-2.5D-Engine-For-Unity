using UnityEngine;

namespace Tamayo2D
{
    /// <summary>
    /// Controls solar panel behavior and energy generation
    /// Handles panel rotation, energy waves, and visual feedback
    /// </summary>
    public class SolarPanelController : MonoBehaviour
    {
        [Header("Panel Settings")]
        [Tooltip("Rotation speed of the solar panel")]
        public float rotationSpeed = 30f;

        [Tooltip("Maximum rotation angle")]
        public float maxRotationAngle = 45f;

        [Tooltip("Enable automatic sun tracking")]
        public bool autoTrackSun = true;

        [Header("Energy Settings")]
        [Tooltip("Energy generation rate")]
        public float energyGenerationRate = 10f;

        [Tooltip("Current energy level")]
        public float currentEnergy = 0f;

        [Tooltip("Maximum energy capacity")]
        public float maxEnergy = 100f;

        [Header("Visual Effects")]
        [Tooltip("Energy wave particle system")]
        public ParticleSystem energyWaves;

        [Tooltip("Glow material for energy visualization")]
        public Material glowMaterial;

        [Tooltip("Energy bar UI element")]
        public RectTransform energyBar;

        [Header("Animation")]
        [Tooltip("Enable energy pulse animation")]
        public bool enablePulse = true;

        [Tooltip("Pulse speed")]
        public float pulseSpeed = 2f;

        private float targetRotation = 0f;
        private float currentRotation = 0f;
        private Material panelMaterial;
        private Renderer panelRenderer;
        private float pulseOffset = 0f;

        void Start()
        {
            panelRenderer = GetComponent<Renderer>();
            if (panelRenderer != null)
            {
                panelMaterial = panelRenderer.material;
            }

            if (energyWaves != null)
            {
                var main = energyWaves.main;
                main.startColor = new Color(0.2f, 0.8f, 1.0f, 0.5f);
            }
        }

        void Update()
        {
            if (autoTrackSun)
            {
                TrackSun();
            }

            RotatePanel();
            GenerateEnergy();
            UpdateVisuals();

            if (enablePulse)
            {
                pulseOffset += Time.deltaTime * pulseSpeed;
            }
        }

        /// <summary>
        /// Track the sun position for optimal energy generation
        /// </summary>
        void TrackSun()
        {
            // Find directional light (sun)
            Light[] lights = FindObjectsOfType<Light>();
            foreach (Light light in lights)
            {
                if (light.type == LightType.Directional)
                {
                    // Calculate angle to sun
                    Vector3 sunDirection = -light.transform.forward;
                    float angle = Mathf.Atan2(sunDirection.x, sunDirection.z) * Mathf.Rad2Deg;
                    targetRotation = Mathf.Clamp(angle, -maxRotationAngle, maxRotationAngle);
                    break;
                }
            }
        }

        /// <summary>
        /// Rotate the solar panel towards target rotation
        /// </summary>
        void RotatePanel()
        {
            currentRotation = Mathf.Lerp(currentRotation, targetRotation, Time.deltaTime * rotationSpeed);
            transform.rotation = Quaternion.Euler(0, currentRotation, 0);
        }

        /// <summary>
        /// Generate energy based on sun alignment
        /// </summary>
        void GenerateEnergy()
        {
            // Calculate energy generation based on rotation alignment
            float alignment = 1f - Mathf.Abs(currentRotation) / maxRotationAngle;
            float energyToAdd = energyGenerationRate * alignment * Time.deltaTime;

            currentEnergy = Mathf.Min(currentEnergy + energyToAdd, maxEnergy);

            // Emit energy waves when generating
            if (energyWaves != null && alignment > 0.8f)
            {
                var emission = energyWaves.emission;
                emission.rateOverTime = 5 + alignment * 10;
            }
        }

        /// <summary>
        /// Update visual effects
        /// </summary>
        void UpdateVisuals()
        {
            // Update glow material
            if (glowMaterial != null)
            {
                float glowIntensity = currentEnergy / maxEnergy;
                glowMaterial.SetFloat("_GlowIntensity", glowIntensity * 2f);

                // Pulse effect
                if (enablePulse)
                {
                    float pulse = Mathf.Sin(pulseOffset) * 0.5f + 0.5f;
                    glowMaterial.SetFloat("_PulseIntensity", pulse);
                }
            }

            // Update energy bar UI
            if (energyBar != null)
            {
                float fillAmount = currentEnergy / maxEnergy;
                energyBar.localScale = new Vector3(fillAmount, 1, 1);
            }

            // Update panel material color based on energy
            if (panelMaterial != null)
            {
                float energyRatio = currentEnergy / maxEnergy;
                Color panelColor = Color.Lerp(
                    new Color(0.3f, 0.3f, 0.3f, 1f),
                    new Color(0.2f, 0.8f, 1.0f, 1f),
                    energyRatio
                );
                panelMaterial.color = panelColor;
            }
        }

        /// <summary>
        /// Consume energy from the panel
        /// </summary>
        public float ConsumeEnergy(float amount)
        {
            float consumed = Mathf.Min(amount, currentEnergy);
            currentEnergy -= consumed;
            return consumed;
        }

        /// <summary>
        /// Add energy to the panel
        /// </summary>
        public void AddEnergy(float amount)
        {
            currentEnergy = Mathf.Min(currentEnergy + amount, maxEnergy);
        }

        /// <summary>
        /// Get current energy level
        /// </summary>
        public float GetEnergyLevel()
        {
            return currentEnergy;
        }

        /// <summary>
        /// Get energy percentage
        /// </summary>
        public float GetEnergyPercentage()
        {
            return currentEnergy / maxEnergy;
        }

        /// <summary>
        /// Set target rotation manually
        /// </summary>
        public void SetTargetRotation(float angle)
        {
            targetRotation = Mathf.Clamp(angle, -maxRotationAngle, maxRotationAngle);
        }

        /// <summary>
        /// Toggle auto sun tracking
        /// </summary>
        public void ToggleAutoTracking()
        {
            autoTrackSun = !autoTrackSun;
        }

        /// <summary>
        /// Trigger energy burst
        /// </summary>
        public void TriggerEnergyBurst()
        {
            if (energyWaves != null)
            {
                energyWaves.Emit(50);
            }

            // Temporary glow boost
            if (glowMaterial != null)
            {
                StartCoroutine(GlowBoost());
            }
        }

        System.Collections.IEnumerator GlowBoost()
        {
            float originalIntensity = glowMaterial.GetFloat("_GlowIntensity");
            glowMaterial.SetFloat("_GlowIntensity", originalIntensity * 3f);

            yield return new WaitForSeconds(0.5f);

            glowMaterial.SetFloat("_GlowIntensity", originalIntensity);
        }

        void OnDestroy()
        {
            if (panelMaterial != null)
            {
                Destroy(panelMaterial);
            }
        }
    }
}
