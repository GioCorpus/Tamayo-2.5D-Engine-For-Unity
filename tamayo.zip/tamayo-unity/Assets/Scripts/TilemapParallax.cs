using UnityEngine;
using UnityEngine.Tilemaps;

namespace Tamayo2D
{
    /// <summary>
    /// Controls parallax scrolling for Tilemap layers
    /// Creates depth effect for 2.5D isometric scenes
    /// </summary>
    public class TilemapParallax : MonoBehaviour
    {
        [Header("Parallax Settings")]
        [Tooltip("How much this layer moves relative to camera (0 = no movement, 1 = full movement)")]
        [Range(0f, 1f)]
        public float parallaxFactor = 0.5f;

        [Tooltip("Enable infinite scrolling")]
        public bool infiniteScrolling = true;

        [Tooltip("Width of the tilemap for infinite scrolling")]
        public float tilemapWidth = 0f;

        [Header("Tilemap References")]
        [Tooltip("Tilemap component")]
        public Tilemap tilemap;

        [Tooltip("Tilemap renderer")]
        public TilemapRenderer tilemapRenderer;

        [Header("Depth Settings")]
        [Tooltip("Z-depth for sorting")]
        public float zDepth = 0f;

        [Tooltip("Enable depth-based scaling")]
        public bool enableDepthScaling = true;

        [Tooltip("Scale factor based on depth")]
        public float depthScaleFactor = 0.1f;

        private Transform cameraTransform;
        private Vector3 previousCameraPosition;
        private float startPosition;
        private Vector3 originalScale;

        void Start()
        {
            cameraTransform = Camera.main.transform;
            previousCameraPosition = cameraTransform.position;
            startPosition = transform.position.x;
            originalScale = transform.localScale;

            // Get tilemap width if not set
            if (tilemapWidth == 0f && tilemap != null)
            {
                BoundsInt bounds = tilemap.cellBounds;
                tilemapWidth = bounds.size.x * tilemap.cellSize.x;
            }

            // Set z-depth
            if (tilemapRenderer != null)
            {
                tilemapRenderer.sortingOrder = Mathf.RoundToInt(zDepth * 100);
            }
        }

        void LateUpdate()
        {
            float deltaX = cameraTransform.position.x - previousCameraPosition.x;
            float movement = deltaX * parallaxFactor;

            transform.position += new Vector3(movement, 0, 0);

            if (infiniteScrolling && tilemapWidth > 0)
            {
                float temp = cameraTransform.position.x * (1 - parallaxFactor);
                if (Mathf.Abs(transform.position.x - cameraTransform.position.x) >= tilemapWidth)
                {
                    float offset = (transform.position.x - cameraTransform.position.x) % tilemapWidth;
                    transform.position = new Vector3(cameraTransform.position.x + offset, transform.position.y, transform.position.z);
                }
            }

            // Apply depth-based scaling
            if (enableDepthScaling)
            {
                float depthScale = 1f - (zDepth * depthScaleFactor);
                transform.localScale = originalScale * depthScale;
            }

            previousCameraPosition = cameraTransform.position;
        }

        /// <summary>
        /// Set parallax factor at runtime
        /// </summary>
        public void SetParallaxFactor(float factor)
        {
            parallaxFactor = Mathf.Clamp01(factor);
        }

        /// <summary>
        /// Set z-depth for sorting
        /// </summary>
        public void SetZDepth(float depth)
        {
            zDepth = depth;
            if (tilemapRenderer != null)
            {
                tilemapRenderer.sortingOrder = Mathf.RoundToInt(zDepth * 100);
            }
        }

        /// <summary>
        /// Set tilemap width for infinite scrolling
        /// </summary>
        public void SetTilemapWidth(float width)
        {
            tilemapWidth = width;
        }

        /// <summary>
        /// Toggle infinite scrolling
        /// </summary>
        public void ToggleInfiniteScrolling()
        {
            infiniteScrolling = !infiniteScrolling;
        }

        /// <summary>
        /// Toggle depth-based scaling
        /// </summary>
        public void ToggleDepthScaling()
        {
            enableDepthScaling = !enableDepthScaling;
            if (!enableDepthScaling)
            {
                transform.localScale = originalScale;
            }
        }

        /// <summary>
        /// Get current parallax factor
        /// </summary>
        public float GetParallaxFactor()
        {
            return parallaxFactor;
        }

        /// <summary>
        /// Get current z-depth
        /// </summary>
        public float GetZDepth()
        {
            return zDepth;
        }
    }
}
