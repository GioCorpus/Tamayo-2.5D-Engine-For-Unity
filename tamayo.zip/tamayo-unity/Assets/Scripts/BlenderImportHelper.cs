using UnityEngine;
using UnityEditor;
using System.IO;
using System.Collections.Generic;

namespace Tamayo2D
{
    /// <summary>
    /// Helper script for importing Blender models into Unity
    /// Handles FBX import settings, material extraction, and texture baking
    /// </summary>
    public class BlenderImportHelper : MonoBehaviour
    {
        [Header("Import Settings")]
        [Tooltip("Path to Blender export folder")]
        public string blenderExportPath = "Assets/Models/Blender/";

        [Tooltip("Path to Unity models folder")]
        public string unityModelsPath = "Assets/Models/";

        [Tooltip("Path to textures folder")]
        public string texturesPath = "Assets/Textures/";

        [Tooltip("Path to materials folder")]
        public string materialsPath = "Assets/Materials/";

        [Header("FBX Import Settings")]
        [Tooltip("Scale factor for FBX import")]
        public float scaleFactor = 1.0f;

        [Tooltip("Apply transforms on import")]
        public bool applyTransforms = true;

        [Tooltip("Import materials")]
        public bool importMaterials = true;

        [Tooltip("Import textures")]
        public bool importTextures = true;

        [Tooltip("Generate lightmap UVs")]
        public bool generateLightmapUVs = false;

        [Header("Texture Baking")]
        [Tooltip("Bake base color textures")]
        public bool bakeBaseColor = true;

        [Tooltip("Bake roughness textures")]
        public bool bakeRoughness = true;

        [Tooltip("Bake normal maps")]
        public bool bakeNormalMaps = true;

        [Tooltip("Texture resolution")]
        public int textureResolution = 1024;

        [Header("Shader Settings")]
        [Tooltip("Default shader for imported materials")]
        public string defaultShader = "Universal Render Pipeline/Lit";

        [Tooltip("Quantum glow shader")]
        public string quantumShader = "Tamayo2D/QuantumGlow";

        /// <summary>
        /// Import FBX file from Blender
        /// </summary>
        public void ImportFBX(string fbxPath)
        {
            if (!File.Exists(fbxPath))
            {
                Debug.LogError($"FBX file not found: {fbxPath}");
                return;
            }

            // Get file name without extension
            string fileName = Path.GetFileNameWithoutExtension(fbxPath);
            string modelPath = Path.Combine(unityModelsPath, fileName);

            // Create directory if it doesn't exist
            if (!Directory.Exists(modelPath))
            {
                Directory.CreateDirectory(modelPath);
            }

            // Copy FBX to Unity models folder
            string destPath = Path.Combine(modelPath, Path.GetFileName(fbxPath));
            File.Copy(fbxPath, destPath, true);

            // Refresh asset database
            AssetDatabase.Refresh();

            // Configure import settings
            ConfigureFBXImportSettings(destPath);

            Debug.Log($"Imported FBX: {fileName}");
        }

        /// <summary>
        /// Configure FBX import settings
        /// </summary>
        void ConfigureFBXImportSettings(string assetPath)
        {
            ModelImporter importer = AssetImporter.GetAtPath(assetPath) as ModelImporter;
            if (importer != null)
            {
                // Set scale
                importer.globalScale = scaleFactor;

                // Apply transforms
                importer.importAnimation = false;
                importer.importBlendShapes = false;
                importer.importCameras = false;
                importer.importLights = false;

                // Material settings
                importer.importMaterials = importMaterials;
                importer.importTextures = importTextures;

                // Generate lightmap UVs
                importer.generateSecondaryUV = generateLightmapUVs;

                // Save changes
                importer.SaveAndReimport();

                Debug.Log($"Configured import settings for: {assetPath}");
            }
        }

        /// <summary>
        /// Extract materials from imported model
        /// </summary>
        public void ExtractMaterials(string modelPath)
        {
            // Load the model
            GameObject model = AssetDatabase.LoadAssetAtPath<GameObject>(modelPath);
            if (model == null)
            {
                Debug.LogError($"Could not load model: {modelPath}");
                return;
            }

            // Get all renderers
            Renderer[] renderers = model.GetComponentsInChildren<Renderer>();
            foreach (Renderer renderer in renderers)
            {
                // Create material for each renderer
                Material material = new Material(Shader.Find(defaultShader));
                string materialName = $"{renderer.gameObject.name}_Material";
                material.name = materialName;

                // Save material
                string materialPath = Path.Combine(materialsPath, $"{materialName}.mat");
                AssetDatabase.CreateAsset(material, materialPath);

                // Assign material to renderer
                renderer.sharedMaterial = material;

                Debug.Log($"Created material: {materialName}");
            }

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
        }

        /// <summary>
        /// Bake textures from Blender materials
        /// </summary>
        public void BakeTextures(string modelPath)
        {
            // Load the model
            GameObject model = AssetDatabase.LoadAssetAtPath<GameObject>(modelPath);
            if (model == null)
            {
                Debug.LogError($"Could not load model: {modelPath}");
                return;
            }

            // Get all renderers
            Renderer[] renderers = model.GetComponentsInChildren<Renderer>();
            foreach (Renderer renderer in renderers)
            {
                // Bake base color
                if (bakeBaseColor)
                {
                    BakeTexture(renderer, "_BaseColor", $"{renderer.gameObject.name}_BaseColor");
                }

                // Bake roughness
                if (bakeRoughness)
                {
                    BakeTexture(renderer, "_Roughness", $"{renderer.gameObject.name}_Roughness");
                }

                // Bake normal map
                if (bakeNormalMaps)
                {
                    BakeTexture(renderer, "_BumpMap", $"{renderer.gameObject.name}_Normal");
                }
            }

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
        }

        /// <summary>
        /// Bake a single texture
        /// </summary>
        void BakeTexture(Renderer renderer, string propertyName, string textureName)
        {
            if (renderer.sharedMaterial == null)
            {
                return;
            }

            // Create render texture
            RenderTexture renderTexture = new RenderTexture(textureResolution, textureResolution, 24);
            RenderTexture.active = renderTexture;

            // Create camera for baking
            GameObject cameraObj = new GameObject("BakeCamera");
            Camera bakeCamera = cameraObj.AddComponent<Camera>();
            bakeCamera.targetTexture = renderTexture;
            bakeCamera.orthographic = true;
            bakeCamera.orthographicSize = 1f;

            // Position camera to see the object
            cameraObj.transform.position = renderer.bounds.center + Vector3.back * 2f;

            // Render
            bakeCamera.Render();

            // Create texture
            Texture2D texture = new Texture2D(textureResolution, textureResolution);
            texture.ReadPixels(new Rect(0, 0, textureResolution, textureResolution), 0, 0);
            texture.Apply();

            // Save texture
            byte[] bytes = texture.EncodeToPNG();
            string texturePath = Path.Combine(texturesPath, $"{textureName}.png");
            File.WriteAllBytes(texturePath, bytes);

            // Clean up
            RenderTexture.active = null;
            DestroyImmediate(cameraObj);
            DestroyImmediate(renderTexture);

            Debug.Log($"Baked texture: {textureName}");
        }

        /// <summary>
        /// Create quantum material for model
        /// </summary>
        public void CreateQuantumMaterial(string modelName)
        {
            // Create material with quantum shader
            Material material = new Material(Shader.Find(quantumShader));
            material.name = $"{modelName}_Quantum";

            // Set default properties
            material.SetColor("_GlowColor", new Color(0.2f, 0.5f, 1.0f, 1.0f));
            material.SetFloat("_GlowIntensity", 2.0f);
            material.SetFloat("_WaveSpeed", 2.0f);
            material.SetFloat("_WaveAmplitude", 1.0f);
            material.SetFloat("_WaveFrequency", 1.0f);

            // Save material
            string materialPath = Path.Combine(materialsPath, $"{material.name}.mat");
            AssetDatabase.CreateAsset(material, materialPath);

            Debug.Log($"Created quantum material: {material.name}");
        }

        /// <summary>
        /// Setup desert scene from Blender models
        /// </summary>
        public void SetupDesertScene()
        {
            // Import desert background
            string desertPath = Path.Combine(blenderExportPath, "Desert.fbx");
            if (File.Exists(desertPath))
            {
                ImportFBX(desertPath);
                ExtractMaterials(Path.Combine(unityModelsPath, "Desert/Desert.fbx"));
            }

            // Import solar panels
            string solarPath = Path.Combine(blenderExportPath, "SolarPanel.fbx");
            if (File.Exists(solarPath))
            {
                ImportFBX(solarPath);
                ExtractMaterials(Path.Combine(unityModelsPath, "SolarPanel/SolarPanel.fbx"));
                CreateQuantumMaterial("SolarPanel");
            }

            // Import quantum particles
            string quantumPath = Path.Combine(blenderExportPath, "QuantumParticles.fbx");
            if (File.Exists(quantumPath))
            {
                ImportFBX(quantumPath);
                CreateQuantumMaterial("QuantumParticles");
            }

            Debug.Log("Desert scene setup complete");
        }

        /// <summary>
        /// Export textures from Blender
        /// </summary>
        public void ExportBlenderTextures()
        {
            // This would typically call a Blender Python script
            // For now, we'll just log the expected workflow
            Debug.Log("To export textures from Blender:");
            Debug.Log("1. Open Blender file");
            Debug.Log("2. Select objects to export");
            Debug.Log("3. Run Python script: bpy.ops.export_scene.fbx()");
            Debug.Log("4. Enable 'Apply Transform' and set scale to 1.0");
            Debug.Log("5. Export to: " + blenderExportPath);
        }
    }
}
