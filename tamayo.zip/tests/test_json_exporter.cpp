#include <catch2/catch_test_macros.hpp>
#include "tamayo/io/JsonExporter.h"

using namespace tamayo;

TEST_CASE("JsonExporter empty scene", "[json_exporter]") {
    Scene scene;
    JsonExporter exporter;
    auto json = exporter.exportScene(scene, false);
    REQUIRE(json.contains("canvasWidth"));
    REQUIRE(json.contains("canvasHeight"));
    REQUIRE(json.contains("layers"));
}

TEST_CASE("JsonExporter layers", "[json_exporter]") {
    Scene scene;
    auto layer = std::make_shared<Layer>();
    layer->setName("Test Layer");
    scene.addLayer(layer);
    JsonExporter exporter;
    auto json = exporter.exportScene(scene, false);
    REQUIRE(json["layers"].size() == 1);
    REQUIRE(json["layers"][0]["name"] == "Test Layer");
}

TEST_CASE("JsonExporter transforms", "[json_exporter]") {
    Scene scene;
    auto layer = std::make_shared<Layer>();
    Transform transform;
    transform.setPosition(10.0f, 20.0f);
    layer->setTransform(transform);
    scene.addLayer(layer);
    JsonExporter exporter;
    auto json = exporter.exportScene(scene, false);
    REQUIRE(json["layers"][0]["transform"]["position"]["x"] == 10.0f);
    REQUIRE(json["layers"][0]["transform"]["position"]["y"] == 20.0f);
}

TEST_CASE("JsonExporter keyframes", "[json_exporter]") {
    Scene scene;
    auto layer = std::make_shared<Layer>();
    Timeline timeline;
    Keyframe keyframe;
    keyframe.setFrame(10);
    timeline.addKeyframe(keyframe);
    layer->setTimeline(timeline);
    scene.addLayer(layer);
    JsonExporter exporter;
    auto json = exporter.exportScene(scene, false);
    REQUIRE(json["layers"][0]["timeline"]["keyframes"].size() == 1);
    REQUIRE(json["layers"][0]["timeline"]["keyframes"][0]["frame"] == 10);
}

TEST_CASE("JsonExporter to string", "[json_exporter]") {
    Scene scene;
    JsonExporter exporter;
    std::string jsonStr = exporter.exportToString(scene, false);
    REQUIRE_FALSE(jsonStr.empty());
}

TEST_CASE("JsonExporter metadata toggle", "[json_exporter]") {
    Scene scene;
    JsonExporter exporter;
    auto jsonWithMeta = exporter.exportScene(scene, true);
    auto jsonWithoutMeta = exporter.exportScene(scene, false);
    REQUIRE(jsonWithMeta.contains("metadata"));
    REQUIRE_FALSE(jsonWithoutMeta.contains("metadata"));
}
