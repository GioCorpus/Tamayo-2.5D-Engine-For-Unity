#include <catch2/catch_test_macros.hpp>
#include "tamayo/core/Keyframe.h"

using namespace tamayo;

TEST_CASE("Keyframe construction", "[keyframe]") {
    Keyframe keyframe;
    REQUIRE(keyframe.getFrame() == 0);
    REQUIRE(keyframe.getInterpolation() == InterpolationType::Linear);
}

TEST_CASE("Keyframe frame", "[keyframe]") {
    Keyframe keyframe;
    keyframe.setFrame(10);
    REQUIRE(keyframe.getFrame() == 10);
}

TEST_CASE("Keyframe interpolation", "[keyframe]") {
    Keyframe keyframe;
    keyframe.setInterpolation(InterpolationType::EaseIn);
    REQUIRE(keyframe.getInterpolation() == InterpolationType::EaseIn);
}

TEST_CASE("Keyframe bezier handles", "[keyframe]") {
    Keyframe keyframe;
    keyframe.setBezierHandles(glm::vec2(0.1f, 0.2f), glm::vec2(0.8f, 0.9f));
    REQUIRE(keyframe.getBezierIn().x == 0.1f);
    REQUIRE(keyframe.getBezierIn().y == 0.2f);
    REQUIRE(keyframe.getBezierOut().x == 0.8f);
    REQUIRE(keyframe.getBezierOut().y == 0.9f);
}

TEST_CASE("Keyframe ordering", "[keyframe]") {
    Keyframe a;
    a.setFrame(5);
    Keyframe b;
    b.setFrame(10);
    REQUIRE(a < b);
    REQUIRE_FALSE(b < a);
}

TEST_CASE("Keyframe equality", "[keyframe]") {
    Keyframe a;
    a.setFrame(5);
    Keyframe b;
    b.setFrame(5);
    REQUIRE(a == b);
    REQUIRE_FALSE(a != b);
}
