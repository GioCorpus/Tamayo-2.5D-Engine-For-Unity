#include <catch2/catch_test_macros.hpp>
#include "tamayo/renderer/DepthSorter.h"

using namespace tamayo;

TEST_CASE("DepthSorter back-to-front", "[depth_sorter]") {
    DepthSorter sorter;
    std::vector<std::shared_ptr<Layer>> layers;
    auto layer1 = std::make_shared<Layer>();
    layer1->setZDepth(1.0f);
    auto layer2 = std::make_shared<Layer>();
    layer2->setZDepth(2.0f);
    layers.push_back(layer1);
    layers.push_back(layer2);

    auto sorted = sorter.sort(layers, false);
    REQUIRE(sorted[0]->getZDepth() == 2.0f);
    REQUIRE(sorted[1]->getZDepth() == 1.0f);
}

TEST_CASE("DepthSorter front-to-back", "[depth_sorter]") {
    DepthSorter sorter;
    std::vector<std::shared_ptr<Layer>> layers;
    auto layer1 = std::make_shared<Layer>();
    layer1->setZDepth(1.0f);
    auto layer2 = std::make_shared<Layer>();
    layer2->setZDepth(2.0f);
    layers.push_back(layer1);
    layers.push_back(layer2);

    auto sorted = sorter.sort(layers, true);
    REQUIRE(sorted[0]->getZDepth() == 1.0f);
    REQUIRE(sorted[1]->getZDepth() == 2.0f);
}

TEST_CASE("DepthSorter visibility filtering", "[depth_sorter]") {
    DepthSorter sorter;
    std::vector<std::shared_ptr<Layer>> layers;
    auto layer1 = std::make_shared<Layer>();
    layer1->setVisible(true);
    auto layer2 = std::make_shared<Layer>();
    layer2->setVisible(false);
    layers.push_back(layer1);
    layers.push_back(layer2);

    auto filtered = sorter.filterVisible(layers);
    REQUIRE(filtered.size() == 1);
    REQUIRE(filtered[0]->isVisible());
}

TEST_CASE("DepthSorter empty input", "[depth_sorter]") {
    DepthSorter sorter;
    std::vector<std::shared_ptr<Layer>> layers;
    auto sorted = sorter.sort(layers, false);
    REQUIRE(sorted.empty());
}
