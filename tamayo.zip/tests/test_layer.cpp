#include <catch2/catch_test_macros.hpp>
#include "tamayo/core/Layer.h"

using namespace tamayo;

TEST_CASE("Layer construction", "[layer]") {
    Layer layer;
    REQUIRE(layer.getName() == "");
    REQUIRE(layer.isVisible() == true);
    REQUIRE(layer.getZDepth() == 0.0f);
    REQUIRE(layer.getBlendMode() == BlendMode::Normal);
}

TEST_CASE("Layer properties", "[layer]") {
    Layer layer;
    layer.setName("Test Layer");
    layer.setVisible(false);
    layer.setZDepth(5.0f);
    layer.setBlendMode(BlendMode::Additive);
    REQUIRE(layer.getName() == "Test Layer");
    REQUIRE(layer.isVisible() == false);
    REQUIRE(layer.getZDepth() == 5.0f);
    REQUIRE(layer.getBlendMode() == BlendMode::Additive);
}

TEST_CASE("Layer image path", "[layer]") {
    Layer layer;
    layer.setImagePath("/path/to/image.png");
    REQUIRE(layer.getImagePath() == "/path/to/image.png");
}

TEST_CASE("Layer content size", "[layer]") {
    Layer layer;
    layer.setContentSize(1920.0f, 1080.0f);
    REQUIRE(layer.getContentWidth() == 1920.0f);
    REQUIRE(layer.getContentHeight() == 1080.0f);
}

TEST_CASE("Layer transform", "[layer]") {
    Layer layer;
    Transform transform;
    transform.setPosition(10.0f, 20.0f);
    layer.setTransform(transform);
    REQUIRE(layer.getTransform().getX() == 10.0f);
    REQUIRE(layer.getTransform().getY() == 20.0f);
}

TEST_CASE("Layer transform with keyframes", "[layer]") {
    Layer layer;
    Timeline timeline;
    Keyframe keyframe;
    keyframe.setFrame(0);
    keyframe.getTransform().setPosition(0.0f, 0.0f);
    timeline.addKeyframe(keyframe);
    layer.setTimeline(timeline);
    REQUIRE_FALSE(layer.getTimeline().isEmpty());
}

TEST_CASE("Layer child hierarchy", "[layer]") {
    Layer parent;
    auto child = std::make_shared<Layer>();
    child->setName("Child");
    parent.addChild(child);
    REQUIRE(parent.getChildren().size() == 1);
    REQUIRE(parent.findChild(child->getID()) != nullptr);
}
