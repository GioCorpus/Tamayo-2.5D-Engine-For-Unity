#include <catch2/catch_test_macros.hpp>
#include "tamayo/core/Scene.h"

using namespace tamayo;

TEST_CASE("Scene construction", "[scene]") {
    Scene scene;
    REQUIRE(scene.getCanvasWidth() == 1920.0f);
    REQUIRE(scene.getCanvasHeight() == 1080.0f);
    REQUIRE(scene.getLayers().empty());
}

TEST_CASE("Scene canvas size", "[scene]") {
    Scene scene;
    scene.setCanvasSize(1280.0f, 720.0f);
    REQUIRE(scene.getCanvasWidth() == 1280.0f);
    REQUIRE(scene.getCanvasHeight() == 720.0f);
}

TEST_CASE("Scene background color", "[scene]") {
    Scene scene;
    Color color(0.5f, 0.5f, 0.5f, 1.0f);
    scene.setBackgroundColor(color);
    REQUIRE(scene.getBackgroundColor().r == 0.5f);
    REQUIRE(scene.getBackgroundColor().g == 0.5f);
    REQUIRE(scene.getBackgroundColor().b == 0.5f);
    REQUIRE(scene.getBackgroundColor().a == 1.0f);
}

TEST_CASE("Scene add layer", "[scene]") {
    Scene scene;
    auto layer = std::make_shared<Layer>();
    layer->setName("Test Layer");
    scene.addLayer(layer);
    REQUIRE(scene.getLayers().size() == 1);
}

TEST_CASE("Scene find layer", "[scene]") {
    Scene scene;
    auto layer = std::make_shared<Layer>();
    layer->setName("Test Layer");
    scene.addLayer(layer);
    auto found = scene.findLayer(layer->getID());
    REQUIRE(found != nullptr);
    REQUIRE(found->getName() == "Test Layer");
}

TEST_CASE("Scene move layer", "[scene]") {
    Scene scene;
    auto layer1 = std::make_shared<Layer>();
    layer1->setName("Layer 1");
    auto layer2 = std::make_shared<Layer>();
    layer2->setName("Layer 2");
    scene.addLayer(layer1);
    scene.addLayer(layer2);
    scene.moveLayer(layer1->getID(), 1);
    REQUIRE(scene.getLayers()[0]->getName() == "Layer 2");
    REQUIRE(scene.getLayers()[1]->getName() == "Layer 1");
}

TEST_CASE("Scene remove layer", "[scene]") {
    Scene scene;
    auto layer = std::make_shared<Layer>();
    layer->setName("Test Layer");
    scene.addLayer(layer);
    scene.removeLayer(layer->getID());
    REQUIRE(scene.getLayers().empty());
}

TEST_CASE("Scene depth sorting", "[scene]") {
    Scene scene;
    auto layer1 = std::make_shared<Layer>();
    layer1->setZDepth(1.0f);
    auto layer2 = std::make_shared<Layer>();
    layer2->setZDepth(2.0f);
    scene.addLayer(layer1);
    scene.addLayer(layer2);
    scene.sortLayersByDepth(false);
    REQUIRE(scene.getLayers()[0]->getZDepth() == 2.0f);
    REQUIRE(scene.getLayers()[1]->getZDepth() == 1.0f);
}

TEST_CASE("Scene frame clamping", "[scene]") {
    Scene scene;
    scene.setTotalFrames(100);
    REQUIRE(scene.clampFrame(50) == 50);
    REQUIRE(scene.clampFrame(150) == 99);
    REQUIRE(scene.clampFrame(0) == 0);
}

TEST_CASE("Scene background color", "[scene]") {
    Scene scene;
    Color color(1.0f, 0.0f, 0.0f, 1.0f);
    scene.setBackgroundColor(color);
    REQUIRE(scene.getBackgroundColor().r == 1.0f);
    REQUIRE(scene.getBackgroundColor().g == 0.0f);
    REQUIRE(scene.getBackgroundColor().b == 0.0f);
    REQUIRE(scene.getBackgroundColor().a == 1.0f);
}
