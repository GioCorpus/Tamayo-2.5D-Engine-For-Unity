#include <catch2/catch_test_macros.hpp>
#include "tamayo/core/Timeline.h"

using namespace tamayo;

TEST_CASE("Timeline construction", "[timeline]") {
    Timeline timeline;
    REQUIRE(timeline.isEmpty());
    REQUIRE(timeline.getStartFrame() == 0);
    REQUIRE(timeline.getEndFrame() == 0);
}

TEST_CASE("Timeline add keyframe", "[timeline]") {
    Timeline timeline;
    Keyframe keyframe;
    keyframe.setFrame(10);
    timeline.addKeyframe(keyframe);
    REQUIRE_FALSE(timeline.isEmpty());
    REQUIRE(timeline.hasKeyframeAt(10));
}

TEST_CASE("Timeline remove keyframe", "[timeline]") {
    Timeline timeline;
    Keyframe keyframe;
    keyframe.setFrame(10);
    timeline.addKeyframe(keyframe);
    timeline.removeKeyframe(10);
    REQUIRE(timeline.isEmpty());
}

TEST_CASE("Timeline clear keyframes", "[timeline]") {
    Timeline timeline;
    Keyframe keyframe1;
    keyframe1.setFrame(10);
    Keyframe keyframe2;
    keyframe2.setFrame(20);
    timeline.addKeyframe(keyframe1);
    timeline.addKeyframe(keyframe2);
    timeline.clearKeyframes();
    REQUIRE(timeline.isEmpty());
}

TEST_CASE("Timeline get keyframes", "[timeline]") {
    Timeline timeline;
    Keyframe keyframe1;
    keyframe1.setFrame(10);
    Keyframe keyframe2;
    keyframe2.setFrame(20);
    timeline.addKeyframe(keyframe1);
    timeline.addKeyframe(keyframe2);
    const auto& keyframes = timeline.getKeyframes();
    REQUIRE(keyframes.size() == 2);
}

TEST_CASE("Timeline get keyframe at", "[timeline]") {
    Timeline timeline;
    Keyframe keyframe;
    keyframe.setFrame(10);
    timeline.addKeyframe(keyframe);
    auto result = timeline.getKeyframeAt(10);
    REQUIRE(result.has_value());
    REQUIRE(result->getFrame() == 10);
}

TEST_CASE("Timeline evaluate linear interpolation", "[timeline]") {
    Timeline timeline;
    Keyframe keyframe1;
    keyframe1.setFrame(0);
    keyframe1.getTransform().setPosition(0.0f, 0.0f);
    Keyframe keyframe2;
    keyframe2.setFrame(10);
    keyframe2.getTransform().setPosition(100.0f, 100.0f);
    timeline.addKeyframe(keyframe1);
    timeline.addKeyframe(keyframe2);

    Transform result = timeline.evaluate(5);
    REQUIRE(result.getX() == 50.0f);
    REQUIRE(result.getY() == 50.0f);
}

TEST_CASE("Timeline evaluate boundary", "[timeline]") {
    Timeline timeline;
    Keyframe keyframe1;
    keyframe1.setFrame(0);
    keyframe1.getTransform().setPosition(0.0f, 0.0f);
    Keyframe keyframe2;
    keyframe2.setFrame(10);
    keyframe2.getTransform().setPosition(100.0f, 100.0f);
    timeline.addKeyframe(keyframe1);
    timeline.addKeyframe(keyframe2);

    Transform result = timeline.evaluate(0);
    REQUIRE(result.getX() == 0.0f);
    REQUIRE(result.getY() == 0.0f);

    result = timeline.evaluate(10);
    REQUIRE(result.getX() == 100.0f);
    REQUIRE(result.getY() == 100.0f);
}

TEST_CASE("Timeline frame time conversion", "[timeline]") {
    Timeline timeline;
    REQUIRE(timeline.timeToFrame(1.0f, 30.0f) == 30);
    REQUIRE(timeline.frameToTime(30, 30.0f) == 1.0f);
}

TEST_CASE("Timeline get previous keyframe", "[timeline]") {
    Timeline timeline;
    Keyframe keyframe1;
    keyframe1.setFrame(10);
    Keyframe keyframe2;
    keyframe2.setFrame(20);
    timeline.addKeyframe(keyframe1);
    timeline.addKeyframe(keyframe2);

    auto prev = timeline.getPreviousKeyframe(15);
    REQUIRE(prev.has_value());
    REQUIRE(prev->getFrame() == 10);
}

TEST_CASE("Timeline get next keyframe", "[timeline]") {
    Timeline timeline;
    Keyframe keyframe1;
    keyframe1.setFrame(10);
    Keyframe keyframe2;
    keyframe2.setFrame(20);
    timeline.addKeyframe(keyframe1);
    timeline.addKeyframe(keyframe2);

    auto next = timeline.getNextKeyframe(15);
    REQUIRE(next.has_value());
    REQUIRE(next->getFrame() == 20);
}

TEST_CASE("Timeline clear", "[timeline]") {
    Timeline timeline;
    Keyframe keyframe;
    keyframe.setFrame(10);
    timeline.addKeyframe(keyframe);
    timeline.clearKeyframes();
    REQUIRE(timeline.isEmpty());
}
