#include <catch2/catch_test_macros.hpp>
#include "tamayo/core/Transform.h"

using namespace tamayo;

TEST_CASE("Transform construction", "[transform]") {
    Transform transform;
    REQUIRE(transform.getX() == 0.0f);
    REQUIRE(transform.getY() == 0.0f);
    REQUIRE(transform.getZ() == 0.0f);
    REQUIRE(transform.getSX() == 1.0f);
    REQUIRE(transform.getSY() == 1.0f);
    REQUIRE(transform.getRotation() == 0.0f);
    REQUIRE(transform.getAlpha() == 1.0f);
}

TEST_CASE("Transform position", "[transform]") {
    Transform transform;
    transform.setPosition(10.0f, 20.0f, 30.0f);
    REQUIRE(transform.getX() == 10.0f);
    REQUIRE(transform.getY() == 20.0f);
    REQUIRE(transform.getZ() == 30.0f);
}

TEST_CASE("Transform scale", "[transform]") {
    Transform transform;
    transform.setScale(2.0f, 3.0f);
    REQUIRE(transform.getSX() == 2.0f);
    REQUIRE(transform.getSY() == 3.0f);
}

TEST_CASE("Transform rotation", "[transform]") {
    Transform transform;
    transform.setRotation(45.0f);
    REQUIRE(transform.getRotation() == 45.0f);
}

TEST_CASE("Transform alpha clamping", "[transform]") {
    Transform transform;
    transform.setAlpha(1.5f);
    REQUIRE(transform.getAlpha() == 1.0f);
    transform.setAlpha(-0.5f);
    REQUIRE(transform.getAlpha() == 0.0f);
}

TEST_CASE("Transform lerp", "[transform]") {
    Transform a;
    a.setPosition(0.0f, 0.0f);
    a.setScale(1.0f, 1.0f);
    a.setRotation(0.0f);
    a.setAlpha(1.0f);

    Transform b;
    b.setPosition(100.0f, 100.0f);
    b.setScale(2.0f, 2.0f);
    b.setRotation(90.0f);
    b.setAlpha(0.0f);

    Transform result = Transform::lerp(a, b, 0.5f);
    REQUIRE(result.getX() == 50.0f);
    REQUIRE(result.getY() == 50.0f);
    REQUIRE(result.getSX() == 1.5f);
    REQUIRE(result.getSY() == 1.5f);
    REQUIRE(result.getRotation() == 45.0f);
    REQUIRE(result.getAlpha() == 0.5f);
}

TEST_CASE("Transform matrix", "[transform]") {
    Transform transform;
    transform.setPosition(10.0f, 20.0f);
    glm::mat4 matrix = transform.getMatrix();
    // Matrix should be valid (not all zeros)
    bool hasNonZero = false;
    for (int i = 0; i < 4; ++i) {
        for (int j = 0; j < 4; ++j) {
            if (matrix[i][j] != 0.0f) {
                hasNonZero = true;
                break;
            }
        }
    }
    REQUIRE(hasNonZero);
}
