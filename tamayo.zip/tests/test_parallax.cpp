#include <catch2/catch_test_macros.hpp>
#include "tamayo/core/ParallaxEngine.h"

using namespace tamayo;

TEST_CASE("ParallaxEngine construction", "[parallax]") {
    ParallaxEngine engine;
    REQUIRE(engine.getCanvasWidth() == 1920.0f);
    REQUIRE(engine.getCanvasHeight() == 1080.0f);
    REQUIRE(engine.getCameraOffset().x == 0.0f);
    REQUIRE(engine.getCameraOffset().y == 0.0f);
    REQUIRE(engine.getCameraZoom() == 1.0f);
}

TEST_CASE("ParallaxEngine camera offset", "[parallax]") {
    ParallaxEngine engine;
    engine.setCameraOffset(100.0f, 200.0f);
    REQUIRE(engine.getCameraOffset().x == 100.0f);
    REQUIRE(engine.getCameraOffset().y == 200.0f);
}

TEST_CASE("ParallaxEngine camera zoom", "[parallax]") {
    ParallaxEngine engine;
    engine.setCameraZoom(2.0f);
    REQUIRE(engine.getCameraZoom() == 2.0f);
}

TEST_CASE("ParallaxEngine depth-varying offset", "[parallax]") {
    ParallaxEngine engine;
    engine.setCameraOffset(100.0f, 100.0f);
    glm::vec2 offset0 = engine.calculateDepthOffset(0.0f);
    glm::vec2 offset1 = engine.calculateDepthOffset(1.0f);
    REQUIRE(offset0.x > offset1.x);
    REQUIRE(offset0.y > offset1.y);
}

TEST_CASE("ParallaxEngine depth-varying scale", "[parallax]") {
    ParallaxEngine engine;
    engine.setCameraZoom(2.0f);
    float scale0 = engine.calculateDepthScale(0.0f);
    float scale1 = engine.calculateDepthScale(1.0f);
    REQUIRE(scale0 > scale1);
}

TEST_CASE("ParallaxEngine apply parallax", "[parallax]") {
    ParallaxEngine engine;
    engine.setCameraOffset(100.0f, 100.0f);
    std::vector<std::shared_ptr<Layer>> layers;
    auto layer = std::make_shared<Layer>();
    layer->setZDepth(0.5f);
    layers.push_back(layer);
    engine.applyParallax(layers);
    // Layer transform should be modified
    REQUIRE(layers[0]->getTransform().getX() != 0.0f);
}

TEST_CASE("ParallaxEngine layer depth generation", "[parallax]") {
    ParallaxEngine engine;
    auto depths = engine.generateLayerDepths(5);
    REQUIRE(depths.size() == 5);
    REQUIRE(depths[0] == 0.0f);
    REQUIRE(depths[4] == 1.0f);
}
